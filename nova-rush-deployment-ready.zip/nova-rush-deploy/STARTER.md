# Nova Rush — Copy to a New Chat

This file is small enough to paste directly into a new coding chat if you cannot
attach the project archive.

## What to attach

Best option: attach `export/nova-rush-code-only.zip` (111 KB) to the new chat.
If the interface blocks zip files, use `export/nova-rush-current-dist.zip` for
the runnable build only, or paste this file.

## Prompt to paste

> Continue development of the attached Nova Rush project. Read HANDOFF.md first,
> then inspect the existing code before editing. Implement the Pending Request in
> HANDOFF.md: fix Glacier Ice Slash slowing on impact, make Survival earnings
> persist for the shop, and redesign Prism's ultimate into a five-second radial
> destruction wave followed by transformation into another comet whose normal
> weapon is inherited. Each later Prism ultimate must repeat the explosion and
> transform into a different comet. Preserve all existing systems, verify on a
> Galaxy S10-sized viewport, run strict TypeScript checks, and run `npm run build`.

## Project summary for a fresh chat

Nova Rush is a mobile-first 2D arcade game.

Stack: React 19, TypeScript, Vite 7, Tailwind CSS v4, Canvas 2D, WebAudio.
Packaged as an offline PWA, tuned for a Samsung Galaxy S10 at 360x760 portrait.

Build commands:

```bash
npm install
npm run dev
npx tsc --noEmit --noUnusedLocals --noUnusedParameters
npm run build
```

`node scripts/make-icons.mjs` regenerates `public/icons/` if it is missing.

## Core files

```
src/App.tsx                 screen router + engine/UI wiring
src/game/engine.ts          game loop, physics, bosses, enemies, ultimates, rendering
src/game/abilities.ts       comet weapons, effects, ultimate definitions
src/game/stages.ts          ten Chapter One stages + planet bosses
src/game/balls.ts           unlockable comet characters + prices
src/game/cometArt.ts        procedural comet artwork
src/game/audio.ts           procedural cinematic SFX
src/game/music.ts           procedural sci-fi soundtrack
src/game/bank.ts            persistent shards, stars, settings
src/ui/GameHud.tsx          in-game HUD + Supernova gauge
src/ui/MainMenu.tsx         main menu
src/ui/StageSelect.tsx      stage selection
src/ui/StageComplete.tsx    star grade + return to stages
public/sw.js                offline cache, currently nova-rush-v29
```

## Current gameplay state

- Ten stages: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune,
  Pluto, the Sun. Each has its own background, boss model, movement, attack
  pattern, projectile type, distance target and star thresholds.
- Boss health ranges 260 to 2385; bosses are immune to Supernova pull but take
  chip damage.
- Weapons auto-fire for 10 seconds after collecting an orb. Weapon orbs drop on
  a fixed cadence. Supernova recharges on a 20-second radial gauge.
- There is no on-screen combo meter.
- Five comets: Pulse (pierce), Glacier (chill), Inferno (burn), Nebula
  (explosive), Prism (ricochet + radiant).
  - Pulse ultimate: Nova Burst shockwaves
  - Glacier ultimate: Absolute Zero expanding freeze wave
  - Inferno ultimate: Solar Flare flamethrower
  - Nebula ultimate: Black Hole gravity well
  - Prism ultimate: Spectrum Storm rotating lances (to be replaced)
- AI co-pilot drones stack to 3, last 40s each, and fire independently.
- Squadron pickup deploys 4 fighters for 12s.
- Endless Survival mode advances waves every 25s and cycles backdrops.
- Shards persist in `nova-credits`; shop prices are 90 / 200 / 400 / 700.

## Pending work (not yet implemented)

1. Ice Slash must reliably apply slow to asteroids and aliens on impact while
   still dealing damage.
2. Survival earnings must persist and be spendable in the shop.
3. Prism ultimate becomes a 5-second radial destruction explosion, then Prism
   transforms into another comet and inherits its normal weapon. Each later use
   explodes again and transforms into a different comet.

## Local storage keys

`nova-best`, `nova-credits`, `nova-balls`, `nova-ball`, `nova-stars`,
`nova-progress`, `nova-settings`, `nova-track`, `nova-story-seen`.
