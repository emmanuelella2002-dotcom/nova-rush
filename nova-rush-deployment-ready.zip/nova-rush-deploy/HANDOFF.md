# Nova Rush - New Chat Handoff

## Project

Nova Rush is a mobile-first 2D arcade game built with React, TypeScript, Vite,
Tailwind CSS v4, Canvas 2D, and WebAudio. It is packaged as an offline-capable
PWA and is tuned for a Samsung Galaxy S10 portrait viewport.

The project currently builds successfully with:

```bash
npm install
npm run dev
npm run build
```

The production build is written to `dist/`.

## Entry Points

- `src/App.tsx` - React screen router and engine/UI integration
- `src/game/engine.ts` - main game loop, physics, rendering, enemies, bosses,
  pickups, status effects, ultimates, survival mode, and AI assistants
- `src/game/abilities.ts` - comet weapons, effects, and ultimate definitions
- `src/game/stages.ts` - Chapter One stages and planet boss configuration
- `src/game/cometArt.ts` - procedural comet character artwork
- `src/game/audio.ts` - procedural cinematic SFX
- `src/game/music.ts` - procedural sci-fi soundtrack system
- `src/ui/GameHud.tsx` - minimal in-game HUD and Supernova recharge gauge
- `src/ui/StageSelect.tsx` - stage selection and progression
- `src/ui/MainMenu.tsx` - main navigation and comet shop access

## Current Implemented State

- Ten Chapter One planet stages: Mercury through the Sun
- Each stage has a unique background, boss model, movement, attack pattern,
  projectile weapon, target distance, and star grade
- Boss health currently ranges from 260 to 2385
- Boss sprite rendering uses spherical lighting, atmospheric rims, and
  planet-specific surface features
- Weapons auto-fire for ten seconds after a weapon orb is collected
- Weapon orbs drop on a fixed cadence
- Supernova recharges automatically using a 20-second radial gauge
- No combo meter is displayed
- Five comet characters with different weapons and ultimate mechanics
- Black Hole ultimate violently pulls and damages all non-boss objects
- Glacier Absolute Zero creates an expanding freeze wave
- AI co-pilot drones stack up to three and fly for forty seconds each
- A four-fighter squadron pickup provides temporary heavy firepower
- Endless Survival mode escalates every twenty-five seconds
- Money/shards and stage progress persist in `localStorage`
- Procedural sci-fi music and layered cinematic SFX
- Offline PWA service worker version: `nova-rush-v29`

## Latest Update - Implemented (2026-11-10)

The last gameplay request before this handoff was:

1. Fix Glacier's normal Ice Slash bullets so impact reliably slows both
   asteroids and alien ships while still dealing damage.
2. Make money earned in Survival mode persist and be usable in the shop.
3. Replace Prism's current Spectrum Storm ultimate with this sequence:
   - A radial explosion that destroys everything in its path for five seconds.
   - After the explosion, Prism transforms into one of the other comet
     characters.
   - Prism inherits that character's normal bullet weapon and abilities.
   - Every later Prism ultimate repeats the radial explosion and then transforms
     Prism into a different character.

Implemented in the latest source update:

1. Glacier Ice Slash now applies a 3.2-second slow to struck asteroids and alien ships while dealing direct damage. Surviving asteroids retain health and can be hit again.
2. Completed-run earnings are added through `addCredits()` to the persistent `nova-credits` wallet, making Survival rewards available to the shop after relaunch.
3. Prism's ultimate is now a five-second radial destruction pulse. At the end, Prism transforms in sequence through Pulse, Glacier, Inferno, and Nebula, adopting each comet's normal weapon. Prism's ultimate identity remains active across transformations, so each later ultimate repeats the five-second destruction and advances to a different form.
4. The offline service-worker cache was bumped to `nova-rush-v30` so installed clients can receive the updated app shell.

Validation status for this update: engine/ability strict TypeScript check and TypeScript transpilation passed. Full app strict checks, production build, and interactive Galaxy S10 viewport verification could not run in this environment because npm registry access failed (`EAI_AGAIN`), leaving Vite and type packages unavailable. Re-run the full commands after dependencies are installed.

## Important Existing Mechanics

### Weapon Effects

- Pulse: piercing plasma/machine-gun rounds
- Glacier: Ice Slash with chill/slow effect
- Inferno: flame/wave gun with burn damage over time
- Nebula: seeking explosive attacks and Black Hole ultimate
- Prism: Prism Lance with ricochet and radiant effects

### Current Ultimates

- Pulse: Nova Burst expanding shockwaves
- Glacier: Absolute Zero expanding freeze wave
- Inferno: Solar Flare flamethrower
- Nebula: Black Hole gravity well
- Prism: Spectrum Storm rotating prism lances

### Persistent Storage

- `nova-best` - best score
- `nova-credits` - shard balance used by the shop
- `nova-balls` - owned comet characters
- `nova-ball` - equipped comet
- `nova-stars` - stage star grades
- `nova-progress` - highest cleared stage
- `nova-settings` - audio/settings preferences
- `nova-track` - selected soundtrack
- `nova-story-seen` - first-launch story flag

## Validation

After changes, always run:

```bash
npx tsc --noEmit --noUnusedLocals --noUnusedParameters
npm run build
```

For mobile interaction tests, use a 360 x 760 viewport with touch enabled.

## Ready-to-Paste Prompt

Paste the following into a new coding chat after attaching the source archive:

> Continue development of the attached Nova Rush project. Read HANDOFF.md first,
> then inspect the existing code before editing. Implement the Pending Request in
> HANDOFF.md: fix Glacier Ice Slash slowing on impact, make Survival earnings
> persist for the shop, and redesign Prism's ultimate into a five-second radial
> destruction wave followed by transformation into another comet whose normal
> weapon is inherited. Each later Prism ultimate must repeat the explosion and
> transform into a different comet. Preserve all existing systems, verify on a
> Galaxy S10-sized viewport, run strict TypeScript checks, and run `npm run build`.


## Verification Retry - 2026-11-10

The latest attached updated-source archive was unpacked and inspected before any edits. The requested gameplay implementation is present in the source:

- Glacier Ice Slash applies a 3.2-second slow on direct asteroid impact and alien-interceptor impact; both paths retain direct bullet damage. Asteroids retain HP and can be hit repeatedly.
- Survival run completion sends the banked amount through `addCredits()` into `nova-credits`; the shop reads and spends from that same persistent wallet.
- Prism keeps a separate `prismCycle` identity while temporarily changing the active comet. Its five-second ultimate repeatedly clears asteroids and alien interceptors, damages an entered boss, then transforms through Pulse, Glacier, Inferno, and Nebula. `setBall(..., true)` preserves the Prism cycle while changing the active normal weapon.
- The service worker cache is `nova-rush-v30`.

Verification attempted on 2026-11-10:

| Check | Result | Details |
|---|---|---|
| Source inspection | Passed | Confirmed the three requested gameplay paths and shop persistence wiring |
| Strict TypeScript - game modules | Passed | Global TypeScript compiler with strict, no-unused checks and isolated game-module file set |
| Full project strict TypeScript | Blocked | Required `@types/node` and other installed type packages are unavailable; full command reports missing Node type definitions |
| Dependency restore (`npm ci`) | Blocked | Installation did not complete before the environment command timed out; dependencies remain unavailable |
| `npm run build` | Blocked | Vite is unavailable (`sh: 1: vite: not found`) |
| Galaxy S10 360 x 760 touch test | Not run | Playwright and the app's runtime dependencies are unavailable, so no interactive browser test can be claimed |

No gameplay source change was necessary in this retry because the latest source already contains the requested implementation. Re-run dependency installation, the full project checks, production build, and touch-enabled mobile verification when package installation is available. Do not mark the work release-verified until all checks pass.
