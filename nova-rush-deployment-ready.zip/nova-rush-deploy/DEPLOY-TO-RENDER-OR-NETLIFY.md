# Publish Nova Rush

This is the Vite/React source project. It is configured for a static production build.

## Build settings
- Build command: `npm run build`
- Publish/output directory: `dist`
- Node.js: 22

## Netlify
1. Push this project to a GitHub repository.
2. In Netlify, choose **Add new site → Import an existing project** and select the repository.
3. Keep the build command `npm run build` and publish directory `dist` (also recorded in `netlify.toml`).
4. Choose **Deploy**. Netlify will provide the public URL after the build succeeds.

## Render
1. Push this project to a GitHub repository.
2. In Render, create a **Static Site** and connect the repository.
3. Set build command to `npm run build` and publish directory to `dist`.
4. Deploy. Render will provide the public URL after the build succeeds.

The public link is created by the hosting provider after deployment; this source archive alone is not a live website.
