import { useCallback, useEffect, useRef, useState } from "react";
import { NovaEngine, type PowerState, type StarGrade } from "./game/engine";
import { sfx } from "./game/audio";
import { music } from "./game/music";
import { BALL_DEFS, readEquipped, readOwned, type BallId } from "./game/balls";
import { addCredits, spendCredits, readSettings, writeSettings, totalStars, readAllStars, writeStageStar, highestStageCleared, writeProgress } from "./game/bank";
import { GameHud } from "./ui/GameHud";
import { PauseOverlay } from "./ui/Hud";
import { GameOver, type RunSummary } from "./ui/GameOver";
import { Sheet, type SheetKind } from "./ui/Sheet";
import { Story } from "./ui/Story";
import { StageIntro } from "./ui/StageIntro";
import { BossIntro } from "./ui/BossIntro";
import { StageComplete } from "./ui/StageComplete";
import { MainMenu } from "./ui/MainMenu";
import { ChapterSelect } from "./ui/ChapterSelect";
import { StageSelect } from "./ui/StageSelect";
import { Settings as SettingsScreen } from "./ui/Settings";
import { CometPreview } from "./ui/CometPreview";
import { ABILITIES, EFFECT_INFO } from "./game/abilities";
import { X } from "lucide-react";

type Screen = "menu" | "chapters" | "stages" | "play" | "pause" | "over" | "settings";

interface FinalArgs {
  score: number;
  best: number;
  isNewBest: boolean;
  livesUsed: number;
  stagesCleared: number;
  banked: number;
  grade: StarGrade;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<NovaEngine | null>(null);
  const wakeRef = useRef<{ release(): Promise<void> } | null>(null);

  const [screen, setScreen] = useState<Screen>("menu");
  const [sheet, setSheet] = useState<SheetKind>(null);
  const [storyOpen, setStoryOpen] = useState(false);

  // chapter + stage selection
  const [chapterN, setChapterN] = useState(1);
  const [stageN, setStageN] = useState(1);

  // hud state
  const [score, setScore] = useState(0);
  const [distance, setDistance] = useState({ ly: 0, target: 1, boss: "MERCURY" });
  const [powers, setPowers] = useState<PowerState>({ slow: 0, double: 0, shield: false, shieldT: 0, lives: 5 });
  const [gunCharges, setGunCharges] = useState(0);
  const [weaponArmed, setWeaponArmed] = useState(false);
  const [weaponTime, setWeaponTime] = useState(0);
  const [copilotTime, setCopilotTime] = useState(0);
  const [squadronTime, setSquadronTime] = useState(0);
  const [ultCharge, setUltCharge] = useState(0);
  const [survival, setSurvival] = useState(false);
  const [wave, setWave] = useState(1);
  const [ultReady, setUltReady] = useState(false);
  const [ultActive, setUltActive] = useState(0);
  const [activeWeaponName, setActiveWeaponName] = useState(ABILITIES[readEquipped()]?.gun.name.toUpperCase() ?? "MACHINE GUN");

  // transitions / modals
  const [stageIntro, setStageIntro] = useState<{ n: number; name: string; subtitle: string; target: number; key: number } | null>(null);
  const [bossIntro, setBossIntro] = useState<{ name: string; title: string; body: string; hint: string; hp: number; hpMax: number; key: number } | null>(null);
  const [stageComplete, setStageComplete] = useState<{ stageN: number; grade: StarGrade; key: number } | null>(null);

  // persistent state
  const [best, setBest] = useState(() => Number(localStorage.getItem("nova-best") ?? 0) || 0);
  const [run, setRun] = useState<RunSummary>({ score: 0, best: 0, isNewBest: false, stageClears: 0, banked: 0, totalCredits: 0, livesUsed: 0, grade: { stars: 0, passed: false, finalScore: 0, deaths: 0 } });
  const [credits, setCredits] = useState(Number(localStorage.getItem("nova-credits") ?? 0) || 0);
  const [stars, setStars] = useState<Record<number, number>>(readAllStars());
  const [totalStarCount, setTotalStarCount] = useState<number>(totalStars());
  const [owned, setOwned] = useState<BallId[]>(readOwned);
  const [equipped, setEquipped] = useState<BallId>(readEquipped);

  // settings + flags
  const [muted, setMuted] = useState(!readSettings().sfx);
  const [musicMuted, setMusicMuted] = useState(!readSettings().music);
  const [trackIndex, setTrackIndex] = useState(() => music.trackIndex);
  const [hasRuns, setHasRuns] = useState(() => localStorage.getItem("nova-runs") === "1");


  // shop (simulated inside menu — purchases from a separate bottom sheet handled by Shop component which is deleted here for cleanliness)
  const [shopOpen, setShopOpen] = useState(false);

  const screenRef = useRef(screen);
  screenRef.current = screen;

  /* ---------------- wake lock ---------------- */
  const requestWake = useCallback(async () => {
    try {
      const nav = navigator as Navigator & {
        wakeLock?: { request(t: "screen"): Promise<{ release(): Promise<void> }> };
      };
      wakeRef.current = (await nav.wakeLock?.request("screen")) ?? null;
    } catch { /* unsupported */ }
  }, []);
  const releaseWake = useCallback(() => {
    void wakeRef.current?.release().catch(() => undefined);
    wakeRef.current = null;
  }, []);

  /* ---------------- engine lifecycle ---------------- */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new NovaEngine(canvas, {
      onScore: (s) => setScore(s),
      onDistance: (ly, target, boss) => setDistance({ ly, target, boss }),
      onPowers: (p) => setPowers(p),
      onGunReady: (n) => {
        setGunCharges(n);
        setWeaponArmed(engineRef.current?.isWeaponArmed ?? false);
      },
      onUltReady: (b) => setUltReady(b),
      onStageIntro: (n, name, subtitle, target) => {
        const key = Date.now();
        setStageIntro({ n, name, subtitle, target, key });
        // compare against the captured key so the banner actually clears
        setTimeout(() => setStageIntro((cur) => (cur && cur.key === key ? null : cur)), 2200);
      },
      onBossSpawn: (name, title, body, hp, hpMax, hint) => {
        if (!name) { setBossIntro(null); return; }
        // a boss always supersedes a lingering stage banner
        setStageIntro(null);
        setBossIntro({ name, title, body, hint, hp, hpMax, key: Date.now() });
        setTimeout(() => setBossIntro(null), 2000);
      },
      onBossHp: () => { /* health bar removed — the fight speaks for itself */ },
      onBossDefeated: (stageN, bonus) => {
        // persistent star write happens in onLevelComplete
        void stageN; void bonus;
      },
      onLevelComplete: (grade) => {
        const sn = engineRef.current?.currentStageN ?? 1;
        writeProgress(sn);
        const newStars = writeStageStar(sn, grade.stars);
        setStars((s) => ({ ...s, [sn]: newStars }));
        setTotalStarCount(totalStars());
        setStageComplete({ stageN: sn, grade, key: Date.now() });
        // the stage is finished — stop the run and hand back to stage select
        releaseWake();
        music.setIntensity(0.45);
      },
      onGameOver: (a: FinalArgs) => {
        const banked = a.banked;
        // Bank the completed run into the same persistent wallet used by the shop.
        const total = addCredits(banked);
        setCredits(total);
        setRun({
            score: a.score,
            best: a.best,
            isNewBest: a.isNewBest,
            stageClears: a.stagesCleared,
            livesUsed: a.livesUsed,
            banked,
          totalCredits: total,
          grade: a.grade,
        });
        setBest(a.best);
        setScreen("over");
        releaseWake();
        music.setIntensity(0.45);
      },
      onCredits: (n, reason) => {
        const next = addCredits(n);
        setCredits(next);
        void reason;
      },
      sfx,
    });
    engine.setBall(readEquipped());
    engineRef.current = engine;
    engine.start();

    const unlock = () => {
      sfx.unlock();
      music.unlock();
      if (!music.muted) music.start();
    };
    window.addEventListener("pointerdown", unlock, { once: true, passive: true });

    const kill = (e: Event) => e.preventDefault();
    document.addEventListener("contextmenu", kill);

    const onVis = () => {
      if (document.hidden && screenRef.current === "play") {
        engine.setPaused(true);
        setScreen("pause");
      }
      if (!document.hidden && screenRef.current === "play") void requestWake();
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      engine.destroy();
      window.removeEventListener("pointerdown", unlock);
      document.removeEventListener("contextmenu", kill);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [requestWake, releaseWake]);

  /* poll lightweight engine state for the HUD */
  useEffect(() => {
    if (screen !== "play") return;
    const id = setInterval(() => {
      const e = engineRef.current;
      if (!e) return;
      setWeaponTime(e.weaponTimeLeft);
      setCopilotTime(e.copilotTimeLeft);
      setSquadronTime(e.squadronTimeLeft);
      setUltCharge(e.ultChargeFrac);
      setUltActive(e.ultimateTimeLeft);
      setActiveWeaponName(e.currentWeaponName.toUpperCase());
      setWeaponArmed(e.isWeaponArmed);
      if (e.isSurvival) setWave(e.currentWave);
    }, 60);
    return () => clearInterval(id);
  }, [screen]);

  /* ---------------- actions ---------------- */
  const launch = useCallback((whichStage: number, endless = false) => {
    if (!hasRuns) {
      localStorage.setItem("nova-runs", "1");
      setHasRuns(true);
    }
    sfx.unlock();
    music.unlock();
    if (!music.muted) music.start();
    music.shuffle();
    setTrackIndex(music.trackIndex);
    music.setIntensity(0.85);
    engineRef.current?.setBall(equipped);
    setActiveWeaponName(ABILITIES[equipped]?.gun.name.toUpperCase() ?? "MACHINE GUN");
    setScore(0);
    setPowers({ slow: 0, double: 0, shield: false, shieldT: 0, lives: 5 });
    setGunCharges(0);
    setWeaponArmed(false);
    setWeaponTime(0);
    setSurvival(endless);
    setWave(1);
    setUltReady(false);
    setUltActive(0);
    setStageIntro(null);
    setBossIntro(null);
    setStageComplete(null);
    engineRef.current?.setPaused(false);
    engineRef.current?.launch(whichStage, endless);
    setScreen("play");
    void requestWake();
  }, [hasRuns, requestWake, equipped]);

  const pause = useCallback(() => {
    sfx.ui();
    music.setIntensity(0.5);
    engineRef.current?.setPaused(true);
    setScreen("pause");
  }, []);

  const resume = useCallback(() => {
    sfx.ui();
    music.setIntensity(0.85);
    engineRef.current?.setPaused(false);
    setScreen("play");
    void requestWake();
  }, [requestWake]);

  const toMenu = useCallback(() => {
    sfx.ui();
    music.setIntensity(0.45);
    engineRef.current?.setPaused(false);
    engineRef.current?.toMenu();
    setScreen("menu");
    releaseWake();
  }, [releaseWake]);

  const toggleMute = useCallback(() => {
    sfx.unlock();
    const next = !muted;
    sfx.setMuted(next);
    setMuted(next);
    const s = readSettings();
    writeSettings({ ...s, sfx: !next });
  }, [muted]);

  const toggleMusic = useCallback(() => {
    sfx.unlock();
    music.unlock();
    const next = !musicMuted;
    music.setMuted(next);
    if (!next) music.start();
    setMusicMuted(next);
    const s = readSettings();
    writeSettings({ ...s, music: !next });
  }, [musicMuted]);

  const useUlt = useCallback(() => {
    engineRef.current?.useUlt();
  }, []);

  const share = useCallback(() => {
    sfx.ui();
    const nav = navigator as Navigator & { share?: (d: ShareData) => Promise<void> };
    void nav
      .share?.({
        title: "Nova Rush",
        text: `I scored ${run.score.toLocaleString()} and cleared ${run.stageClears} stage${run.stageClears === 1 ? "" : "s"} in Nova Rush. Beat it.`,
        url: window.location.href.split("?")[0],
      })
      .catch(() => undefined);
  }, [run.score, run.stageClears]);

  const openSheet = useCallback((k: Exclude<SheetKind, null>) => {
    sfx.unlock(); sfx.ui(); setSheet(k);
  }, []);

  const canShare = typeof (navigator as Navigator & { share?: unknown }).share === "function";

  /* ---------------- shop ---------------- */
  const buy = useCallback(
    (id: BallId) => {
      const def = BALL_DEFS.find((d) => d.id === id);
      if (!def || owned.includes(id)) return;
      const res = spendCredits(def.price);
      if (!res.ok) return;
      const nextOwned = [...owned, id];
      setCredits(res.remaining);
      setOwned(nextOwned);
      localStorage.setItem("nova-balls", JSON.stringify(nextOwned));
      sfx.unlock(); sfx.buy();
      setEquipped(id);
      localStorage.setItem("nova-ball", id);
      engineRef.current?.setBall(id);
    },
    [credits, owned]
  );
  const equip = useCallback((id: BallId) => {
    sfx.ui();
    setEquipped(id);
    localStorage.setItem("nova-ball", id);
    engineRef.current?.setBall(id);
  }, []);

  /* ---------------- first-launch story ---------------- */
  useEffect(() => {
    if (!localStorage.getItem("nova-story-seen")) {
      setStoryOpen(true);
    }
  }, []);
  const closeStory = useCallback(() => {
    setStoryOpen(false);
    try { localStorage.setItem("nova-story-seen", "1"); } catch { /* private */ }
  }, []);

  const onStagePicked = useCallback((n: number) => {
    setStageN(n);
    setScreen("play");
    launch(n);
  }, [launch]);

  const highestCleared = highestStageCleared();

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#05060f]">
      <canvas ref={canvasRef} className="absolute inset-0" aria-label="Nova Rush game field" />

      <div className="vignette pointer-events-none absolute inset-0 z-10" />
      <div className="scanlines pointer-events-none absolute inset-0 z-10" />

      <MainMenu
        best={best}
        credits={credits}
        totalStars={totalStarCount}
        owned={owned}
        equipped={equipped}
        muted={muted}
        musicMuted={musicMuted}
        visible={screen === "menu"}
        onLaunch={() => setScreen("chapters")}
        onChapters={() => setScreen("chapters")}
        onSettings={() => setScreen("settings")}
        onShop={() => setShopOpen(true)}
        onStory={() => setStoryOpen(true)}
        onSurvival={() => launch(1, true)}
        onBuy={buy}
        onEquip={equip}
        onMute={toggleMute}
        onMusicMute={toggleMusic}
      />

      <ChapterSelect
        visible={screen === "chapters"}
        totalStars={totalStarCount}
        onBack={() => setScreen("menu")}
        onChapter={(n) => { setChapterN(n); setScreen("stages"); }}
      />

      <StageSelect
        visible={screen === "stages"}
        chapterN={chapterN}
        stars={stars}
        highestCleared={highestCleared}
        onBack={() => setScreen("chapters")}
        onPlay={onStagePicked}
      />

      <GameHud
        visible={screen === "play"}
        score={score}
        lives={powers.lives}
        ultReady={ultReady}
        ultActive={ultActive > 0}
        gunCharges={gunCharges}
        powers={powers}
        distance={distance.ly}
        distanceTarget={distance.target}
        bossName={distance.boss}
        weaponName={activeWeaponName}
        weaponArmed={weaponArmed}
        weaponTime={weaponTime}
        copilotTime={copilotTime}
        squadronTime={squadronTime}
        ultCharge={ultCharge}
        survival={survival}
        wave={wave}
        onPause={pause}

        onUlt={useUlt}
      />

      <GameOver
        visible={screen === "over"}
        run={run}
        canShare={canShare}
        onRetry={() => launch(stageN, survival)}
        onMenu={toMenu}
        onShare={share}
        onShop={() => setShopOpen(true)}
      />

      <PauseOverlay
        visible={screen === "pause"}
        muted={muted}
        musicMuted={musicMuted}
        onResume={resume}
        onRestart={() => launch(stageN, survival)}
        onMenu={toMenu}
        onMute={toggleMute}
        onMusicMute={toggleMusic}
      />

      <SettingsScreen
        visible={screen === "settings"}
        muted={muted}
        musicMuted={musicMuted}
        onMute={toggleMute}
        onMusicMute={toggleMusic}
        onBack={() => setScreen("menu")}
        trackIndex={trackIndex}
        onTrack={(i) => { sfx.unlock(); music.unlock(); music.setTrack(i); setTrackIndex(i); if (music.muted) { music.setMuted(false); setMusicMuted(false); } music.start(); }}
        onHow={() => openSheet("how")}
      />

      <Sheet kind={sheet} onClose={() => setSheet(null)} />
      <Story open={storyOpen} onClose={closeStory} />
      <StageIntro data={stageIntro} onDismiss={() => setStageIntro(null)} />
      <BossIntro data={bossIntro} />
      <StageComplete
        data={stageComplete}
        onNext={() => {
          setStageComplete(null);
          engineRef.current?.toMenu();
          setScreen("stages");
        }}
      />


      {screen === "play" && !weaponArmed && squadronTime <= 0 && copilotTime <= 0 && score < 60 && !bossIntro && !stageIntro && (
        <div className="pointer-events-none absolute inset-x-0 top-[44%] z-20 flex justify-center">
          <div className="animate-float rounded-full border border-violet-400/25 bg-[#0b0e20]/70 px-3.5 py-1.5 text-[9px] font-bold tracking-[0.22em] text-violet-200/90 backdrop-blur-sm">
            GRAB AN ORB TO ARM WEAPONS
          </div>
        </div>
      )}

      {shopOpen && (
        <ShopSheet
          owned={owned}
          equipped={equipped}
          credits={credits}
          onBuy={buy}
          onEquip={equip}
          onClose={() => setShopOpen(false)}
        />
      )}


    </div>
  );
}

/* ---------------- shop sheet ---------------- */
interface ShopSheetProps {
  owned: BallId[];
  equipped: BallId;
  credits: number;
  onBuy(id: BallId): void;
  onEquip(id: BallId): void;
  onClose(): void;
}

function ShopSheet(p: ShopSheetProps) {
  return (
    <div className="absolute inset-0 z-50" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-[#02030a]/80 backdrop-blur-md" onClick={p.onClose} />
      <div className="animate-rise absolute inset-x-3 bottom-3 top-10 mx-auto flex max-h-[88dvh] w-full max-w-md flex-col overflow-hidden rounded-[2rem] border border-slate-700/40 bg-[#0b0e20]/95 pt-3 backdrop-blur-xl">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-slate-600/60" />
        <button
          onClick={p.onClose}
          aria-label="Close shop"
          className="chip absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full text-slate-400 transition active:scale-90"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="overflow-y-auto px-5 py-3">
          <h2 className="font-display text-xl font-bold text-white text-glow">COMET HANGAR</h2>
          <p className="mt-1 text-[11px] text-slate-400">Each comet flies its own weapon system.</p>
          <div className="mt-3 chip flex items-center justify-between rounded-2xl px-4 py-3">
            <span className="text-[10px] font-bold tracking-[0.2em] text-slate-400">YOUR SHARDS</span>
            <span className="font-display text-base font-bold text-cyan-200 tabular-nums">{p.credits.toLocaleString()}</span>
          </div>
          <div className="mt-4 space-y-3">
            {BALL_DEFS.map((def) => {
              const isOwned = p.owned.includes(def.id);
              const isEquipped = p.equipped === def.id;
              const afford = p.credits >= def.price;
              const ab = ABILITIES[def.id];
              return (
                <div
                  key={def.id}
                  className={`rounded-3xl border p-4 transition-colors ${
                    isEquipped ? "border-cyan-300/40 bg-cyan-400/5" : "border-slate-700/40 bg-white/[0.02]"
                  }`}
                >
                  {/* comet portrait — real engine art */}
                  <div className="relative mb-3 overflow-hidden rounded-2xl bg-[#05060f]">
                    <CometPreview id={def.id} width={300} height={92} className="w-full" />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#05060f] via-transparent to-transparent opacity-60" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-display text-sm font-bold tracking-wider text-white">{def.name}</span>
                      {isEquipped && (
                        <span className="rounded-full bg-cyan-400/15 px-2 py-0.5 text-[9px] font-bold tracking-[0.15em] text-cyan-300">EQUIPPED</span>
                      )}
                    </div>
                    <p className="mt-1 text-[11px] leading-snug text-slate-400">{def.tagline}</p>

                    {/* weapon loadout */}
                    <div className="mt-3 space-y-1.5 rounded-2xl border border-slate-700/40 bg-black/20 px-3 py-2.5">
                      <div className="flex items-start gap-2">
                        <span className="mt-0.5 shrink-0 rounded bg-cyan-400/15 px-1.5 py-0.5 text-[8px] font-bold tracking-[0.15em] text-cyan-300">GUN</span>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[11px] font-bold text-slate-100">{ab.gun.name}</span>
                            {[ab.effect, ab.effect2].filter(Boolean).map((e) => (
                              <span
                                key={e}
                                className="rounded px-1.5 py-0.5 text-[8px] font-bold tracking-[0.12em]"
                                style={{
                                  color: EFFECT_INFO[e!].color,
                                  background: `${EFFECT_INFO[e!].color}1f`,
                                }}
                              >
                                {EFFECT_INFO[e!].label}
                              </span>
                            ))}
                          </div>
                          <div className="text-[10px] leading-snug text-slate-500">{ab.gun.description}</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="mt-0.5 shrink-0 rounded bg-amber-400/15 px-1.5 py-0.5 text-[8px] font-bold tracking-[0.15em] text-amber-300">ULT</span>
                        <div className="min-w-0">
                          <div className="text-[11px] font-bold text-slate-100">{ab.ultimate.name}</div>
                          <div className="text-[10px] leading-snug text-slate-500">{ab.ultimate.description}</div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3">
                      {isEquipped ? (
                        <div className="text-[10px] font-bold tracking-[0.2em] text-slate-500">IN LOADOUT</div>
                      ) : isOwned ? (
                        <button onClick={() => p.onEquip(def.id)} className="chip rounded-xl px-4 py-2 text-[10px] font-bold tracking-[0.2em] text-slate-100 transition active:scale-95">EQUIP</button>
                      ) : (
                        <button
                          onClick={() => p.onBuy(def.id)}
                          disabled={!afford}
                          className={`rounded-xl px-4 py-2 text-[10px] font-bold tracking-[0.2em] transition active:scale-95 ${
                            afford ? "btn-launch text-[#05060f]" : "cursor-not-allowed border border-slate-700/50 text-slate-500"
                          }`}
                        >
                          {def.price.toLocaleString()} SHARDS
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
