import { ArrowLeft, Lock, Play, Star, Target } from "lucide-react";
import { STAGES } from "../game/stages";

interface StageSelectProps {
  visible: boolean;
  chapterN: number;
  stars: Record<number, number>;
  highestCleared: number;
  onBack(): void;
  onPlay(stageN: number): void;
}

export function StageSelect(p: StageSelectProps) {
  if (!p.visible) return null;
  return (
    <div className="absolute inset-0 z-20 flex flex-col bg-[#05060f]/95 backdrop-blur-md"
      style={{ paddingTop: "max(env(safe-area-inset-top), 14px)", paddingBottom: "max(env(safe-area-inset-bottom), 14px)" }}>
      <div className="px-5">
        <div className="flex items-center justify-between">
          <button onClick={p.onBack} className="chip flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-slate-300 transition active:scale-90" aria-label="Back">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="min-w-0 px-2 text-center">
            <div className="truncate text-[9px] font-bold tracking-[0.25em] text-cyan-300/80">CHAPTER 01 · MILKY WAY</div>
            <div className="font-display text-base font-bold leading-tight text-white text-glow">SELECT STAGE</div>
          </div>
          <div className="h-10 w-10 shrink-0" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 pt-4">
        <div className="grid grid-cols-2 gap-3">
          {STAGES.map((s) => {
            // stage N is playable once you've cleared N-1 — so stage 1 is always open
            const unlocked = s.n <= p.highestCleared + 1;
            const completed = p.highestCleared >= s.n;
            const isNext = unlocked && !completed;
            const stars = p.stars[s.n] ?? 0;
            return (
              <button
                key={s.n}
                onClick={() => unlocked && p.onPlay(s.n)}
                disabled={!unlocked}
                className={`relative flex flex-col rounded-3xl border p-3.5 text-left transition ${
                  isNext
                    ? "border-cyan-300/50 bg-cyan-400/[0.07] active:scale-[0.97]"
                    : unlocked
                      ? "border-slate-700/40 bg-white/[0.03] active:scale-[0.97]"
                      : "border-slate-800/40 bg-white/[0.01] opacity-50"
                }`}
              >
                {/* planet ring header */}
                <div className="flex items-center justify-between">
                  <div
                    className={`flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-bold tracking-wider ${
                      isNext ? "bg-cyan-400/20 text-cyan-200" : "bg-slate-800/50 text-slate-300"
                    }`}
                  >
                    {s.n.toString().padStart(2, "0")}
                  </div>
                  {!unlocked ? (
                    <Lock className="h-3.5 w-3.5 text-slate-600" />
                  ) : (
                    <div className="flex items-center gap-0.5">
                      {[0, 1, 2].map((i) => (
                        <Star
                          key={i}
                          className={`h-3.5 w-3.5 ${i < stars ? "fill-amber-300 text-amber-300" : "text-slate-700"}`}
                        />
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-2 font-display text-sm font-bold tracking-wider text-white">{s.name}</div>
                <div className="mt-0.5 text-[9px] font-bold tracking-[0.2em] text-slate-500">{s.subtitle.toUpperCase()}</div>

                <div className="mt-3 flex items-center gap-1.5 text-[10px] text-slate-500">
                  <Target className="h-3 w-3 text-cyan-300/70" />
                  <span>{s.distanceTarget} LY</span>
                </div>

                {unlocked && (
                  <div
                    className={`mt-3 flex items-center gap-1.5 self-start rounded-full px-2.5 py-1 text-[9px] font-bold tracking-[0.18em] ${
                      isNext ? "bg-cyan-400/20 text-cyan-200" : "bg-cyan-400/10 text-cyan-300"
                    }`}
                  >
                    <Play className="h-2.5 w-2.5 fill-current" />
                    {isNext ? "START" : "REPLAY"}
                  </div>
                )}
              </button>
            );
          })}
        </div>
        <p className="mt-6 text-center text-[10px] tracking-wider text-slate-600">
          Clear all 10 stages to finish Chapter One
        </p>
      </div>

    </div>
  );
}
