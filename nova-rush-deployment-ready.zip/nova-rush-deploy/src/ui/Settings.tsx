import { ArrowLeft, Music, Volume2, VolumeX, BookOpen, SkipForward } from "lucide-react";
import { TRACKS } from "../game/music";

interface SettingsProps {
  visible: boolean;
  muted: boolean;
  musicMuted: boolean;
  onMute(): void;
  onMusicMute(): void;
  onBack(): void;
  onHow(): void;
  trackIndex: number;
  onTrack(i: number): void;
}

export function Settings({ visible, muted, musicMuted, onMute, onMusicMute, onBack, onHow, trackIndex, onTrack }: SettingsProps) {
  if (!visible) return null;
  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-[#05060f]/95 backdrop-blur-md"
      style={{ paddingTop: "max(env(safe-area-inset-top), 14px)", paddingBottom: "max(env(safe-area-inset-bottom), 14px)" }}>
      <div className="px-5">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="chip flex h-10 w-10 items-center justify-center rounded-full text-slate-300 transition active:scale-90" aria-label="Back">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="text-center">
            <div className="text-[10px] font-bold tracking-[0.4em] text-cyan-300/80">SETTINGS</div>
            <div className="font-display text-lg font-bold text-white text-glow">PREFERENCES</div>
          </div>
          <div className="h-10 w-10" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5">
        <Section title="AUDIO">
          <Row icon={muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />} label="Sound Effects" value={muted ? "OFF" : "ON"} on={!muted} onClick={onMute} />
          <Row icon={<Music className="h-4 w-4" />} label="Music" value={musicMuted ? "OFF" : "ON"} on={!musicMuted} onClick={onMusicMute} />
        </Section>

        <Section title="SOUNDTRACK">
          <div className="space-y-2">
            {TRACKS.map((tr, i) => (
              <button
                key={tr.id}
                onClick={() => onTrack(i)}
                className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 transition active:scale-[0.98] ${
                  i === trackIndex
                    ? "border-cyan-300/50 bg-cyan-400/10"
                    : "border-slate-700/40 bg-white/[0.02]"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`flex h-8 w-8 items-center justify-center rounded-xl ${i === trackIndex ? "bg-cyan-400/20 text-cyan-300" : "bg-slate-800 text-slate-500"}`}>
                    {i === trackIndex ? <Music className="h-4 w-4" /> : <SkipForward className="h-4 w-4" />}
                  </div>
                  <div className="text-left">
                    <div className={`text-sm font-bold ${i === trackIndex ? "text-cyan-100" : "text-slate-200"}`}>{tr.name}</div>
                    <div className="text-[10px] tracking-wider text-slate-500">{tr.bpm} BPM</div>
                  </div>
                </div>
                {i === trackIndex && (
                  <span className="text-[9px] font-bold tracking-[0.2em] text-cyan-300">PLAYING</span>
                )}
              </button>
            ))}
          </div>
        </Section>

        <Section title="LEARN">
          <Row icon={<BookOpen className="h-4 w-4" />} label="How to play" value="OPEN" on={true} onClick={onHow} />
        </Section>

        <div className="mt-6 text-center text-[10px] leading-relaxed tracking-wider text-slate-600">
          Nova Rush · Chapter One · The Milky Way
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-5">
      <div className="mb-2 text-[10px] font-bold tracking-[0.3em] text-cyan-300/70">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Row({ icon, label, value, on, onClick }: { icon: React.ReactNode; label: string; value: string; on: boolean; onClick(): void }) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center justify-between rounded-2xl border border-slate-700/40 bg-white/[0.02] px-4 py-3 transition active:scale-[0.98]"
    >
      <div className="flex items-center gap-3">
        <div className={`flex h-8 w-8 items-center justify-center rounded-xl ${on ? "bg-cyan-400/15 text-cyan-300" : "bg-slate-800 text-slate-500"}`}>{icon}</div>
        <div className="text-sm font-bold text-slate-100">{label}</div>
      </div>
      <div className={`text-[10px] font-bold tracking-[0.2em] ${on ? "text-cyan-300" : "text-slate-500"}`}>{value}</div>
    </button>
  );
}

