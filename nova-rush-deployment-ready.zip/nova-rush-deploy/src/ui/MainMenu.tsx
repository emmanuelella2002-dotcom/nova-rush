import { BookOpen, Gem, Infinity, Layers, Play, Settings as SettingsIcon, ShoppingBag, Star, Trophy } from "lucide-react";
import { BALL_DEFS, type BallId } from "../game/balls";

interface MainMenuProps {
  best: number;
  credits: number;
  totalStars: number;
  owned: BallId[];
  equipped: BallId;
  muted: boolean;
  musicMuted: boolean;
  visible: boolean;
  onLaunch(): void;
  onChapters(): void;
  onSettings(): void;
  onShop(): void;
  onStory(): void;
  onSurvival(): void;
  onBuy(id: BallId): void;
  onEquip(id: BallId): void;
  onMute(): void;
  onMusicMute(): void;
}

export function MainMenu(p: MainMenuProps) {
  if (!p.visible) return null;

  return (
    <div
      className="absolute inset-0 z-20 flex flex-col"
      style={{
        paddingTop: "max(env(safe-area-inset-top), 14px)",
        paddingBottom: "max(env(safe-area-inset-bottom), 14px)",
      }}
    >
      {/* top status row */}
      <div className="px-5">
        <div className="grid grid-cols-3 gap-2">
          <div className="chip flex items-center gap-2 rounded-2xl px-3 py-2.5">
            <Trophy className="h-3.5 w-3.5 text-amber-300" />
            <div>
              <div className="text-[8px] font-bold tracking-[0.2em] text-slate-500">BEST</div>
              <div className="font-display text-sm font-bold text-amber-200 tabular-nums">{p.best.toLocaleString()}</div>
            </div>
          </div>
          <div className="chip flex items-center gap-2 rounded-2xl px-3 py-2.5">
            <Star className="h-3.5 w-3.5 text-amber-300" />
            <div>
              <div className="text-[8px] font-bold tracking-[0.2em] text-slate-500">STARS</div>
              <div className="font-display text-sm font-bold text-amber-200 tabular-nums">{p.totalStars} <span className="text-[9px] text-slate-500">/ 30</span></div>
            </div>
          </div>
          <div className="chip flex items-center gap-2 rounded-2xl px-3 py-2.5">
            <Gem className="h-3.5 w-3.5 text-cyan-300" />
            <div>
              <div className="text-[8px] font-bold tracking-[0.2em] text-slate-500">SHARDS</div>
              <div className="font-display text-sm font-bold text-cyan-200 tabular-nums">{p.credits.toLocaleString()}</div>
            </div>
          </div>
        </div>
      </div>

      {/* hero title */}
      <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
        <div className="animate-rise">
          <div className="mb-2 flex items-center justify-center gap-2 text-[10px] font-bold tracking-[0.4em] text-cyan-300/80">
            <span>CHAPTER ONE</span>
          </div>
          <h1 className="font-display font-extrabold leading-[0.92]">
            <span className="block text-[18vw] text-white text-glow animate-flicker sm:text-7xl">NOVA</span>
            <span
              className="block bg-gradient-to-r from-cyan-300 via-violet-400 to-pink-400 bg-clip-text text-[18vw] text-transparent sm:text-7xl"
              style={{ filter: "drop-shadow(0 0 26px rgba(168,85,247,0.5))" }}
            >
              RUSH
            </span>
          </h1>
          <p className="mx-auto mt-3 max-w-64 text-[12px] leading-relaxed text-slate-400">
            A comet looking for a sound the Milky Way forgot. Ten worlds, ten bosses, one star.
          </p>
        </div>
      </div>

      {/* 3x2 menu grid — clean, equal-weight, no shabby overflow */}
      <div className="px-5 pb-2">
        <button
          onClick={p.onLaunch}
          className="btn-launch pointer-events-auto mb-3 flex w-full items-center justify-center gap-3 rounded-2xl py-4 font-display text-base font-bold tracking-[0.25em] text-[#05060f]"
        >
          <Play className="h-5 w-5" strokeWidth={2.4} fill="currentColor" />
          PLAY
        </button>

        <div className="grid grid-cols-3 gap-2">
          <MenuButton icon={<Layers className="h-4 w-4" />} label="CHAPTERS" onClick={p.onChapters} tone="violet" />
          <MenuButton icon={<Infinity className="h-4 w-4" />} label="SURVIVAL" onClick={p.onSurvival} tone="emerald" />
          <MenuButton icon={<ShoppingBag className="h-4 w-4" />} label="SHOP" onClick={p.onShop} tone="cyan" />
          <MenuButton icon={<BookOpen className="h-4 w-4" />} label="STORY" onClick={p.onStory} tone="amber" />
          <MenuButton icon={<SettingsIcon className="h-4 w-4" />} label="SETTINGS" onClick={p.onSettings} tone="slate" />
          <MenuButton
            icon={p.musicMuted ? <span className="text-[10px]">♪×</span> : <span className="text-[10px]">♪</span>}
            label={p.musicMuted ? "MUSIC" : "MUSIC"}
            onClick={p.onMusicMute}
            tone={p.musicMuted ? "slate" : "violet"}
          />
        </div>
      </div>
    </div>
  );
}

function MenuButton({
  icon, label, onClick, tone, badge,
}: {
  icon: React.ReactNode;
  label: string;
  onClick(): void;
  tone: "violet" | "cyan" | "emerald" | "amber" | "slate";
  badge?: string;
}) {
  const toneCls: Record<string, string> = {
    violet: "text-violet-300",
    cyan: "text-cyan-300",
    emerald: "text-emerald-300",
    amber: "text-amber-300",
    slate: "text-slate-300",
  };
  return (
    <button
      onClick={onClick}
      className="pointer-events-auto flex flex-col items-center justify-center gap-1 rounded-2xl border border-slate-700/40 bg-white/[0.02] py-3 transition active:scale-95"
    >
      <div className={`flex items-center gap-1 ${toneCls[tone]}`}>
        {icon}
        {badge && <span className="text-[8px] font-bold tracking-[0.15em] opacity-70">{badge}</span>}
      </div>
      <div className="text-[9px] font-bold tracking-[0.18em] text-slate-400">{label}</div>
    </button>
  );
}

/* re-export the BALL_DEFS for the shop sheet — kept here for convenience */
export { BALL_DEFS };
