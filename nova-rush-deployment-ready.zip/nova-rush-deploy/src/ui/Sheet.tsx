import {
  Coins,
  Gem,
  Hand,
  Sparkles,
  Target,
  TriangleAlert,
  X,
} from "lucide-react";

export type SheetKind = "how" | null;

interface SheetProps {
  kind: SheetKind;
  onClose(): void;
}

export function Sheet({ kind, onClose }: SheetProps) {
  if (!kind) return null;
  return (
    <div className="absolute inset-0 z-40" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-[#02030a]/70 backdrop-blur-sm" onClick={onClose} />
      <div
        className="animate-rise absolute inset-x-0 bottom-0 mx-auto max-h-[86dvh] w-full max-w-md overflow-y-auto rounded-t-[2rem] border-t border-slate-700/40 bg-[#0b0e20]/95 px-6 pb-10 pt-3 backdrop-blur-xl"
        style={{ paddingBottom: "max(env(safe-area-inset-bottom), 2.5rem)" }}
      >
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-600/60" />
        <button
          onClick={onClose}
          aria-label="Close"
          className="chip absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full text-slate-400 transition active:scale-90"
        >
          <X className="h-4 w-4" />
        </button>
        <HowTo />
      </div>
    </div>
  );
}

/* ------------------------------ HOW TO PLAY ------------------------------ */

function HowTo() {
  const rows = [
    {
      icon: <Hand className="h-5 w-5 text-cyan-300" />,
      title: "Drag anywhere",
      body: "Your ship flies just ahead of your thumb — your finger never covers the action.",
    },
    {
      icon: <Target className="h-5 w-5 text-amber-300" />,
      title: "Hit the stage target",
      body: "Fill the STAGE bar to clear the level and bank a bonus. Cleared stages push you deeper — and faster.",
    },
    {
      icon: <TriangleAlert className="h-5 w-5 text-rose-400" />,
      title: "Dodge the neon",
      body: "Rocks drift, red darts hunt. One clean hit ends the run — unless you're carrying a spare heart.",
    },
    {
      icon: <Gem className="h-5 w-5 text-violet-300" />,
      title: "Chain the shards",
      body: "Each crystal increases your score reward. Keep collecting while you dodge incoming fire.",
    },
    {
      icon: <Sparkles className="h-5 w-5 text-pink-300" />,
      title: "Power orbs",
      body: "Amber ring = shield · blue clock = slow-mo · pink ×2 = double score · red heart = extra life.",
    },
    {
      icon: <Coins className="h-5 w-5 text-amber-200" />,
      title: "Shards buy balls",
      body: "Boss victories award shards. Spend them in the Shop on new comet characters.",
    },
  ];
  return (
    <div>
      <h2 className="font-display text-xl font-bold text-white text-glow">HOW TO FLY</h2>
      <p className="mt-1 text-xs text-slate-400">Thirty seconds to learn. A lifetime to master.</p>
      <div className="mt-5 space-y-4">
        {rows.map((r) => (
          <div key={r.title} className="flex gap-4">
            <div className="chip mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl">
              {r.icon}
            </div>
            <div>
              <div className="text-sm font-bold text-slate-100">{r.title}</div>
              <div className="mt-0.5 text-xs leading-relaxed text-slate-400">{r.body}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

