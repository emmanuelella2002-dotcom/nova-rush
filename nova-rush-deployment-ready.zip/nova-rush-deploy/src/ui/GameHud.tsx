import { Heart, Pause, Target } from "lucide-react";
import type { PowerState } from "../game/engine";

interface GameHudProps {
  visible: boolean;
  score: number;
  lives: number;
  ultReady: boolean;
  ultActive: boolean;
  gunCharges: number;
  powers: PowerState;
  distance: number;
  distanceTarget: number;
  bossName: string;
  weaponName?: string;
  /** weapons only arm after the first weapon orb is collected */
  weaponArmed?: boolean;
  /** seconds of weapon uptime remaining (of 10) */
  weaponTime?: number;
  /** endless survival mode */
  survival?: boolean;
  wave?: number;
  copilotTime?: number;
  squadronTime?: number;
  /** 0..1 Supernova recharge progress */
  ultCharge?: number;
  onPause(): void;

  onUlt(): void;
}


/**
 * In-game HUD.
 *
 * Deliberately minimal: score, lives, the distance run to the boss, and the
 * Supernova button. Ability timers are intentionally NOT displayed — every
 * power-up still works and still expires on its own timer, the player simply
 * reads its state from the game world (shield ring, magnet pull, drones
 * flying beside them) rather than from a countdown widget.
 */
export function GameHud(p: GameHudProps) {
  if (!p.visible) return null;
  const distFrac = Math.max(0, Math.min(1, p.distance / p.distanceTarget));

  return (
    <div
      className="pointer-events-none absolute inset-0 z-20 transition-opacity duration-300"
      style={{ paddingTop: "max(env(safe-area-inset-top), 10px)" }}
    >
      {/* top centre — survival wave, or the light-year run to the boss */}
      {p.survival ? (
        <div className="pointer-events-none absolute inset-x-0 top-3 flex flex-col items-center">
          <div className="text-[9px] font-bold tracking-[0.3em] text-amber-300/80">ENDLESS SURVIVAL</div>
          <div className="font-display text-xl font-extrabold leading-tight text-white text-glow">
            WAVE {p.wave ?? 1}
          </div>
        </div>
      ) : (
      <div className="pointer-events-none absolute inset-x-0 top-3 flex flex-col items-center">
        <div className="flex items-center gap-1.5 text-[9px] font-bold tracking-[0.3em] text-slate-400">
          <Target className="h-3 w-3 text-cyan-300" />
          <span>
            {Math.min(p.distance, p.distanceTarget).toFixed(1)} / {p.distanceTarget}{" "}
            <span className="text-slate-500">LY</span>
          </span>
        </div>
        <div className="mt-1 h-1 w-44 overflow-hidden rounded-full bg-white/10">
          <div
            className="combo-drain h-full rounded-full bg-gradient-to-r from-cyan-300 via-violet-300 to-pink-300"
            style={{ width: `${distFrac * 100}%` }}
          />
        </div>
        <div className="mt-0.5 text-[8px] font-bold tracking-[0.25em] text-slate-500">
          NEXT: <span className="text-slate-300">{p.bossName}</span>
        </div>
      </div>
      )}

      {/* top-left score + lives */}
      <div className="absolute left-4 top-12">
        <div className="text-[10px] font-semibold tracking-[0.3em] text-slate-400">SCORE</div>
        <div key={p.score} className="score-pop font-display text-3xl font-bold text-white text-glow tabular-nums">
          {p.score.toLocaleString()}
        </div>
        <div className="mt-1 flex items-center gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Heart
              key={i}
              className={`h-3.5 w-3.5 transition-opacity ${
                i < p.lives ? "fill-rose-400 text-rose-400" : "fill-rose-950/30 text-rose-950/40"
              }`}
            />
          ))}
        </div>
      </div>

      {/* top-right pause */}
      <div className="absolute right-4 top-12">
        <button
          onClick={p.onPause}
          aria-label="Pause"
          className="chip pointer-events-auto flex h-10 w-10 items-center justify-center rounded-full text-slate-300 transition active:scale-90"
        >
          <Pause className="h-4 w-4" />
        </button>
      </div>

      {/* bottom bar — SUPERNOVA only. Weapons are fully automatic. */}
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex items-end justify-between px-3"
        style={{ paddingBottom: "max(env(safe-area-inset-bottom), 14px)" }}
      >
        {/* left corner kept clear for steering — no ability readouts */}
        <div className="pointer-events-none pb-2" />

        {/* SUPERNOVA */}
        <div className="pointer-events-auto">
          <button
            onPointerDown={(e) => { e.stopPropagation(); p.onUlt(); }}
            onClick={(e) => { e.stopPropagation(); p.onUlt(); }}
            disabled={!p.ultReady && !p.ultActive}
            aria-label="Supernova"
            className={`relative flex h-[72px] w-[72px] items-center justify-center rounded-full border-2 transition active:scale-90 ${
              p.ultActive
                ? "border-white bg-gradient-to-br from-amber-200 via-orange-400 to-fuchsia-500 text-white"
                : p.ultReady
                  ? "animate-pulse-ring border-amber-300 bg-gradient-to-br from-amber-300/30 to-orange-500/20 text-amber-100"
                  : "border-slate-700/60 bg-slate-900/60 text-slate-500"
            }`}
          >
            {/* radial recharge gauge */}
            {!p.ultReady && !p.ultActive && (
              <svg viewBox="0 0 72 72" className="pointer-events-none absolute inset-0 -rotate-90">
                <circle cx="36" cy="36" r="32" fill="none" stroke="rgba(148,163,184,0.18)" strokeWidth="4" />
                <circle
                  cx="36" cy="36" r="32" fill="none"
                  stroke="url(#snGrad)" strokeWidth="4" strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 32}`}
                  strokeDashoffset={`${2 * Math.PI * 32 * (1 - (p.ultCharge ?? 0))}`}
                  style={{ transition: "stroke-dashoffset 120ms linear" }}
                />
                <defs>
                  <linearGradient id="snGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#fcd34d" />
                    <stop offset="100%" stopColor="#fb7185" />
                  </linearGradient>
                </defs>
              </svg>
            )}
            {/* starburst icon */}
            <svg viewBox="0 0 48 48" className="h-9 w-9" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <circle cx="24" cy="24" r="6.5" fill={p.ultReady || p.ultActive ? "currentColor" : "none"} />
              {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
                <line
                  key={deg}
                  x1={24 + Math.cos((deg * Math.PI) / 180) * 11}
                  y1={24 + Math.sin((deg * Math.PI) / 180) * 11}
                  x2={24 + Math.cos((deg * Math.PI) / 180) * (deg % 90 === 0 ? 20 : 16)}
                  y2={24 + Math.sin((deg * Math.PI) / 180) * (deg % 90 === 0 ? 20 : 16)}
                />
              ))}
            </svg>
            <span
              className={`absolute -bottom-[14px] whitespace-nowrap text-[8px] font-bold tracking-[0.2em] ${
                p.ultReady || p.ultActive ? "text-amber-200" : "text-slate-600"
              }`}
            >
              SUPERNOVA
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
