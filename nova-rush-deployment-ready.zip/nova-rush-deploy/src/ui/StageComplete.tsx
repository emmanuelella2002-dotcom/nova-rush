import { Sparkles } from "lucide-react";
import type { StarGrade } from "../game/engine";

interface StageCompleteProps {
  data: { stageN: number; grade: StarGrade; key: number } | null;
  onNext(): void;
}

const STAGE_NAMES = [
  "",
  "MERCURY",
  "VENUS",
  "EARTH",
  "MARS",
  "JUPITER",
  "SATURN",
  "URANUS",
  "NEPTUNE",
  "PLUTO",
  "THE SUN",
];

export function StageComplete({ data, onNext }: StageCompleteProps) {
  if (!data) return null;
  const stars = data.grade.stars;
  return (
    <div
      key={data.key}
      className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-[#05060f]/80 px-6 backdrop-blur-md"
    >
      <div className="animate-rise flex max-w-xs flex-col items-center text-center">
        <div className="text-[10px] font-bold tracking-[0.4em] text-amber-300">STAGE CLEAR</div>
        <div className="mt-1 font-display text-3xl font-extrabold text-white text-glow">
          {STAGE_NAMES[data.stageN] ?? "STAGE"}
        </div>
        <div className="mt-4 flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <Sparkles
              key={i}
              className={`h-9 w-9 ${i < stars ? "fill-amber-300 text-amber-300" : "text-slate-700"}`}
              strokeWidth={1.5}
            />
          ))}
        </div>
        <div className="mt-2 text-[11px] font-bold tracking-[0.25em] text-slate-300">
          {stars === 3 ? "PERFECT RUN" : stars === 2 ? "GREAT WORK" : stars === 1 ? "CLEARED" : "TRAINING RUN"}
        </div>
        <div className="mt-1 text-[10px] tracking-wider text-slate-500">
          Deaths this stage: {data.grade.deaths}
        </div>
        <button
          onClick={onNext}
          className="pointer-events-auto btn-launch mt-5 w-full rounded-2xl py-3 font-display text-[11px] font-bold tracking-[0.2em] text-[#05060f]"
        >
          BACK TO STAGES
        </button>
      </div>
    </div>
  );
}
