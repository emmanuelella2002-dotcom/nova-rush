import { ArrowLeft, Lock, Star } from "lucide-react";
import { CHAPTERS, isChapterUnlocked } from "../game/chapters";

interface ChapterSelectProps {
  visible: boolean;
  totalStars: number;
  onBack(): void;
  onChapter(n: number): void;
}

export function ChapterSelect({ visible, totalStars, onBack, onChapter }: ChapterSelectProps) {
  if (!visible) return null;
  return (
    <div className="absolute inset-0 z-20 flex flex-col bg-[#05060f]/95 backdrop-blur-md"
      style={{ paddingTop: "max(env(safe-area-inset-top), 14px)", paddingBottom: "max(env(safe-area-inset-bottom), 14px)" }}>
      <div className="px-5">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="chip flex h-10 w-10 items-center justify-center rounded-full text-slate-300 transition active:scale-90" aria-label="Back">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="text-center">
            <div className="text-[10px] font-bold tracking-[0.4em] text-cyan-300/80">SELECT</div>
            <div className="font-display text-lg font-bold text-white text-glow">CHAPTERS</div>
          </div>
          <div className="chip flex items-center gap-1.5 rounded-full px-3 py-1.5">
            <Star className="h-3.5 w-3.5 text-amber-300" />
            <span className="font-display text-xs font-bold text-amber-200 tabular-nums">{totalStars}</span>
            <span className="text-[9px] text-slate-500">/ 270</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5">
        <div className="grid grid-cols-1 gap-3">
          {CHAPTERS.map((ch) => {
            const unlocked = isChapterUnlocked(ch.n, totalStars);
            return (
              <button
                key={ch.n}
                onClick={() => unlocked && onChapter(ch.n)}
                disabled={!unlocked}
                className={`relative flex items-center gap-4 rounded-3xl border p-4 text-left transition ${
                  unlocked
                    ? "border-slate-700/40 bg-white/[0.02] active:scale-[0.98]"
                    : "border-slate-800/40 bg-white/[0.01] opacity-60"
                }`}
              >
                <div
                  className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl font-display text-2xl font-extrabold ${
                    unlocked
                      ? "bg-gradient-to-br from-cyan-400/20 to-violet-500/30 text-white"
                      : "bg-slate-800/40 text-slate-500"
                  }`}
                >
                  {unlocked ? `0${ch.n}` : <Lock className="h-5 w-5" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className={`font-display text-base font-bold tracking-wider ${unlocked ? "text-white" : "text-slate-500"}`}>{ch.title}</span>
                  </div>
                  <div className={`mt-0.5 text-[10px] font-bold tracking-[0.2em] ${unlocked ? "text-cyan-300/70" : "text-slate-600"}`}>{ch.subtitle.toUpperCase()}</div>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{ch.body}</p>
                  {!unlocked && (
                    <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-slate-800/60 px-2 py-0.5 text-[9px] font-bold tracking-[0.15em] text-slate-500">
                      <Lock className="h-2.5 w-2.5" />
                      {ch.unlock.stars} STARS TO UNLOCK
                    </div>
                  )}
                </div>
                {ch.n >= 2 && (
                  <div className="absolute right-3 top-3 rounded-full bg-amber-500/15 px-2 py-0.5 text-[8px] font-bold tracking-[0.2em] text-amber-300">
                    COMING SOON
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
