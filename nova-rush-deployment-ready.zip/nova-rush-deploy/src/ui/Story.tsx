import { useEffect, useRef } from "react";
import { BookOpen, X } from "lucide-react";
import { STORY } from "../game/story";

interface StoryProps {
  open: boolean;
  onClose(): void;
}

export function Story({ open, onClose }: StoryProps) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (open) ref.current?.scrollTo({ top: 0 });
  }, [open]);
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-50" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-[#02030a]/85 backdrop-blur-md" />
      <div className="animate-rise absolute inset-x-3 top-[3%] bottom-[3%] mx-auto flex max-h-[94dvh] w-full max-w-md flex-col overflow-hidden rounded-[2rem] border border-slate-700/40 bg-[#0b0e20]/95 backdrop-blur-xl">
        <button
          onClick={onClose}
          aria-label="Close story"
          className="chip absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full text-slate-300 transition active:scale-90"
        >
          <X className="h-4 w-4" />
        </button>
        <div ref={ref} className="overflow-y-auto px-7 pb-6 pt-10" style={{ paddingTop: "max(env(safe-area-inset-top), 2.5rem)" }}>
          <div className="flex flex-col items-center">
            <div className="chip flex items-center gap-2 rounded-full px-3.5 py-2">
              <BookOpen className="h-3.5 w-3.5 text-cyan-300" />
              <span className="text-[10px] font-bold tracking-[0.3em] text-slate-300">PROLOGUE</span>
            </div>
            <h1 className="mt-4 font-display text-5xl font-extrabold leading-none text-white text-glow">
              {STORY.title}
            </h1>
            <div className="mt-2 text-[11px] font-bold tracking-[0.35em] text-cyan-300/80">
              {STORY.subtitle}
            </div>
          </div>

          <div className="mt-7 space-y-4">
            {STORY.body.map((p, i) => (
              <p
                key={i}
                className="text-[14px] leading-[1.65] text-slate-200/90 first-letter:font-display first-letter:text-2xl first-letter:font-bold first-letter:text-cyan-300 first-letter:mr-1"
              >
                {p}
              </p>
            ))}
          </div>

          <div className="my-7 h-px bg-gradient-to-r from-transparent via-cyan-300/40 to-transparent" />

          <div className="rounded-2xl border border-cyan-300/15 bg-cyan-400/5 p-4">
            <div className="text-[10px] font-bold tracking-[0.3em] text-cyan-300">YOUR MISSION</div>
            <p className="mt-1.5 text-[12px] leading-relaxed text-slate-300">
              Clear all 10 stages. Earn three stars on each boss. Bank your shards. The further you go, the closer
              Nova gets to the sound of home.
            </p>
          </div>
        </div>
        <div
          className="border-t border-slate-700/40 bg-[#0b0e20]/95 p-4"
          style={{ paddingBottom: "max(env(safe-area-inset-bottom), 1rem)" }}
        >
          <button
            onClick={onClose}
            className="btn-launch w-full rounded-2xl py-3.5 font-display text-sm font-bold tracking-[0.25em] text-[#05060f]"
          >
            BEGIN THE SEARCH
          </button>
        </div>
      </div>
    </div>
  );
}
