import { Gem, Home, RotateCcw, Share2, ShoppingBag, Sparkles } from "lucide-react";

export interface RunSummary {
  score: number;
  best: number;
  isNewBest: boolean;
  stageClears: number;
  livesUsed: number;
  banked: number;
  totalCredits: number;
  grade: { stars: number; passed: boolean; finalScore: number; deaths: number };
}

interface GameOverProps {
  visible: boolean;
  run: RunSummary;
  canShare: boolean;
  onRetry(): void;
  onMenu(): void;
  onShare(): void;
  onShop(): void;
}

export function GameOver({ visible, run, canShare, onRetry, onMenu, onShare, onShop }: GameOverProps) {
  if (!visible) return null;
  const stageBonus = run.stageClears * 25;
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center px-6">
      <div className="animate-rise glass w-full max-w-xs rounded-3xl p-7 text-center">
        <div className="text-[10px] font-bold tracking-[0.4em] text-pink-400">SIGNAL LOST</div>

        {run.isNewBest && (
          <div className="mx-auto mt-3 flex w-fit items-center gap-1.5 rounded-full border border-amber-300/30 bg-amber-400/10 px-3 py-1 text-[10px] font-bold tracking-[0.2em] text-amber-300">
            <Sparkles className="h-3 w-3" />
            NEW BEST
          </div>
        )}

        <div className="mt-4 font-display text-6xl font-extrabold text-white text-glow tabular-nums">
          {run.score.toLocaleString()}
        </div>
        <div className="mt-2 text-[11px] font-semibold tracking-[0.25em] text-slate-400">
          BEST <span className="text-slate-200">{run.best.toLocaleString()}</span>
          {run.stageClears > 0 && (
            <>
              <span className="mx-2 text-slate-600">·</span>
              <span className="text-cyan-300">{run.stageClears} STAGE{run.stageClears > 1 ? "S" : ""} CLEARED</span>
            </>
          )}
        </div>

        {/* shard bank breakdown */}
        <div className="mt-5 space-y-1.5 rounded-2xl border border-slate-700/40 bg-white/[0.03] px-4 py-3 text-left">
          <div className="flex justify-between text-[11px] font-semibold text-slate-400">
            <span>Run score</span>
            <span className="tabular-nums text-slate-200">{run.score.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-[11px] font-semibold text-slate-400">
            <span>Stage bonus ×{run.stageClears}</span>
            <span className="tabular-nums text-slate-200">+{stageBonus.toLocaleString()}</span>
          </div>
          <div className="flex justify-between border-t border-slate-700/40 pt-1.5 text-[11px] font-bold">
            <span className="flex items-center gap-1 text-cyan-300">
              <Gem className="h-3 w-3" /> Banked
            </span>
            <span className="tabular-nums text-cyan-200">+{run.banked.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-[10px] font-semibold text-slate-500">
            <span>Total shards</span>
            <span className="tabular-nums">{run.totalCredits.toLocaleString()}</span>
          </div>
        </div>

        <button
          onClick={onRetry}
          className="btn-launch mt-5 flex w-full items-center justify-center gap-2 rounded-2xl py-4 font-display text-sm font-bold tracking-[0.25em] text-[#05060f]"
        >
          <RotateCcw className="h-4 w-4" strokeWidth={2.5} />
          RETRY
        </button>

        <div className="mt-3 flex gap-2">
          <button
            onClick={onShop}
            className="chip flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-3 text-[10px] font-bold tracking-[0.12em] text-violet-300 transition active:scale-95"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            SHOP
          </button>
          {canShare && (
            <button
              onClick={onShare}
              className="chip flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-3 text-[10px] font-bold tracking-[0.12em] text-slate-200 transition active:scale-95"
            >
              <Share2 className="h-3.5 w-3.5" />
              SHARE
            </button>
          )}
          <button
            onClick={onMenu}
            className="chip flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-3 text-[10px] font-bold tracking-[0.12em] text-slate-200 transition active:scale-95"
          >
            <Home className="h-3.5 w-3.5" />
            MENU
          </button>
        </div>
      </div>
    </div>
  );
}
