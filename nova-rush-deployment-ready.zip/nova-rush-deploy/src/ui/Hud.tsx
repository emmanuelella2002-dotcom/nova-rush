import { Music, Volume2, VolumeX } from "lucide-react";

interface PauseProps {
  visible: boolean;
  muted: boolean;
  musicMuted: boolean;
  onResume(): void;
  onRestart(): void;
  onMenu(): void;
  onMute(): void;
  onMusicMute(): void;
}

export function PauseOverlay({
  visible,
  muted,
  musicMuted,
  onResume,
  onRestart,
  onMenu,
  onMute,
  onMusicMute,
}: PauseProps) {
  if (!visible) return null;
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#05060f]/70 backdrop-blur-md">
      <div className="animate-rise glass w-[80%] max-w-xs rounded-3xl p-7 text-center">
        <div className="font-display text-2xl font-bold tracking-widest text-white text-glow">PAUSED</div>
        <p className="mt-1 text-xs text-slate-400">The void can wait.</p>
        <button
          onClick={onResume}
          className="btn-launch mt-6 w-full rounded-2xl py-3.5 font-display text-sm font-bold tracking-[0.2em] text-[#05060f]"
        >
          RESUME
        </button>
        <div className="mt-3 flex gap-3">
          <button
            onClick={onRestart}
            className="chip flex-1 rounded-2xl py-3 text-xs font-bold tracking-[0.15em] text-slate-200 transition active:scale-95"
          >
            RESTART
          </button>
          <button
            onClick={onMenu}
            className="chip flex-1 rounded-2xl py-3 text-xs font-bold tracking-[0.15em] text-slate-200 transition active:scale-95"
          >
            EXIT
          </button>
        </div>
        <div className="mt-4 flex gap-3">
          <button
            onClick={onMute}
            className="chip flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-2.5 text-[10px] font-bold tracking-[0.12em] text-slate-300 transition active:scale-95"
          >
            {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
            SFX {muted ? "OFF" : "ON"}
          </button>
          <button
            onClick={onMusicMute}
            className="chip flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-2.5 text-[10px] font-bold tracking-[0.12em] text-slate-300 transition active:scale-95"
          >
            <Music className={`h-3.5 w-3.5 ${musicMuted ? "opacity-40" : ""}`} />
            MUSIC {musicMuted ? "OFF" : "ON"}
          </button>
        </div>
      </div>
    </div>
  );
}
