import { useEffect, useRef } from "react";
import { paintCometPortrait, type CometId } from "../game/cometArt";

interface CometPreviewProps {
  id: CometId;
  width?: number;
  height?: number;
  className?: string;
}

/**
 * Canvas-rendered comet portrait — the exact same art the engine flies,
 * so what you see in the shop is what you get in the void.
 */
export function CometPreview({ id, width = 108, height = 64, className }: CometPreviewProps) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    const art = paintCometPortrait(id, Math.round(width * dpr), Math.round(height * dpr));
    ctx.drawImage(art, 0, 0, width, height);
  }, [id, width, height]);

  return (
    <canvas
      ref={ref}
      style={{ width, height }}
      className={className}
      aria-label={`${id} comet preview`}
    />
  );
}
