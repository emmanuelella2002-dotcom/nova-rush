interface StageIntroProps {
  data: { n: number; name: string; subtitle: string; target: number; key: number } | null;
  onDismiss(): void;
}

export function StageIntro({ data }: StageIntroProps) {
  if (!data) return null;
  return (
    <div
      key={data.key}
      className="pointer-events-none absolute inset-0 z-30 flex flex-col items-center justify-center"
    >
      <div className="animate-rise flex flex-col items-center">
        <div className="text-[10px] font-bold tracking-[0.4em] text-cyan-300">
          STAGE {data.n.toString().padStart(2, "0")} / 10
        </div>
        <div
          className="mt-2 font-display text-6xl font-extrabold text-white text-glow"
          style={{ filter: "drop-shadow(0 0 30px rgba(255,255,255,0.25))" }}
        >
          {data.name}
        </div>
        <div className="mt-2 max-w-xs text-center text-[12px] italic text-slate-400">
          {data.subtitle}
        </div>
        <div className="mt-5 flex items-center gap-2 text-[10px] font-semibold tracking-[0.2em] text-slate-500">
          <span className="h-px w-8 bg-slate-700" />
          REACH {data.target} LIGHT·YEARS
          <span className="h-px w-8 bg-slate-700" />
        </div>
      </div>
    </div>
  );
}
