interface BossIntroProps {
  data: { name: string; title: string; body: string; hint: string; hp: number; hpMax: number; key: number } | null;
}

export function BossIntro({ data }: BossIntroProps) {
  if (!data) return null;
  return (
    <div
      key={data.key}
      className="pointer-events-none absolute inset-0 z-30 flex flex-col items-center justify-center px-6"
    >
      <div className="animate-rise flex max-w-sm flex-col items-center text-center">
        <div className="text-[10px] font-bold tracking-[0.4em] text-rose-300">⚠ BOSS ENCOUNTER</div>
        <div
          className="mt-2 font-display text-5xl font-extrabold text-white text-glow"
          style={{ filter: "drop-shadow(0 0 30px rgba(244,63,94,0.4))" }}
        >
          {data.name}
        </div>
        <div className="mt-1 text-[11px] font-bold tracking-[0.25em] text-rose-200/80">
          {data.title}
        </div>
        <p className="mt-3 text-[10px] italic tracking-wider text-amber-300/80">{data.hint}</p>
      </div>
    </div>
  );
}
