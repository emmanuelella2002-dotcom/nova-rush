/* Nova Rush — chapter 1: "The Milky Way" */
export const STORY = {
  title: "NOVA",
  subtitle: "Chapter One — The Milky Way",
  body: [
    "Once, Nova was the fastest comet in a galaxy that no one in this part of the sky remembers.",
    "She was born from the cold heart of a dwarf spiral on the other side of the universe, where the stars are few and the dark between them is older than words.",
    "One morning — though nobody kept track of mornings, out there — a young star in her home system began to die. A slow red collapse. The kind that turns everything it has ever loved into a long goodbye.",
    "Nova could feel the light going out. The orbits were thinning. Her cousins — the other comets, the dust rings, the small moons — were already drifting, lost, indifferent.",
    "She did the only thing a comet can do. She ran.",
    "For uncounted years she crossed the absolute dark. She passed through nothing. She passed through things worse than nothing. Once, a red dwarf tried to swallow her. She burned through its atmosphere and kept going.",
    "When the light finally came back, it was the wrong light — too yellow, too warm, too crowded. A billion stars. A spiral arm. A name whispered by every radio she'd flown past on the way in.",
    "The Milky Way.",
    "She doesn't belong here. The pull is wrong. The dust is wrong. The suns sing in a key she doesn't recognize. But here is the strange part — for the first time since her home went dark, the universe feels alive again.",
    "So Nova does what she's always done. She drifts. She weaves. She tells herself that somewhere in this galaxy there must be a star that hums in the same old frequency — the song her mother used to sing before the collapse.",
    "That is the search. The Milky Way has ten worlds to cross before its centre. Mercury, Venus, Earth — the one that almost looked right — Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, and the Sun itself, beating at the heart of everything.",
    "If she survives all ten, maybe she'll hear it. Maybe the home she's looking for is a sound, not a place.",
    "Either way — she's not stopping.",
  ],
};
