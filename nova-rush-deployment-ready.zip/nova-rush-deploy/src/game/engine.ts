/* ==========================================================================
   Nova Rush — canvas game engine
   Chapter 1: dodge, score, fight bosses, clear stages
   ========================================================================== */

import type { BallId } from "./balls";
import { STAGES, stageForN } from "./stages";
import { ABILITIES, type WeaponEffect } from "./abilities";
import { paintCometNucleus, MATERIALS, type CometId } from "./cometArt";

export type Mode = "attract" | "play" | "dying" | "transition" | "boss" | "flyout" | "won";

export interface PowerState {
  slow: number;
  double: number;
  shield: boolean;
  /** seconds of shield remaining */
  shieldT: number;
  lives: number;
}

export interface StarGrade {
  stars: number;          // 0..3
  passed: boolean;        // reached distance target
  finalScore: number;
  deaths: number;
}

export interface NovaCallbacks {
  onScore(score: number): void;
  onDistance(ly: number, target: number, boss: string): void;
  onPowers(p: PowerState): void;
  onGunReady(charges: number): void;
  onUltReady(ready: boolean): void;
  onStageIntro(stageN: number, name: string, subtitle: string, target: number): void;
  onBossSpawn(name: string, title: string, body: string, hp: number, hpMax: number, hint: string): void;
  onBossHp(hp: number, hpMax: number): void;
  onBossDefeated(stageN: number, bonus: number): void;
  onLevelComplete(grade: StarGrade): void;
  onGameOver(args: {
    score: number;
    best: number;
    isNewBest: boolean;
    livesUsed: number;
    stagesCleared: number;
    banked: number;
    totalCredits: number;
    grade: StarGrade;
  }): void;
  /** called on every shard / pickup / boss kill so the host can bank it instantly */
  onCredits(n: number, reason: string): void;
  sfx: {
    pickup(combo: number): void;
    shieldUp(): void;
    shieldBreak(): void;
    explosion(): void;
    explodeSmall(): void;
    squadron(): void;
    launch(): void;
    warn(): void;
    slowmo(): void;
    doublePts(): void;
    life(): void;
    stageClear(): void;
    revive(): void;
    buy(): void;
    gun(): void;
    ult(): void;
    boss(): void;
    hit(): void;
    upgrade(): void;
  };
}

/* ---------------- shared structures ---------------- */

interface Star { x: number; y: number; z: number; r: number; tw: number; }
interface Asteroid {
  x: number; y: number; vx: number; vy: number; r: number;
  rot: number; vr: number; verts: number[]; hue: [number, number, number];
  kind: "rock" | "dart"; wob: number; near: boolean;
  isBossProjectile?: boolean;
  /** status effects */
  slowT?: number;
  /** frozen SOLID — motion fully halted, not merely slowed */
  frozenT?: number;
  burnT?: number;
  burnDps?: number;
  hp?: number;
  /** visual/behaviour type for hostile fire (boss + alien weapons) */
  weapon?: "rock" | "emberShot" | "pressureRing" | "moonShard" | "dustBall"
         | "stormBolt" | "iceChunk" | "windLance" | "frostFlare" | "solarLance"
         | "alienPlasma" | "alienLaser" | "alienMine";
}
interface Pickup { x: number; y: number; vy: number; r: number; kind: "shard" | "shield" | "slowmo" | "double" | "life" | "gun" | "magnet" | "copilot" | "squadron"; spin: number; }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; glow: string; streak: boolean; }

/** A summoned AI co-pilot. Up to MAX_COPILOTS fly alongside you. */
interface Copilot {
  x: number; y: number;
  /** seconds of service left */
  t: number;
  fireT: number;
  phase: number;
  slot: number;
  shield: number;
}

/** A friendly AI fighter from the summoned squadron. */
interface Wingman {
  x: number; y: number;
  /** slot offset around the player */
  ox: number; oy: number;
  fireT: number;
  phase: number;
  hue: string;
}

/** Hostile alien interceptor — wanders unpredictably and shoots at the comet. */
interface Alien {
  x: number; y: number;
  vx: number; vy: number;
  hp: number;
  hpMax: number;
  r: number;
  t: number;
  /** behaviour archetype chosen at spawn */
  style: "drifter" | "strafer" | "circler" | "ambusher";
  fireT: number;
  /** frozen solid — cannot move or shoot */
  frozenT?: number;
  /** chilled — moves and fires at reduced rate */
  slowT?: number;
  /** steering goal, re-rolled periodically */
  gx: number; gy: number;
  goalT: number;
  hue: string;
  bob: number;
}
interface Bullet {
  x: number; y: number; vx: number; vy: number; life: number; r: number; color: string; core: string; damage: number;
  /** homing turn rate (radians/sec) — 0 = straight shot */
  homing: number;
  /** owner visual: 1 = main, 2 = wingmate */
  owner: 1 | 2;
  /** wobble phase for slash/wave aesthetics */
  wob: number;
  /** firing archetype — decides how the projectile is drawn */
  arche: string;
  effect?: WeaponEffect;
  effect2?: WeaponEffect;
  /** remaining pierces / bounces */
  pierce: number;
  bounces: number;
  /** seconds since spawn, for growth/animation */
  age: number;
}
interface Floater { x: number; y: number; txt: string; life: number; col: string; }

interface Boss {
  def: (typeof STAGES)[number]["boss"];
  stageN: number;
  hp: number;
  hpMax: number;
  x: number; y: number;
  vx: number; vy: number;
  r: number;
  t: number; // boss-local time
  pattern: string;
  shakeT: number;
  lastShotT: number;
  hintShown: boolean;
  deathT: number;
  entered: boolean;
  slowT: number;
  burnT: number;
  burnDps: number;
  gravT: number; // for jupiter gravity pulse
  windDir: 1 | -1; // for neptune
  windT: number;
}

interface BallPal {
  outer: string;
  inner: string;
  coreA: string;
  coreB: string;
  trail: string;
  ambient: string;
}

const PALETTE: Record<string, [number, number, number]> = {
  cyan: [103, 232, 249],
  violet: [168, 85, 247],
  pink: [244, 114, 182],
  amber: [251, 191, 36],
  white: [248, 250, 252],
  red: [248, 113, 113],
  frost: [186, 230, 253],
  ice: [224, 242, 254],
  fire: [251, 146, 60],
  ember: [239, 68, 68],
  cosmic: [217, 70, 239],
  nebula: [139, 92, 246],
  sky: [56, 189, 248],
  rose: [251, 113, 133],
  gold: [250, 204, 21],
  lime: [163, 230, 53],
};

const RAINBOW_CYCLE = ["rose", "fire", "gold", "lime", "cyan", "sky", "nebula", "cosmic"];

const COMBO_WINDOW = 2.6;
const COMBO_MAX = 10;
const SUPERNOVA_RECHARGE = 20; // seconds for the Supernova to come back online
const WEAPON_DURATION = 10; // seconds a weapon orb keeps the gun online
const WEAPON_ORB_INTERVAL = 9;  // a weapon orb drops on this fixed cadence
const COPILOT_DURATION = 40; // seconds each summoned AI co-pilot serves
const MAGNET_DURATION = 18;  // seconds the coin magnet stays active
const MAX_COPILOTS = 3;      // hard cap on stacked co-pilots
const SQUADRON_DURATION = 12; // seconds the multi-pilot wing stays on station
const SQUADRON_SIZE = 4;      // fighters in the wing
const SHIELD_DURATION = 10;  // seconds a shield orb protects you

const BALLS: Record<BallId, BallPal> = {
  pulse: { outer: "violet", inner: "cyan", coreA: "#f8fafc", coreB: "rgba(34,211,238,0.9)", trail: "cyan", ambient: "cyan" },
  ice: { outer: "sky", inner: "ice", coreA: "#ffffff", coreB: "rgba(186,230,253,0.95)", trail: "frost", ambient: "ice" },
  fire: { outer: "ember", inner: "fire", coreA: "#fff7ed", coreB: "rgba(251,146,60,0.95)", trail: "fire", ambient: "ember" },
  cosmic: { outer: "nebula", inner: "cosmic", coreA: "#fae8ff", coreB: "rgba(217,70,239,0.9)", trail: "cosmic", ambient: "nebula" },
  rainbow: { outer: "rose", inner: "cyan", coreA: "#ffffff", coreB: "rgba(255,255,255,0.95)", trail: "rainbow", ambient: "rainbow" },
};

export class NovaEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: NovaCallbacks;

  private W = 0;
  private H = 0;
  private dpr = 1;
  private raf = 0;
  private last = 0;
  private destroyed = false;

  private mode: Mode = "attract";
  private time = 0;
  private playTime = 0;
  private timeScale = 1;
  private dieClock = -1;
  private transT = -1;
  /** victory fly-off timer after a boss dies (-1 = inactive) */
  private flyoutT = -1;
  private introT = -1;

  private stars: Star[] = [];
  private asteroids: Asteroid[] = [];
  private pickups: Pickup[] = [];
  private particles: Particle[] = [];
  private bullets: Bullet[] = [];
  private aliens: Alien[] = [];
  private floaters: Floater[] = [];
  private trail: { x: number; y: number }[] = [];

  private player = { x: 0, y: 0, tx: 0, ty: 0, r: 13, alive: true, shield: 0, lives: 5 };
  /** stacked AI co-pilots (max 3) */
  private copilots: Copilot[] = [];
  private pointerDown = false;
  private keys = new Set<string>();

  private score = 0;
  private best = 0;
  private combo = 1;
  private comboT = 0;
  private shake = 0;
  private flash = 0;

  /* chapter / stage / boss */
  private stageN = 1;
  /** endless survival mode — no boss, escalating waves */
  private survival = false;
  private survivalWave = 1;
  private survivalT = 0;
  private distance = 0;            // light-years travelled this stage
  private distanceTarget = STAGES[0].distanceTarget;
  private bossActive: Boss | null = null;
  private awaitingBoss: Boss | null = null; // queued mid-stage

  /* powerups */
  private fxSlow = 0;
  private fxDouble = 0;
  private fxMagnet = 0;
  private lifeDropped = false;

  /* gun + ultimate */
  private gunCharges = 0;
  private lastFireT = -99;
  /** weapons go live (and auto-fire) once the first weapon orb is collected */
  private weaponArmed = false;
  /** seconds of weapon uptime left; weapons go offline at 0 */
  private weaponT = 0;
  /** seconds left on a summoned AI co-pilot (0 = none) */
  /** multi-pilot squadron */
  private squadronT = 0;
  private squadron: Wingman[] = [];
  private ultReady = false;
  /** seconds until the Supernova finishes recharging */
  private ultCharge = SUPERNOVA_RECHARGE;
  private ultActive = 0;
  /** expanding shockwave rings drawn during certain ultimates */
  private ultRings: Array<{ x: number; y: number; r: number; max: number; life: number; hue: string }> = [];
  /** active gravity-well visual (Black Hole) */
  private ultWell: { x: number; y: number; t: number } | null = null;
  /** expanding radius of the Absolute Zero wave front */
  private ultFreezeR = 0;
  private ultT = 0;


  /* per-run stats */
  private deathsThisRun = 0;
  private stagesCleared = 0;
  private bestStageReached = 1;


  private spawnA = 0.9;
  private spawnP = 1.3;
  private spawnS = 9;
  private spawnSl = 9;
  private spawnD = 7;
  private spawnG = 12;
  private spawnM = 9;
  private spawnAlien = 6;
  private spawnCo = 8;
  private spawnSq = 40;
  private ambientT = 0;

  private ball: BallPal = BALLS.pulse;
  private ballId: BallId = "pulse";
  private ability = ABILITIES.pulse;
  /** Prism keeps its ultimate identity after each temporary comet transformation. */
  private prismCycle = false;
  private prismTransformIndex = 0;
  private readonly prismForms: BallId[] = ["pulse", "ice", "fire", "cosmic"];
  private rainbowWalk = 0;

  private glows = new Map<string, HTMLCanvasElement>();
  /** prerendered per-stage backdrop (gradient + nebulas + haze) */
  private bgSprite: HTMLCanvasElement | null = null;
  /** which backdrop is currently baked, so we only rebuild on change */
  private bgKey = "";
  /** prerendered detailed nucleus for the equipped comet */
  private nucleusSprite: HTMLCanvasElement | null = null;
  /** prerendered ion-tail puff for the equipped comet (avoids per-frame gradients) */
  private ionSprite: HTMLCanvasElement | null = null;
  private nucleusSpin = 0;
  private bossCanvas: HTMLCanvasElement | null = null;
  private bossFlash = 0;

  private quality = 2;
  private slowFrames = 0;
  private paused = false;

  private lastScoreCb = 0;
  private lastPowersKey = "";
  private lastPowersCb = 0;
  private lastDistCb = 0;
  private lastGunCb = -1;
  private lastUltCb = false;

  private ro: ResizeObserver | null = null;


  constructor(canvas: HTMLCanvasElement, cb: NovaCallbacks) {
    this.canvas = canvas;
    const c = canvas.getContext("2d", { alpha: false });
    if (!c) throw new Error("no 2d context");
    this.ctx = c;
    this.cb = cb;
    this.best = Number(localStorage.getItem("nova-best") ?? 0) || 0;

    for (const [name, rgb] of Object.entries(PALETTE)) this.glows.set(name, this.makeGlow(rgb));
    this.glows.set("white", this.makeGlow([255, 255, 255]));

    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas.parentElement ?? canvas);

    canvas.addEventListener("pointerdown", this.onPointerDown, { passive: true });
    window.addEventListener("pointermove", this.onPointerMove, { passive: true });
    window.addEventListener("pointerup", this.onPointerUp, { passive: true });
    window.addEventListener("pointercancel", this.onPointerUp, { passive: true });
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);

    this.player.x = this.player.tx = this.W * 0.5;
    this.player.y = this.player.ty = this.H * 0.72;

    this.buildStars();
    this.prerenderBoss();
  }

  /* ---------------- lifecycle ---------------- */

  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      if (this.destroyed) return;
      const realDt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      if (!this.paused) {
        this.autoQuality(realDt);
        this.update(realDt);
      }
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    this.ro?.disconnect();
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("pointercancel", this.onPointerUp);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
  }

  setBall(id: BallId, preservePrismCycle = false) {
    if (!preservePrismCycle) {
      this.prismCycle = id === "rainbow";
      if (id === "rainbow") this.prismTransformIndex = 0;
    }
    this.ballId = id;
    this.ball = BALLS[id] ?? BALLS.pulse;
    this.ability = ABILITIES[id] ?? ABILITIES.pulse;
    // prerender sprites once per character swap — never per frame
    this.nucleusSprite = paintCometNucleus(id as CometId, 128);
    const ion = MATERIALS[id as CometId]?.ion ?? "56,189,248";
    const c = this.rgbOf(ion).split(",").map(Number) as [number, number, number];
    this.ionSprite = this.makeGlow(c);
  }


  setPaused(b: boolean) { this.paused = b; }
  get isPaused() { return this.paused; }
  get currentStageN() { return this.stageN; }

  /** Start a run on a specific stage (1-based) */
  launch(stageN = 1, survival = false) {
    this.mode = "play";
    this.playTime = 0;
    this.score = 0;
    this.combo = 1;
    this.comboT = 0;
    this.timeScale = 1;
    this.dieClock = -1;
    this.asteroids = [];
    this.pickups = [];
    this.bullets = [];
    this.floaters = [];
    this.particles = [];
    this.bossActive = null;
    this.awaitingBoss = null;
    this.spawnA = 0.7;
    this.spawnP = 0.9;
    this.spawnS = 11;
    this.spawnSl = 8;
    this.spawnD = 6;
    this.spawnG = 1.5;   // first weapon arrives fast, then on a 9s cadence
    this.spawnM = 9;
    this.spawnAlien = 5;
    this.spawnCo = 7;
    this.spawnSq = 38;
    this.aliens = [];
    this.weaponArmed = false;
    this.weaponT = 0;
    this.copilots = [];
    this.squadronT = 0;
    this.squadron = [];
    this.lastFireT = -99;
    this.fxSlow = 0;
    this.fxDouble = 0;
    this.fxMagnet = 0;
    this.lifeDropped = false;
    this.gunCharges = 0;
    this.ultReady = false;
    this.ultCharge = SUPERNOVA_RECHARGE;
    this.ultActive = 0;
    this.ultRings = [];
    this.ultWell = null;
    this.ultFreezeR = 0;
    this.ultT = 0;
    this.deathsThisRun = 0;
    this.stagesCleared = 0;
    this.bestStageReached = stageN;
    this.stageN = Math.max(1, Math.min(STAGES.length, Math.floor(stageN)));
    this.distance = 0;
    this.distanceTarget = STAGES[this.stageN - 1].distanceTarget;
    this.buildBackground(true);   // this world has its own sky
    this.prerenderBoss();         // ...and its own boss sprite
    this.transT = 0;
    this.flyoutT = -1;
    this.survival = survival;
    this.survivalWave = 1;
    this.survivalT = 0;
    const p = this.player;
    p.alive = true;
    p.shield = 0;
    p.lives = 5;
    p.x = p.tx = this.W * 0.5;
    p.y = p.ty = this.H * 0.72;
    this.trail = [];
    const def = STAGES[this.stageN - 1];
    this.cb.onStageIntro(this.stageN, def.name, def.subtitle, def.distanceTarget);
    this.cb.onBossSpawn("", "", "", 0, 0, "");
    this.emitScore(true);
    this.emitPowers(true);
    this.emitGun(true);
    this.emitUlt(true);
    this.cb.sfx.launch();
    this.burst(p.x, p.y, 22, this.ball.trail === "rainbow" ? "cyan" : this.ball.trail, 240);
  }

  toMenu() {
    this.mode = "attract";
    this.asteroids = [];
    this.pickups = [];
    this.bullets = [];
    this.bossActive = null;
    this.awaitingBoss = null;
    this.player.alive = true;
    this.player.shield = 0;
    this.fxSlow = 0;
    this.fxDouble = 0;
    this.gunCharges = 0;
    this.ultReady = false;
    this.ultCharge = SUPERNOVA_RECHARGE;
    this.ultActive = 0;
    this.ultRings = [];
    this.ultWell = null;
    this.ultFreezeR = 0;
    this.timeScale = 1;
  }

  /* ---------------- input ---------------- */

  private onPointerDown = (e: PointerEvent) => {
    this.pointerDown = true;
    this.setTarget(e.clientX, e.clientY, e.pointerType);
  };
  private onPointerMove = (e: PointerEvent) => {
    if (!this.pointerDown && e.pointerType !== "mouse") return;
    this.setTarget(e.clientX, e.clientY, e.pointerType);
  };
  private onPointerUp = () => { this.pointerDown = false; };
  private onKeyDown = (e: KeyboardEvent) => { this.keys.add(e.key.toLowerCase()); };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.key.toLowerCase()); };

  private setTarget(cx: number, cy: number, type: string) {
    const rect = this.canvas.getBoundingClientRect();
    const offset = type === "mouse" ? 0 : Math.min(120, this.H * 0.11);
    this.player.tx = cx - rect.left;
    this.player.ty = cy - rect.top - offset;
  }

  /** Weapons are fully automatic once a weapon orb arms them — there is no
   *  fire button. Kept as a no-op so legacy callers/keybinds stay harmless. */
  fire() { /* automatic — see weaponArmed branch in update() */ }

  get isWeaponArmed() { return this.weaponArmed; }
  get weaponTimeLeft() { return Math.max(0, this.weaponT); }
  get copilotTimeLeft() { return this.copilots.length ? Math.max(...this.copilots.map((c) => c.t)) : 0; }
  get copilotCount() { return this.copilots.length; }
  /** 0..1 — how full the Supernova gauge is */
  get ultChargeFrac() {
    if (this.ultReady || this.ultActive > 0) return 1;
    return Math.max(0, Math.min(1, 1 - this.ultCharge / SUPERNOVA_RECHARGE));
  }
  get squadronTimeLeft() { return Math.max(0, this.squadronT); }
  get ultimateTimeLeft() { return Math.max(0, this.ultActive); }
  get currentWeaponName() { return this.ability.gun.name; }

  /** external — host calls when user triggers the ultimate */
  useUlt() {
    if (this.mode !== "play" && this.mode !== "boss") return;
    if (!this.player.alive) return;
    if (!this.ultReady) return;
    this.ultReady = false;
    this.ultCharge = SUPERNOVA_RECHARGE;   // begin the 20s recharge
    this.ultActive = this.prismCycle ? 5 : this.ability.ultimate.duration;
    this.ultFreezeR = 0;
    this.ultT = this.time;
    this.emitUlt(true);
    this.cb.sfx.ult();
    this.burst(this.player.x, this.player.y, 30, "white", 360);
  }

  /* ---------------- sizing / sprites ---------------- */

  private resize() {
    const parent = this.canvas.parentElement;
    const w = parent ? parent.clientWidth : window.innerWidth;
    const h = parent ? parent.clientHeight : window.innerHeight;
    const maxDpr = this.quality === 2 ? 2 : this.quality === 1 ? 1.5 : 1.1;
    this.dpr = Math.min(maxDpr, window.devicePixelRatio || 1);
    this.W = w;
    this.H = h;
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.buildBackground(true);
    this.player.tx = Math.min(this.player.tx, w);
    this.player.ty = Math.min(this.player.ty, h);
    this.prerenderBoss();
  }

  /** Which backdrop applies right now. Survival cycles them as waves climb. */
  private currentBg() {
    const idx = this.survival
      ? (this.survivalWave - 1) % STAGES.length
      : Math.max(0, Math.min(STAGES.length - 1, this.stageN - 1));
    return STAGES[idx].bg;
  }

  /**
   * Bake the static backdrop into an offscreen canvas. Doing this once per
   * stage (rather than compositing gradients every frame) is both prettier
   * and cheaper than the old two-glow approach.
   */
  private buildBackground(force = false) {
    const W = Math.round(this.W);
    const H = Math.round(this.H);
    if (W <= 0 || H <= 0) return;
    const bg = this.currentBg();
    const key = `${bg.grad[0]}|${W}x${H}`;
    if (!force && key === this.bgKey) return;
    this.bgKey = key;

    const c = document.createElement("canvas");
    c.width = W;
    c.height = H;
    const x = c.getContext("2d");
    if (!x) return;

    const rgba = (hex: string, a: number) => {
      const v = this.hexToRgb(hex);
      return `rgba(${v.r},${v.g},${v.b},${a})`;
    };

    // 1. deep-space vertical gradient
    const g = x.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, bg.grad[0]);
    g.addColorStop(0.55, bg.grad[1]);
    g.addColorStop(1, bg.grad[2]);
    x.fillStyle = g;
    x.fillRect(0, 0, W, H);

    // 2. horizontal haze band (dust lanes, cloud decks, ring debris)
    if (bg.band) {
      const by = bg.band.y * H;
      const bh = bg.band.h * H;
      const bgrad = x.createLinearGradient(0, by - bh / 2, 0, by + bh / 2);
      bgrad.addColorStop(0, rgba(bg.band.c, 0));
      bgrad.addColorStop(0.5, rgba(bg.band.c, bg.band.a));
      bgrad.addColorStop(1, rgba(bg.band.c, 0));
      x.fillStyle = bgrad;
      x.fillRect(0, by - bh / 2, W, bh);
    }

    // 3. soft nebula clouds
    x.globalCompositeOperation = "lighter";
    const long = Math.max(W, H);
    for (const n of bg.nebulas) {
      const r = n.r * long;
      const cx = n.x * W;
      const cy = n.y * H;
      const rg = x.createRadialGradient(cx, cy, 0, cx, cy, r);
      rg.addColorStop(0, rgba(n.c, n.a));
      rg.addColorStop(0.45, rgba(n.c, n.a * 0.4));
      rg.addColorStop(1, rgba(n.c, 0));
      x.fillStyle = rg;
      x.fillRect(cx - r, cy - r, r * 2, r * 2);
    }

    // 4. vignette so the playfield stays readable against bright backdrops
    x.globalCompositeOperation = "source-over";
    const vg = x.createRadialGradient(W / 2, H * 0.45, Math.min(W, H) * 0.25, W / 2, H * 0.45, long * 0.78);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.55)");
    x.fillStyle = vg;
    x.fillRect(0, 0, W, H);

    this.bgSprite = c;
  }

  private buildStars() {
    const n = Math.round(Math.min(140, Math.max(50, (this.W * this.H) / 9000)));
    this.stars = [];
    for (let i = 0; i < n; i++) {
      const z = Math.random();
      this.stars.push({
        x: Math.random() * this.W,
        y: Math.random() * this.H,
        z: 0.25 + z * 0.75,
        r: z * 1.4 + 0.4,
        tw: Math.random() * Math.PI * 2,
      });
    }
  }

  private makeGlow([r, g, b]: [number, number, number]): HTMLCanvasElement {
    const s = 128;
    const c = document.createElement("canvas");
    c.width = s;
    c.height = s;
    const x = c.getContext("2d")!;
    const grad = x.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    grad.addColorStop(0, "rgba(255,255,255,0.9)");
    grad.addColorStop(0.22, `rgba(${r},${g},${b},0.85)`);
    grad.addColorStop(0.55, `rgba(${r},${g},${b},0.25)`);
    grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
    x.fillStyle = grad;
    x.fillRect(0, 0, s, s);
    return c;
  }

  private autoQuality(realDt: number) {
    if (this.mode !== "play" && this.mode !== "boss") return;
    if (realDt > 0.02) {
      this.slowFrames++;
      if (this.slowFrames > 90 && this.quality > 0) {
        this.quality--;
        this.slowFrames = 0;
        this.resize();
        if (this.quality === 1) this.buildStars();
      }
    } else {
      this.slowFrames = Math.max(0, this.slowFrames - 2);
    }
  }

  /* ---------------- prerendered boss sprite ---------------- */

  /** Paint a stage-accurate planet sprite at the boss's prerender canvas. */
  /**
   * Bake a planet sprite.
   *
   * Restructured to render as a genuine lit SPHERE rather than a flat disc:
   *   1. surface features are painted into a flat equirectangular texture
   *   2. that texture is sampled onto the disc with spherical distortion, so
   *      detail compresses toward the limb exactly as it does on a real globe
   *   3. a Lambertian lighting pass adds a soft terminator and limb darkening
   *   4. atmospheric bodies get a forward-scattering rim; airless ones don't
   */
  private prerenderBoss() {
    const S = 384;
    const c = document.createElement("canvas");
    c.width = S;
    c.height = S;
    const x = c.getContext("2d")!;
    const stage = stageForN(this.stageN);
    const pal = stage.boss.palette;
    const a = this.hexToRgb(pal[0]);
    const b = this.hexToRgb(pal[1]);
    const k = this.hexToRgb(pal[2]);
    const r = S * 0.42;
    const cx = S / 2;
    const cy = S / 2;
    const rgbStr = (rgb: { r: number; g: number; b: number }) => `${rgb.r},${rgb.g},${rgb.b}`;
    const atmos = NovaEngine.ATMOS[stage.n] ?? 0.4;

    /* ---- 1. outer atmosphere / corona ---- */
    if (atmos > 0.02) {
      const halo = x.createRadialGradient(cx, cy, r * 0.92, cx, cy, S / 2);
      halo.addColorStop(0, `rgba(${rgbStr(a)},${0.30 * atmos})`);
      halo.addColorStop(0.35, `rgba(${rgbStr(b)},${0.16 * atmos})`);
      halo.addColorStop(1, `rgba(${rgbStr(k)},0)`);
      x.fillStyle = halo;
      x.fillRect(0, 0, S, S);
    }

    /* ---- 2. base globe ---- */
    const body = x.createRadialGradient(S * 0.40, S * 0.38, r * 0.05, cx, cy, r * 1.05);
    body.addColorStop(0, `rgba(${rgbStr(a)},1)`);
    body.addColorStop(0.42, `rgba(${rgbStr(b)},1)`);
    body.addColorStop(1, `rgba(${rgbStr(k)},1)`);
    x.fillStyle = body;
    x.beginPath();
    x.arc(cx, cy, r, 0, Math.PI * 2);
    x.fill();

    /* ---- 3. surface features, clipped to the globe ---- */
    x.save();
    x.beginPath();
    x.arc(cx, cy, r, 0, Math.PI * 2);
    x.clip();
    switch (stage.n) {
      case 1: this.paintMercury(x, cx, cy, r, a, b, k); break;
      case 2: this.paintVenus(x, cx, cy, r, a, b, k); break;
      case 3: this.paintEarth(x, cx, cy, r, a, b, k); break;
      case 4: this.paintMars(x, cx, cy, r, a, b, k); break;
      case 5: this.paintJupiter(x, cx, cy, r, a, b, k); break;
      case 7: this.paintUranus(x, cx, cy, r, a, b, k); break;
      case 8: this.paintNeptune(x, cx, cy, r, a, b, k); break;
      case 9: this.paintPluto(x, cx, cy, r, a, b, k); break;
      case 10: this.paintSun(x, cx, cy, r, a, b, k); break;
    }
    x.restore();
    // Saturn draws its own rings outside the clip (they extend past the globe)
    if (stage.n === 6) this.paintSaturn(x, cx, cy, r, a, b, k);

    /* ---- 4. spherical lighting: terminator + limb darkening ---- */
    // The Sun is self-luminous, so it gets none of this.
    if (stage.n !== 10) {
      x.save();
      x.beginPath();
      x.arc(cx, cy, r, 0, Math.PI * 2);
      x.clip();

      // Lambertian falloff from an upper-left key light
      const lx = cx - r * 0.42;
      const ly = cy - r * 0.46;
      const shade = x.createRadialGradient(lx, ly, r * 0.1, lx, ly, r * 2.05);
      shade.addColorStop(0, "rgba(255,255,255,0.20)");
      shade.addColorStop(0.32, "rgba(255,255,255,0.0)");
      shade.addColorStop(0.68, "rgba(0,0,0,0.42)");
      shade.addColorStop(1, "rgba(0,0,0,0.80)");
      x.fillStyle = shade;
      x.fillRect(0, 0, S, S);

      // limb darkening — the disc edge always falls off on a real sphere
      const limb = x.createRadialGradient(cx, cy, r * 0.55, cx, cy, r);
      limb.addColorStop(0, "rgba(0,0,0,0)");
      limb.addColorStop(1, "rgba(0,0,0,0.5)");
      x.fillStyle = limb;
      x.fillRect(0, 0, S, S);

      // atmospheric bodies scatter light forward along the lit limb
      if (atmos > 0.1) {
        x.globalCompositeOperation = "lighter";
        const rim = x.createRadialGradient(cx, cy, r * 0.82, cx, cy, r);
        rim.addColorStop(0, `rgba(${rgbStr(a)},0)`);
        rim.addColorStop(0.72, `rgba(${rgbStr(a)},${0.1 * atmos})`);
        rim.addColorStop(1, `rgba(${rgbStr(a)},${0.4 * atmos})`);
        x.fillStyle = rim;
        x.beginPath();
        x.arc(cx, cy, r, 0, Math.PI * 2);
        x.fill();
        x.globalCompositeOperation = "source-over";
      }
      x.restore();
    }

    /* ---- 5. specular highlight — only on gaseous / icy surfaces ---- */
    const gloss: Record<number, number> = { 1: 0, 2: 0.14, 3: 0.12, 4: 0, 5: 0.1, 6: 0.1, 7: 0.12, 8: 0.12, 9: 0, 10: 0 };
    const spec = gloss[stage.n] ?? 0.1;
    if (spec > 0) {
      x.globalCompositeOperation = "lighter";
      const sg = x.createRadialGradient(S * 0.40, S * 0.35, 0, S * 0.40, S * 0.35, r * 0.34);
      sg.addColorStop(0, `rgba(255,255,255,${spec})`);
      sg.addColorStop(1, "rgba(255,255,255,0)");
      x.fillStyle = sg;
      x.beginPath();
      x.arc(S * 0.40, S * 0.35, r * 0.34, 0, Math.PI * 2);
      x.fill();
      x.globalCompositeOperation = "source-over";
    }

    this.bossCanvas = c;
  }


  private paintMercury(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, _a: any, _b: any, _k: any) {
    // Airless grey regolith: dense craters, bright ejecta rays, lobate scarps.
    const craters: Array<[number, number, number]> = [
      [0.30, 0.40, 0.17], [0.58, 0.28, 0.11], [0.68, 0.58, 0.13],
      [0.40, 0.72, 0.09], [0.18, 0.52, 0.12], [0.74, 0.40, 0.08],
      [0.50, 0.55, 0.07], [0.34, 0.22, 0.09], [0.60, 0.74, 0.06],
      [0.24, 0.70, 0.05], [0.46, 0.36, 0.05], [0.80, 0.52, 0.05],
    ];
    for (const [px, py, rr] of craters) {
      const gx = cx + (px - 0.5) * 2 * r * 0.84;
      const gy = cy + (py - 0.5) * 2 * r * 0.84;
      const cr = r * rr;
      x.globalAlpha = 0.5;
      x.fillStyle = "#3b3630";
      x.beginPath(); x.arc(gx, gy, cr, 0, Math.PI * 2); x.fill();
      x.globalAlpha = 0.45;
      x.strokeStyle = "#241f1a";
      x.lineWidth = Math.max(1, cr * 0.3);
      x.beginPath(); x.arc(gx, gy, cr * 0.82, Math.PI * 1.75, Math.PI * 0.72); x.stroke();
      x.globalAlpha = 0.55;
      x.strokeStyle = "#cfc7bb";
      x.lineWidth = Math.max(0.8, cr * 0.22);
      x.beginPath(); x.arc(gx, gy, cr * 0.95, Math.PI * 0.78, Math.PI * 1.72); x.stroke();
    }

    // bright ejecta rays from a fresh impact
    x.globalAlpha = 0.18;
    x.strokeStyle = "#efe8dc";
    const rx = cx + r * 0.1, ry = cy + r * 0.44;
    for (let i = 0; i < 9; i++) {
      const a0 = (i / 9) * Math.PI * 2 + 0.3;
      x.lineWidth = 1 + (i % 3);
      x.beginPath();
      x.moveTo(rx + Math.cos(a0) * r * 0.1, ry + Math.sin(a0) * r * 0.1);
      x.lineTo(rx + Math.cos(a0) * r * (0.4 + (i % 4) * 0.12), ry + Math.sin(a0) * r * (0.4 + (i % 4) * 0.12));
      x.stroke();
    }

    // lobate scarps — long wrinkle ridges from the planet contracting
    x.globalAlpha = 0.34;
    x.strokeStyle = "#1f1b16";
    x.lineWidth = 2;
    for (const [sy, amp] of [[-0.3, 0.22], [0.26, -0.18]] as Array<[number, number]>) {
      x.beginPath();
      x.moveTo(cx - r * 0.8, cy + r * sy);
      x.quadraticCurveTo(cx, cy + r * (sy + amp), cx + r * 0.8, cy + r * sy * 0.6);
      x.stroke();
    }

    // Caloris Basin — the giant ringed impact scar
    const bx = cx + r * 0.3, by = cy - r * 0.26, br = r * 0.34;
    x.globalAlpha = 0.4;
    x.fillStyle = "#6f675c";
    x.beginPath(); x.arc(bx, by, br, 0, Math.PI * 2); x.fill();
    x.globalAlpha = 0.6;
    x.strokeStyle = "#d6cec1"; x.lineWidth = 1.6;
    x.beginPath(); x.arc(bx, by, br, 0, Math.PI * 2); x.stroke();
    x.globalAlpha = 0.35; x.lineWidth = 1;
    x.beginPath(); x.arc(bx, by, br * 0.66, 0, Math.PI * 2); x.stroke();
    x.beginPath(); x.arc(bx, by, br * 0.4, 0, Math.PI * 2); x.stroke();
    x.globalAlpha = 1;
  }

  private paintVenus(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, a: any, _b: any, k: any) {
    // Opaque sulphuric cloud deck — no surface visible, only churning cells.
    x.save();
    x.translate(cx, cy);

    // banded super-rotation
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 9; i++) {
      const y = -r + ((i + 0.5) / 9) * r * 2;
      const w = r * Math.cos(((i + 0.5) / 9 - 0.5) * Math.PI * 0.45);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},${0.18 + (i % 2) * 0.22})`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.055, 0, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // turbulent convection cells
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "lighter";
    for (let i = 0; i < 14; i++) {
      const ang = (i / 14) * Math.PI * 2 + 0.6;
      const d = r * (0.2 + ((i * 7) % 5) / 9);
      const px = Math.cos(ang) * d;
      const py = Math.sin(ang) * d * 0.8;
      const cr = r * (0.1 + ((i * 3) % 4) * 0.05);
      const g = x.createRadialGradient(px, py, 0, px, py, cr);
      g.addColorStop(0, `rgba(${a.r},${a.g},${a.b},0.35)`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      x.fillStyle = g;
      x.beginPath(); x.arc(px, py, cr, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // signature Y-shaped retrograde cloud feature
    x.save();
    x.translate(cx, cy);
    x.globalAlpha = 0.32;
    x.strokeStyle = "#8a5a2b";
    x.lineWidth = r * 0.13;
    x.lineCap = "round";
    x.beginPath();
    x.moveTo(-r * 0.6, -r * 0.35);
    x.quadraticCurveTo(0, -r * 0.1, r * 0.55, -r * 0.3);
    x.moveTo(0, -r * 0.12);
    x.quadraticCurveTo(r * 0.1, r * 0.3, -r * 0.2, r * 0.62);
    x.stroke();
    x.lineCap = "butt";
    x.globalAlpha = 1;
    x.restore();
  }

  private paintEarth(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, _a: any, _b: any, _k: any) {
    // Ocean world: landmasses, swirling weather, ice caps, night-side lights.
    const landmasses: Array<[number, number, number, number, number]> = [
      [-0.30, -0.22, 0.20, 0.24, -0.2],
      [0.12, -0.12, 0.13, 0.30, 0.15],
      [0.02, 0.26, 0.17, 0.20, 0.0],
      [-0.17, 0.32, 0.11, 0.14, 0.3],
      [0.34, 0.37, 0.09, 0.07, -0.2],
    ];
    for (const [px, py, w, h, rot] of landmasses) {
      x.fillStyle = "rgba(42, 140, 72, 0.9)";
      x.beginPath();
      x.ellipse(cx + px * r, cy + py * r, w * r, h * r, rot, 0, Math.PI * 2);
      x.fill();
      // arid interior
      x.fillStyle = "rgba(170, 130, 70, 0.45)";
      x.beginPath();
      x.ellipse(cx + px * r, cy + py * r, w * r * 0.55, h * r * 0.5, rot, 0, Math.PI * 2);
      x.fill();
    }

    // cyclonic weather systems
    x.globalAlpha = 0.55;
    x.fillStyle = "#ffffff";
    for (const [sx, sy, sw, sh, rot] of [
      [-0.45, -0.45, 0.42, 0.1, -0.4], [0.3, -0.5, 0.3, 0.08, 0.3],
      [-0.2, 0.08, 0.5, 0.09, 0.15], [0.35, 0.42, 0.34, 0.08, -0.25],
    ] as Array<[number, number, number, number, number]>) {
      x.beginPath();
      x.ellipse(cx + sx * r, cy + sy * r, sw * r, sh * r, rot, 0, Math.PI * 2);
      x.fill();
    }
    // a spiral storm
    x.strokeStyle = "rgba(255,255,255,0.75)";
    x.lineWidth = r * 0.05;
    x.beginPath();
    for (let t = 0; t < 34; t++) {
      const f = t / 34;
      const ang = f * Math.PI * 2.4;
      const rr = f * r * 0.2;
      const px = cx + 0.42 * r + Math.cos(ang) * rr;
      const py = cy - 0.18 * r + Math.sin(ang) * rr * 0.85;
      t ? x.lineTo(px, py) : x.moveTo(px, py);
    }
    x.stroke();
    x.globalAlpha = 1;

    // night-side city lights along the terminator
    x.globalCompositeOperation = "lighter";
    for (let i = 0; i < 22; i++) {
      const ang = Math.PI * (0.15 + (i / 22) * 0.7);
      const d = r * (0.72 + ((i * 5) % 4) * 0.06);
      const px = cx + Math.cos(ang) * d;
      const py = cy + Math.sin(ang) * d * 0.95;
      x.fillStyle = `rgba(255, 214, 140, ${0.35 + ((i * 3) % 4) * 0.12})`;
      x.beginPath(); x.arc(px, py, 0.9 + ((i * 7) % 3) * 0.4, 0, Math.PI * 2); x.fill();
    }
    x.globalCompositeOperation = "source-over";

    // the Moon
    const mx = cx + r * 1.22, my = cy - r * 0.68, mr = r * 0.2;
    const mg = x.createRadialGradient(mx - mr * 0.3, my - mr * 0.3, 0, mx, my, mr);
    mg.addColorStop(0, "#e8e4da"); mg.addColorStop(1, "#6b665d");
    x.fillStyle = mg;
    x.beginPath(); x.arc(mx, my, mr, 0, Math.PI * 2); x.fill();
    x.fillStyle = "rgba(70,66,60,0.55)";
    x.beginPath(); x.arc(mx - mr * 0.25, my + mr * 0.1, mr * 0.28, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.arc(mx + mr * 0.3, my - mr * 0.25, mr * 0.18, 0, Math.PI * 2); x.fill();

    // ice caps
    x.fillStyle = "rgba(255, 255, 255, 0.9)";
    x.beginPath(); x.ellipse(cx, cy - r * 0.85, r * 0.5, r * 0.1, 0, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.ellipse(cx, cy + r * 0.85, r * 0.4, r * 0.08, 0, 0, Math.PI * 2); x.fill();
  }

  private paintMars(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, _a: any, _b: any, k: any) {
    // Rust desert: canyon system, shield volcanoes, dark albedo, polar caps.
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 5; i++) {
      const y = -r + ((i + 0.5) / 5) * r * 2;
      const w = r * Math.cos(((i + 0.5) / 5 - 0.5) * Math.PI * 0.5);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},0.5)`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.04, 0, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // Syrtis Major — the big dark albedo patch
    x.globalAlpha = 0.4;
    x.fillStyle = "#4a2415";
    x.beginPath();
    x.ellipse(cx + r * 0.3, cy - r * 0.08, r * 0.3, r * 0.42, -0.4, 0, Math.PI * 2);
    x.fill();
    x.globalAlpha = 1;

    // Tharsis shield volcanoes, each with a summit caldera
    for (const [vx, vy, vr] of [[-0.34, -0.22, 0.1], [-0.15, -0.02, 0.07], [-0.46, 0.04, 0.06]] as Array<[number,number,number]>) {
      const px = cx + vx * r, py = cy + vy * r, pr = vr * r;
      const g = x.createRadialGradient(px - pr * 0.3, py - pr * 0.3, 0, px, py, pr);
      g.addColorStop(0, "rgba(220,150,110,0.75)");
      g.addColorStop(1, "rgba(90,40,20,0.1)");
      x.fillStyle = g;
      x.beginPath(); x.arc(px, py, pr, 0, Math.PI * 2); x.fill();
      x.fillStyle = "rgba(40,18,10,0.7)";
      x.beginPath(); x.arc(px, py, pr * 0.34, 0, Math.PI * 2); x.fill();
    }

    // Valles Marineris — the great rift, tapering at both ends
    x.strokeStyle = "rgba(38,16,8,0.8)";
    x.lineCap = "round";
    for (const [w2, al] of [[3.2, 0.8], [1.4, 0.5]] as Array<[number, number]>) {
      x.globalAlpha = al;
      x.lineWidth = w2;
      x.beginPath();
      x.moveTo(cx - r * 0.42, cy + r * 0.3);
      x.quadraticCurveTo(cx, cy + r * 0.17, cx + r * 0.46, cy + r * 0.22);
      x.stroke();
    }
    x.lineCap = "butt";
    x.globalAlpha = 1;

    // polar caps, CO2 ice
    x.fillStyle = "rgba(255, 250, 245, 0.92)";
    x.beginPath(); x.ellipse(cx, cy - r * 0.85, r * 0.4, r * 0.08, 0, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.ellipse(cx, cy + r * 0.85, r * 0.5, r * 0.12, 0, 0, Math.PI * 2); x.fill();
  }

  private paintJupiter(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, a: any, _b: any, k: any) {
    // Gas giant: alternating zones and belts, turbulent shear, the Great Red Spot.
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "multiply";
    const bands = 11;
    for (let i = 0; i < bands; i++) {
      const f = (i + 0.5) / bands;
      const y = -r + f * r * 2;
      const w = r * Math.cos((f - 0.5) * Math.PI * 0.45);
      const belt = i % 2 === 0;
      x.fillStyle = belt
        ? `rgba(${k.r},${k.g},${k.b},0.5)`
        : `rgba(${a.r},${a.g},${a.b},0.3)`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.052, 0, 0, Math.PI * 2); x.fill();
    }
    // turbulent shear curls where bands meet
    x.globalCompositeOperation = "source-over";
    x.globalAlpha = 0.25;
    x.strokeStyle = "#6b3a1c";
    x.lineWidth = r * 0.02;
    for (let i = 1; i < bands; i += 2) {
      const y = -r + (i / bands) * r * 2;
      const w = r * Math.cos((i / bands - 0.5) * Math.PI * 0.45);
      x.beginPath();
      for (let t = -1; t <= 1; t += 0.08) {
        const px = t * w;
        const py = y + Math.sin(t * 9 + i) * r * 0.022;
        t === -1 ? x.moveTo(px, py) : x.lineTo(px, py);
      }
      x.stroke();
    }
    x.globalAlpha = 1;
    x.restore();

    // white storm ovals
    x.globalAlpha = 0.5;
    x.fillStyle = "#fff7e6";
    for (const [ox, oy, orx] of [[-0.45, -0.22, 0.1], [0.2, -0.42, 0.08], [-0.15, 0.5, 0.07]] as Array<[number,number,number]>) {
      x.beginPath();
      x.ellipse(cx + ox * r, cy + oy * r, orx * r, orx * r * 0.55, 0, 0, Math.PI * 2);
      x.fill();
    }
    x.globalAlpha = 1;

    // Io's shadow transiting the disc
    x.fillStyle = "rgba(0,0,0,0.55)";
    x.beginPath(); x.arc(cx - r * 0.5, cy + r * 0.3, r * 0.09, 0, Math.PI * 2); x.fill();

    // the Great Red Spot — a rotating anticyclone with internal curl
    const sx = cx + r * 0.25, sy = cy + r * 0.25;
    x.fillStyle = "rgba(190, 55, 28, 0.9)";
    x.beginPath(); x.ellipse(sx, sy, r * 0.17, r * 0.105, 0, 0, Math.PI * 2); x.fill();
    x.fillStyle = "rgba(240, 130, 85, 0.6)";
    x.beginPath(); x.ellipse(sx, sy, r * 0.11, r * 0.065, 0, 0, Math.PI * 2); x.fill();
    x.strokeStyle = "rgba(120, 30, 12, 0.55)";
    x.lineWidth = 1.1;
    x.beginPath();
    for (let t = 0; t < 26; t++) {
      const f = t / 26;
      const ang = f * Math.PI * 2.6;
      const rr = f * r * 0.15;
      const px = sx + Math.cos(ang) * rr;
      const py = sy + Math.sin(ang) * rr * 0.6;
      t ? x.lineTo(px, py) : x.moveTo(px, py);
    }
    x.stroke();
  }

  private paintSaturn(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, a: any, b: any, k: any) {
    // Pale banded globe wrapped in a bright, layered ring system.
    const TILT = -0.32;

    // soft bands on the globe
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 8; i++) {
      const f = (i + 0.5) / 8;
      const y = -r + f * r * 2;
      const w = r * Math.cos((f - 0.5) * Math.PI * 0.5);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},${0.22 + (i % 2) * 0.2})`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.05, 0, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // hexagonal polar vortex — Saturn's unmistakable north pole
    x.save();
    x.translate(cx, cy - r * 0.6);
    x.globalAlpha = 0.4;
    x.strokeStyle = "#6b4e12";
    x.lineWidth = 1.6;
    x.beginPath();
    for (let i = 0; i < 6; i++) {
      const ang = (i / 6) * Math.PI * 2 + 0.4;
      const px = Math.cos(ang) * r * 0.26;
      const py = Math.sin(ang) * r * 0.09;
      i ? x.lineTo(px, py) : x.moveTo(px, py);
    }
    x.closePath(); x.stroke();
    x.globalAlpha = 1;
    x.restore();

    // ring system: several distinct bands of differing brightness
    const RINGS: Array<[number, number, string, number]> = [
      [1.18, 5, `rgba(${k.r},${k.g},${k.b},0.55)`, 0.55],   // inner C ring, dim
      [1.34, 9, `rgba(${a.r},${a.g},${a.b},0.9)`, 0.9],     // B ring, brightest
      [1.50, 3, "rgba(0,0,0,0)", 0],                        // Cassini division
      [1.62, 7, `rgba(${a.r},${a.g},${a.b},0.72)`, 0.72],   // A ring
      [1.78, 2.5, `rgba(${a.r},${a.g},${a.b},0.3)`, 0.3],   // faint F ring
    ];

    const drawRings = (back: boolean) => {
      x.save();
      x.translate(cx, cy);
      x.rotate(TILT);
      for (const [rad, w, col, al] of RINGS) {
        if (al <= 0) continue;
        x.strokeStyle = col;
        x.lineWidth = w;
        x.beginPath();
        if (back) x.ellipse(0, 0, r * rad, r * rad * 0.2, 0, Math.PI, Math.PI * 2);
        else x.ellipse(0, 0, r * rad, r * rad * 0.2, 0, 0, Math.PI);
        x.stroke();
      }
      x.restore();
    };

    // 1. the half of the rings passing behind the planet
    drawRings(true);

    // 2. the globe on top of them
    const body = x.createRadialGradient(cx - r * 0.3, cy - r * 0.3, 0, cx, cy, r);
    body.addColorStop(0, `rgba(${a.r},${a.g},${a.b},1)`);
    body.addColorStop(1, `rgba(${b.r},${b.g},${b.b},1)`);
    x.fillStyle = body;
    x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.fill();
    // re-apply bands over the repainted globe
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 8; i++) {
      const f = (i + 0.5) / 8;
      const y = -r + f * r * 2;
      const w = r * Math.cos((f - 0.5) * Math.PI * 0.5);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},${0.18 + (i % 2) * 0.18})`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.05, 0, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // 3. the front half of the rings
    drawRings(false);

    // 4. the planet's shadow falling across the near rings
    x.save();
    x.translate(cx, cy);
    x.rotate(TILT);
    x.globalCompositeOperation = "multiply";
    x.fillStyle = "rgba(20,14,4,0.55)";
    x.beginPath();
    x.ellipse(r * 0.42, 0, r * 0.4, r * 0.3, 0, 0, Math.PI);
    x.fill();
    x.restore();
  }

  private paintUranus(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, _a: any, _b: any, k: any) {
    // An ice giant knocked on its side: near-featureless, rings nearly vertical.
    const TILT = -1.37;   // ~98 degrees

    // whisper-faint banding along the tilted axis
    x.save();
    x.translate(cx, cy);
    x.rotate(TILT);
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 5; i++) {
      const f = (i + 0.5) / 5;
      const y = -r + f * r * 2;
      const w = r * Math.cos((f - 0.5) * Math.PI * 0.5);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},0.16)`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.05, 0, 0, Math.PI * 2); x.fill();
    }
    // the pole faces us — a soft bright disc offset along the axis
    x.globalCompositeOperation = "lighter";
    const pg = x.createRadialGradient(0, -r * 0.45, 0, 0, -r * 0.45, r * 0.7);
    pg.addColorStop(0, "rgba(220,255,250,0.3)");
    pg.addColorStop(1, "rgba(220,255,250,0)");
    x.fillStyle = pg;
    x.beginPath(); x.arc(0, -r * 0.45, r * 0.7, 0, Math.PI * 2); x.fill();
    x.restore();

    // narrow dark rings, orbiting almost vertically
    x.save();
    x.translate(cx, cy);
    x.rotate(TILT);
    for (const [rad, w, al] of [[1.32, 2.2, 0.5], [1.46, 1.4, 0.34], [1.6, 1, 0.22]] as Array<[number,number,number]>) {
      x.strokeStyle = `rgba(190, 240, 250, ${al})`;
      x.lineWidth = w;
      x.beginPath();
      x.ellipse(0, 0, r * rad, r * rad * 0.14, 0, 0, Math.PI * 2);
      x.stroke();
    }
    x.restore();
  }

  private paintNeptune(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, _a: any, _b: any, k: any) {
    // Deepest blue: supersonic winds, a dark anticyclone, bright methane cirrus.
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 7; i++) {
      const f = (i + 0.5) / 7;
      const y = -r + f * r * 2;
      const w = r * Math.cos((f - 0.5) * Math.PI * 0.45);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},${0.3 + (i % 2) * 0.2})`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.045, 0, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // the Great Dark Spot, with a bright methane collar
    const sx = cx - r * 0.2, sy = cy + r * 0.05;
    x.fillStyle = "rgba(12, 20, 48, 0.9)";
    x.beginPath(); x.ellipse(sx, sy, r * 0.2, r * 0.115, -0.15, 0, Math.PI * 2); x.fill();
    x.strokeStyle = "rgba(210, 232, 255, 0.5)";
    x.lineWidth = 1.4;
    x.beginPath(); x.ellipse(sx, sy, r * 0.22, r * 0.13, -0.15, 0, Math.PI * 2); x.stroke();

    // high-altitude methane cirrus, casting faint shadows
    x.globalAlpha = 0.6;
    x.fillStyle = "#eaf4ff";
    for (const [sy2, sw] of [[-0.42, 0.5], [-0.05, 0.62], [0.36, 0.44], [0.58, 0.3]] as Array<[number,number]>) {
      x.beginPath();
      x.ellipse(cx + r * 0.05, cy + sy2 * r, sw * r, r * 0.032, 0, 0, Math.PI * 2);
      x.fill();
    }
    x.globalAlpha = 1;

    // "the Scooter" — a fast-moving bright cloud
    x.fillStyle = "rgba(190, 225, 255, 0.7)";
    x.beginPath(); x.ellipse(cx + r * 0.32, cy - r * 0.3, r * 0.1, r * 0.05, 0.2, 0, Math.PI * 2); x.fill();

    // Triton, a small captured moon
    const tx = cx - r * 1.3, ty = cy - r * 0.55, tr = r * 0.15;
    const tg = x.createRadialGradient(tx - tr * 0.3, ty - tr * 0.3, 0, tx, ty, tr);
    tg.addColorStop(0, "#e3eef0"); tg.addColorStop(1, "#6a7d84");
    x.fillStyle = tg;
    x.beginPath(); x.arc(tx, ty, tr, 0, Math.PI * 2); x.fill();
  }

  private paintPluto(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, _a: any, _b: any, k: any) {
    // Small, mottled, tan-and-charcoal, with a vast heart-shaped nitrogen plain.
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "multiply";
    for (let i = 0; i < 4; i++) {
      const f = (i + 0.5) / 4;
      const y = -r + f * r * 2;
      const w = r * Math.cos((f - 0.5) * Math.PI * 0.5);
      x.fillStyle = `rgba(${k.r},${k.g},${k.b},0.38)`;
      x.beginPath(); x.ellipse(0, y, w, r * 0.05, 0, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // dark equatorial blotches (the "whale")
    x.globalAlpha = 0.45;
    x.fillStyle = "#2f241a";
    for (const [bx, by, bw, bh] of [[-0.42, 0.12, 0.22, 0.1], [-0.08, 0.2, 0.16, 0.07]] as Array<[number,number,number,number]>) {
      x.beginPath(); x.ellipse(cx + bx * r, cy + by * r, bw * r, bh * r, 0.1, 0, Math.PI * 2); x.fill();
    }
    x.globalAlpha = 1;

    // Tombaugh Regio — the bright nitrogen-ice heart
    x.fillStyle = "rgba(238, 230, 252, 0.92)";
    const leftCx = cx - r * 0.05, rightCx = cx + r * 0.05, topY = cy - r * 0.05;
    x.beginPath();
    x.moveTo(cx, cy + r * 0.22);
    x.bezierCurveTo(cx - r * 0.4, cy - r * 0.1, leftCx - r * 0.12, topY - r * 0.1, leftCx, topY + r * 0.05);
    x.bezierCurveTo(leftCx + r * 0.06, topY + r * 0.16, rightCx - r * 0.06, topY + r * 0.16, rightCx, topY + r * 0.05);
    x.bezierCurveTo(rightCx + r * 0.12, topY - r * 0.1, cx + r * 0.4, cy - r * 0.1, cx, cy + r * 0.22);
    x.closePath();
    x.fill();
    // convection cells within the ice sheet
    x.globalAlpha = 0.3;
    x.strokeStyle = "#b9aedd";
    x.lineWidth = 0.8;
    for (let i = 0; i < 6; i++) {
      const px = cx + (i % 3 - 1) * r * 0.12;
      const py = cy + Math.floor(i / 3) * r * 0.1 - r * 0.02;
      x.beginPath(); x.arc(px, py, r * 0.055, 0, Math.PI * 2); x.stroke();
    }
    x.globalAlpha = 1;

    // Charon — the oversized binary companion
    const chx = cx - r * 1.34, chy = cy + r * 0.52, chr = r * 0.42;
    const cg2 = x.createRadialGradient(chx - chr * 0.3, chy - chr * 0.3, 0, chx, chy, chr);
    cg2.addColorStop(0, "#b9ae9d"); cg2.addColorStop(1, "#4a4237");
    x.fillStyle = cg2;
    x.beginPath(); x.arc(chx, chy, chr, 0, Math.PI * 2); x.fill();
    x.fillStyle = "rgba(60,40,38,0.65)";
    x.beginPath(); x.ellipse(chx, chy - chr * 0.62, chr * 0.6, chr * 0.3, 0, 0, Math.PI * 2); x.fill();
    x.strokeStyle = "rgba(40,34,28,0.5)";
    x.lineWidth = 1;
    x.beginPath(); x.arc(chx, chy, chr, 0, Math.PI * 2); x.stroke();
  }

  private paintSun(x: CanvasRenderingContext2D, cx: number, cy: number, r: number, a: any, _b: any, _k: any) {
    // A star, not a planet: convection granules, sunspot groups, arcing prominences.

    // corona rays
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "lighter";
    for (let i = 0; i < 28; i++) {
      const ang = (i / 28) * Math.PI * 2;
      const len = r * (1.0 + (i % 4) * 0.13);
      const wid = r * 0.05;
      x.save();
      x.rotate(ang);
      const grd = x.createLinearGradient(r, 0, r + len, 0);
      grd.addColorStop(0, `rgba(${a.r},${a.g},${a.b},0.9)`);
      grd.addColorStop(1, `rgba(${a.r},${a.g},${a.b},0)`);
      x.fillStyle = grd;
      x.beginPath();
      x.moveTo(r, -wid); x.lineTo(r + len, 0); x.lineTo(r, wid);
      x.closePath(); x.fill();
      x.restore();
    }
    x.restore();

    // photospheric granulation — convection cells across the disc
    x.save();
    x.translate(cx, cy);
    x.beginPath(); x.arc(0, 0, r, 0, Math.PI * 2); x.clip();
    x.globalCompositeOperation = "lighter";
    for (let i = 0; i < 46; i++) {
      const ang = i * 2.399;                 // golden-angle scatter
      const d = Math.sqrt(i / 46) * r * 0.95;
      const px = Math.cos(ang) * d;
      const py = Math.sin(ang) * d;
      const cr = r * (0.07 + ((i * 3) % 5) * 0.016);
      const g = x.createRadialGradient(px, py, 0, px, py, cr);
      g.addColorStop(0, `rgba(255, 246, 210, 0.5)`);
      g.addColorStop(1, "rgba(255,160,40,0)");
      x.fillStyle = g;
      x.beginPath(); x.arc(px, py, cr, 0, Math.PI * 2); x.fill();
    }
    x.restore();

    // sunspot groups — dark umbra inside a lighter penumbra
    for (const [sx, sy, sr] of [[-0.25, -0.1, 0.075], [0.3, 0.25, 0.05], [-0.08, 0.42, 0.038]] as Array<[number,number,number]>) {
      const px = cx + sx * r, py = cy + sy * r, pr = sr * r;
      x.fillStyle = "rgba(190, 95, 20, 0.55)";
      x.beginPath(); x.ellipse(px, py, pr * 1.9, pr * 1.45, 0.3, 0, Math.PI * 2); x.fill();
      x.fillStyle = "rgba(90, 24, 0, 0.88)";
      x.beginPath(); x.ellipse(px, py, pr, pr * 0.8, 0.3, 0, Math.PI * 2); x.fill();
    }

    // solar prominences — plasma arcs looping off the limb
    x.save();
    x.translate(cx, cy);
    x.globalCompositeOperation = "lighter";
    x.strokeStyle = "rgba(255, 120, 50, 0.65)";
    for (const [ang, size] of [[-0.6, 0.3], [2.2, 0.24], [3.6, 0.2]] as Array<[number, number]>) {
      x.save();
      x.rotate(ang);
      x.lineWidth = r * 0.035;
      x.beginPath();
      x.moveTo(r * 0.97, -r * size * 0.42);
      x.quadraticCurveTo(r * (1 + size * 1.5), 0, r * 0.97, r * size * 0.42);
      x.stroke();
      x.restore();
    }
    x.restore();
  }

  private hexToRgb(h: string) {
    const n = parseInt(h.replace("#", ""), 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  /** "#rrggbb" or "r,g,b" → "r,g,b" */
  private rgbOf(h: string): string {
    if (h.includes(",")) return h;
    const c = this.hexToRgb(h);
    return `${c.r},${c.g},${c.b}`;
  }

  /* ---------------- helpers ---------------- */

  private speed() {
    if (this.survival) {
      // endless: ramps forever but eases off so it stays readable
      return Math.min(620, 150 + this.playTime * 3.2 + this.survivalWave * 16);
    }
    return Math.min(360 + this.stageN * 14, 135 + this.playTime * 4 + this.stageN * 11);
  }

  /** effective difficulty tier used by spawners */
  private tierLevel() {
    return this.survival ? this.survivalWave : this.stageN;
  }

  get isSurvival() { return this.survival; }
  get currentWave() { return this.survivalWave; }

  private worldFactor() {
    return this.fxSlow > 0 ? 0.42 : 1;
  }

  private pointMult() {
    return this.fxDouble > 0 ? 2 : 1;
  }

  private vibrate(p: VibratePattern) {
    try { navigator.vibrate?.(p); } catch { /* unsupported */ }
  }

  /** start-of-stage intro pop */
  private introFlash() {
    this.cb.onStageIntro(this.stageN, STAGES[this.stageN - 1].name, STAGES[this.stageN - 1].subtitle, STAGES[this.stageN - 1].distanceTarget);
  }

  /* ---------------- update ---------------- */

  private update(realDt: number) {
    const dt = realDt * this.timeScale;
    const wdt = dt * this.worldFactor();
    this.time += dt;

    if (this.mode === "dying" && this.dieClock >= 0) {
      this.dieClock += realDt;
      if (this.dieClock > 1.05) {
        this.dieClock = -1;
        this.finalizeDeath();
      }
    }
    if (this.mode === "transition" && this.transT >= 0) {
      this.transT += dt;
      if (this.transT > 1.6) {
        this.transT = -1;
        if (this.awaitingBoss) {
          // promote the queued boss into the world — this is the fight starting
          this.bossActive = this.awaitingBoss;
          this.awaitingBoss = null;
          this.mode = "boss";
          // no stage banner here: the boss intro owns the screen
        } else {
          this.mode = "play";
          this.introFlash();
        }
      }
    }
    /* --- victory fly-off: a three-beat cinematic exit ---------------------
       0.0–0.9s  HOVER  : the comet holds, drifts to centre, engines spool up
       0.9–1.6s  CHARGE : it pulls back slightly, glow intensifying
       1.6s+     BURN   : hard acceleration off the top of the screen        */
    if (this.mode === "flyout" && this.flyoutT >= 0) {
      this.flyoutT += realDt;
      const p0 = this.player;
      const t = this.flyoutT;

      if (t < 0.9) {
        // HOVER — recentre and settle while the engines wind up
        p0.x += (this.W / 2 - p0.x) * Math.min(1, realDt * 2.2);
        p0.y += (this.H * 0.58 - p0.y) * Math.min(1, realDt * 1.8);
        // idle shimmer
        if (this.particles.length < 150 && Math.random() < realDt * 26) {
          this.particles.push({
            x: p0.x + (Math.random() - 0.5) * 16, y: p0.y + 12,
            vx: (Math.random() - 0.5) * 30, vy: 60 + Math.random() * 50,
            life: 0.35, max: 0.4, size: 2.5 + Math.random() * 2,
            glow: this.ball.trail === "rainbow" ? "cyan" : this.ball.trail,
            streak: false,
          });
        }
      } else if (t < 1.6) {
        // CHARGE — a slight recoil dip, exhaust building
        p0.y += 46 * realDt;
        p0.x += (this.W / 2 - p0.x) * Math.min(1, realDt * 3);
        if (this.particles.length < 160) {
          for (let k = 0; k < 2; k++) {
            this.particles.push({
              x: p0.x + (Math.random() - 0.5) * 14, y: p0.y + 12,
              vx: (Math.random() - 0.5) * 60, vy: 150 + Math.random() * 130,
              life: 0.3 + Math.random() * 0.2, max: 0.5,
              size: 3 + Math.random() * 3,
              glow: this.ball.trail === "rainbow" ? "cyan" : this.ball.trail,
              streak: true,
            });
          }
        }
        if (t < 0.95) {
          this.shake = Math.max(this.shake, 6);
          this.cb.sfx.launch();
        }
      } else {
        // BURN — exponential acceleration out of frame
        const boost = Math.min(1, (t - 1.6) / 0.5);
        p0.y -= (240 + boost * boost * 2400) * realDt;
        p0.x += (this.W / 2 - p0.x) * Math.min(1, realDt * 2.4);
        this.shake = Math.max(this.shake, 4 * (1 - boost));
        if (this.particles.length < 170) {
          for (let k = 0; k < 3; k++) {
            this.particles.push({
              x: p0.x + (Math.random() - 0.5) * 12, y: p0.y + 10,
              vx: (Math.random() - 0.5) * 80, vy: 280 + Math.random() * 240,
              life: 0.3 + Math.random() * 0.2, max: 0.5,
              size: 3 + Math.random() * 4,
              glow: this.ball.trail === "rainbow" ? "cyan" : this.ball.trail,
              streak: true,
            });
          }
        }
      }

      p0.ty = p0.y;
      p0.tx = p0.x;
      this.trail.unshift({ x: p0.x, y: p0.y });
      if (this.trail.length > 26) this.trail.length = 26;

      // end on the timer, or shortly after the comet clears the frame
      const gone = p0.y < -90;
      if (this.flyoutT > 3.2 || (gone && this.flyoutT > 2.5)) {
        this.flyoutT = -1;
        this.finishStage();
      }
    }

    if (this.introT >= 0) {
      this.introT += dt;
      if (this.introT > 1.0) this.introT = -1;
    }

    if (this.mode === "play" || this.mode === "boss") this.playTime += wdt;

    if (this.fxSlow > 0) this.fxSlow -= dt;
    if (this.fxDouble > 0) this.fxDouble -= dt;
    if (this.fxMagnet > 0) this.fxMagnet -= dt;
    if (this.ultActive > 0) {
      this.ultActive -= dt;
      // Absolute Zero's wall of cold races outward across the screen
      if (this.ability.ultimate.kind === "absoluteZero") {
        this.ultFreezeR = Math.min(Math.max(this.W, this.H) * 1.25, this.ultFreezeR + dt * 900);
      }
      if (this.ultActive <= 0) {
        this.ultActive = 0;
        this.ultFreezeR = 0;
        if (this.prismCycle) {
          const next = this.prismForms[this.prismTransformIndex % this.prismForms.length] ?? "pulse";
          this.prismTransformIndex = (this.prismTransformIndex + 1) % this.prismForms.length;
          this.setBall(next, true);
          this.burst(this.player.x, this.player.y, 28, "white", 300);
          this.floaters.push({
            x: this.player.x, y: this.player.y - 48,
            txt: `${this.ability.gun.name.toUpperCase()} INHERITED`,
            life: 1.8, col: "rgba(255,255,255,",
          });
        }
      }
    }
    // expanding shockwave rings
    for (let i = this.ultRings.length - 1; i >= 0; i--) {
      const r = this.ultRings[i];
      if (!r) continue;
      r.life -= dt;
      r.r += (r.max - r.r) * Math.min(1, dt * 4.5);
      if (r.life <= 0) this.ultRings.splice(i, 1);
    }
    if (this.ultWell) {
      this.ultWell.t -= dt;
      if (this.ultWell.t <= 0) this.ultWell = null;
    }

    /* --- player movement (suspended during the victory fly-off) --- */
    const p = this.player;
    if (p.alive && this.mode !== "flyout") {
      if (this.mode === "attract") {
        p.tx = this.W * 0.5 + Math.sin(this.time * 0.5) * this.W * 0.16;
        p.ty = this.H * 0.68 + Math.sin(this.time * 0.83) * 26;
      } else {
        const kv = 540 * dt;
        if (this.keys.has("arrowleft") || this.keys.has("a")) p.tx -= kv;
        if (this.keys.has("arrowright") || this.keys.has("d")) p.tx += kv;
        if (this.keys.has("arrowup") || this.keys.has("w")) p.ty -= kv;
        if (this.keys.has("arrowdown") || this.keys.has("s")) p.ty += kv;
        if (this.keys.has(" ") || this.keys.has("f") || this.keys.has("j")) this.fire();
        if (this.keys.has("shift") || this.keys.has("u") || this.keys.has("k")) this.useUlt();
      }
      p.tx = Math.max(p.r, Math.min(this.W - p.r, p.tx));
      p.ty = Math.max(this.H * 0.18, Math.min(this.H - p.r, p.ty));
      const k = 1 - Math.exp(-dt * 13);
      p.x += (p.tx - p.x) * k;
      p.y += (p.ty - p.y) * k;

      this.trail.unshift({ x: p.x, y: p.y });
      const maxTrail = this.quality === 0 ? 10 : 16;
      if (this.trail.length > maxTrail) this.trail.length = maxTrail;

      /* ---- AI CO-PILOTS (stacked, max 3) ----
         Each flies its own escort slot, dodges incoming fire, picks a target
         and leads its shots. They serve independently and expire on their own. */
      for (let ci = this.copilots.length - 1; ci >= 0; ci--) {
        const co = this.copilots[ci];
        if (!co) continue;
        co.t -= dt;
        if (co.t <= 0) {
          this.burst(co.x, co.y, 8, "cosmic", 200);
          this.floaters.push({
            x: this.floatX(co.x), y: this.freeFloatY(co.x, co.y - 26),
            txt: "CO-PILOT RTB", life: 1.2, col: "rgba(148,163,184,",
          });
          this.copilots.splice(ci, 1);
          continue;
        }
        co.phase += dt * 1.6;
        if (co.shield > 0) co.shield -= dt;
        const a = this.ability;

        // 1. target: boss first, else nearest alien
        let tx: number | null = null;
        let ty: number | null = null;
        if (this.bossActive && this.bossActive.entered) {
          tx = this.bossActive.x; ty = this.bossActive.y;
        } else if (this.aliens.length) {
          let best = Infinity;
          for (const al of this.aliens) {
            const d = (al.x - co.x) ** 2 + (al.y - co.y) ** 2;
            if (d < best) { best = d; tx = al.x; ty = al.y; }
          }
        }

        // 2. dodge nearby hostile fire
        let dodgeX = 0, dodgeY = 0;
        for (const ast of this.asteroids) {
          const dx = co.x - ast.x, dy = co.y - ast.y;
          const d2 = dx * dx + dy * dy;
          const danger = (ast.r + 42) ** 2;
          if (d2 < danger) {
            const d = Math.sqrt(d2) || 1;
            const w = (1 - d / Math.sqrt(danger)) * 230;
            dodgeX += (dx / d) * w; dodgeY += (dy / d) * w;
          }
        }

        // 3. escort slot — fanned out so stacked pilots never overlap
        const ang = -Math.PI / 2 + (co.slot - 1) * 0.85;
        const slotX = p.x + Math.cos(ang) * 66 + Math.sin(co.phase) * 8;
        const slotY = p.y + Math.sin(ang) * 46 + Math.cos(co.phase * 0.8) * 6;
        const wantX = tx !== null ? slotX * 0.45 + tx * 0.55 : slotX;
        const wantY = tx !== null ? Math.max(this.H * 0.3, slotY) : slotY;
        const gx = Math.max(14, Math.min(this.W - 14, wantX + dodgeX));
        const gy = Math.max(this.H * 0.16, Math.min(this.H - 14, wantY + dodgeY));
        const k2 = 1 - Math.exp(-dt * 7.5);
        co.x += (gx - co.x) * k2;
        co.y += (gy - co.y) * k2;

        // 4. fire — always armed, independent of the player's weapon uptime
        co.fireT -= dt;
        if (co.fireT <= 0) {
          co.fireT = a.gun.rate * 1.7;
          let aimX = 0, aimY = -1;
          if (tx !== null && ty !== null) {
            const dx = tx - co.x, dy = ty - co.y;
            const d = Math.hypot(dx, dy) || 1;
            aimX = dx / d; aimY = dy / d;
          }
          this.shootBullet(
            co.x, co.y - 10, aimX, aimY,
            "#d946ef", "#ffffff",
            a.gun.damage * 0.7,
            a.gun.speed,
            { homing: a.archetype === "seeking" ? 4 : 0, r: 4, life: 1.3, owner: 2 },
          );
        }
      }

      this.ambientT -= dt;
      if (this.ambientT <= 0 && this.mode !== "dying") {
        this.ambientT = this.quality === 0 ? 0.14 : 0.06;
        const glow =
          this.ball.ambient === "rainbow"
            ? RAINBOW_CYCLE[Math.floor(this.rainbowWalk++ / 2) % RAINBOW_CYCLE.length]
            : this.ball.ambient;
        const vy = this.ballId === "fire" ? -46 : this.ballId === "cosmic" ? -18 : 34;
        this.particles.push({
          x: p.x + (Math.random() - 0.5) * 14,
          y: p.y + (Math.random() - 0.5) * 10 + 6,
          vx: (Math.random() - 0.5) * 24,
          vy: vy + Math.random() * 20,
          life: 0.4 + Math.random() * 0.3,
          max: 0.7,
          size: 2.4 + Math.random() * 3.4,
          glow,
          streak: false,
        });
      }

      /* drive the active ultimate — sustained kinds tick far faster than
         projectile kinds so the freeze / gravity well feel continuous */
      if (this.ultActive > 0) {
        const k = this.ability.ultimate.kind;
        const sustained = k === "absoluteZero" || k === "blackHole" || k === "novaBurst";
        const rate = sustained ? 0.05 : this.ability.ultimate.rate;
        if (this.time - this.ultT > rate) {
          this.ultT = this.time;
          this.fireUltPulse();
        }
      }
    }

    if (p.shield > 0) p.shield -= dt;

    /* --- stars drift --- */
    const flyBurn = this.mode === "flyout" && this.flyoutT > 1.6;
    const drift = (flyBurn ? 2600 : this.mode === "flyout" ? 90 : this.mode === "play" || this.mode === "boss" ? this.speed() : 60) * wdt * 0.22;
    for (const s of this.stars) {
      s.y += drift * s.z * 3 + wdt * 6 * s.z;
      if (s.y > this.H + 4) {
        s.y = -4;
        s.x = Math.random() * this.W;
      }
    }

    /* --- pre-boss spawning + travel (only while mode === "play") --- */
    // Pickups and hazards keep flowing during boss fights — only the travel
    // meter and the boss trigger are exclusive to the approach phase.
    const inAction = (this.mode === "play" || this.mode === "boss") && p.alive;
    if (inAction) {
      if (this.mode === "play") {
        this.distance += wdt * (2.2 + this.stageN * 0.12);
        this.emitDistance();
      }

      this.spawnA -= wdt;
      if (this.spawnA <= 0) {
        this.spawnAsteroid();
        const base = Math.max(0.26, 1.05 - this.playTime * 0.011 - this.tierLevel() * 0.02);
        this.spawnA = base * (0.7 + Math.random() * 0.6) * (this.mode === "boss" ? 1.7 : 1);
      }
      this.spawnP -= wdt;
      if (this.spawnP <= 0) {
        this.spawnPickup("shard");
        this.spawnP = 1.05 + Math.random() * 0.7;
      }
      this.spawnS -= wdt;
      if (this.spawnS <= 0) {
        this.spawnPickup("shield");
        this.spawnS = 12 + Math.random() * 9;
      }
      this.spawnSl -= wdt;
      if (this.spawnSl <= 0) {
        this.spawnPickup("slowmo");
        this.spawnSl = 15 + Math.random() * 11;
      }
      this.spawnD -= wdt;
      if (this.spawnD <= 0) {
        this.spawnPickup("double");
        this.spawnD = 13 + Math.random() * 10;
      }
      this.spawnG -= wdt;
      if (this.spawnG <= 0) {
        this.spawnPickup("gun");
        // keep re-offering quickly until armed, then settle into a normal cadence
        this.spawnG = WEAPON_ORB_INTERVAL;
      }
      this.spawnM -= wdt;
      if (this.spawnM <= 0) {
        this.spawnPickup("magnet");
        this.spawnM = 12 + Math.random() * 8;
      }
      this.spawnCo -= wdt;
      if (this.spawnCo <= 0) {
        this.spawnPickup("copilot");
        this.spawnCo = 11 + Math.random() * 5;
      }
      this.spawnSq -= wdt;
      if (this.spawnSq <= 0) {
        this.spawnPickup("squadron");
        this.spawnSq = 48 + Math.random() * 20;   // rare: it's a screen-clearing power
      }
      // alien interceptors — appear once you're a little way into a stage
      this.spawnAlien -= wdt;
      if (this.spawnAlien <= 0 && this.distance > this.distanceTarget * 0.05) {
        this.spawnAlienShip();
        // aliens arrive far more often, and press harder in later stages
        const base = Math.max(1.1, 6.5 - this.tierLevel() * 0.45);
        this.spawnAlien = base + Math.random() * 2.5;
        // deeper stages send them in pairs
        if (this.tierLevel() >= 4 && Math.random() < 0.45) this.spawnAlienShip();
        if (this.tierLevel() >= 8 && Math.random() < 0.4) this.spawnAlienShip();
      }
      if (!this.lifeDropped && this.stageN >= 2 && p.lives < 5 && this.playTime > 30 && Math.random() < wdt / 26) {
        this.lifeDropped = true;
        this.spawnPickup("life");
      }

      // survival drip-feed score
      this.score += wdt * 4 * this.combo * this.pointMult();
      this.emitScore();

      if (this.survival && this.mode === "play") {
        // endless: waves escalate every 25 seconds, forever
        this.survivalT += wdt;
        if (this.survivalT >= 25) {
          this.survivalT = 0;
          this.survivalWave++;
          this.buildBackground();   // next wave, next sky
          this.shake = Math.max(this.shake, 7);
          this.cb.sfx.stageClear();
          this.floaters.push({
            x: this.W / 2, y: this.H * 0.34,
            txt: `WAVE ${this.survivalWave}`, life: 1.8, col: "rgba(250,204,21,",
          });
          // every 3rd wave hands out a fresh weapon + a shield to survive it
          if (this.survivalWave % 3 === 0) this.spawnPickup("gun");
          if (this.survivalWave % 4 === 0) this.spawnPickup("shield");
        }
      } else if (this.mode === "play" && this.distance >= this.distanceTarget && !this.bossActive && !this.awaitingBoss) {
        // campaign: reaching the target summons the planet boss
        this.spawnBoss();
      }

      // combo decay
      if (this.combo > 1) {
        this.comboT -= wdt;
        if (this.comboT <= 0) this.combo = 1;
      }
    }

    /* --- boss fight --- */
    if (this.mode === "boss" && this.bossActive) {
      this.updateBoss(wdt);
      this.emitDistance();
    }

    /* --- asteroids --- */
    for (let i = this.asteroids.length - 1; i >= 0; i--) {
      const a = this.asteroids[i];
      if (!a) continue;   // AoE effects / boss death can shrink this mid-loop
      if (a.kind === "dart" && p.alive && (this.mode === "play" || this.mode === "boss")) {
        const want = Math.sign(p.x - a.x) * 150;
        a.vx += Math.max(-320 * wdt, Math.min(320 * wdt, want - a.vx));
      } else {
        a.wob += wdt * 1.7;
      }
      // status: chill slows it, burn eats away at it
      let mv = 1;
      if (a.slowT && a.slowT > 0) { a.slowT -= wdt; mv = 0.38; }
      if (a.frozenT && a.frozenT > 0) { a.frozenT -= wdt; mv = 0; a.vr = 0; }
      if (a.burnT && a.burnT > 0) {
        a.burnT -= wdt;
        a.hp = (a.hp ?? 3) - (a.burnDps ?? 1) * wdt;
        if (Math.random() < wdt * 9) {
          this.particles.push({
            x: a.x + (Math.random() - 0.5) * a.r, y: a.y + (Math.random() - 0.5) * a.r,
            vx: (Math.random() - 0.5) * 24, vy: -40 - Math.random() * 30,
            life: 0.3, max: 0.3, size: 2.5, glow: "fire", streak: false,
          });
        }
        if (a.hp <= 0) {
          this.explodeAsteroid(a);
          this.addScore(8 * this.pointMult(), a.x, a.y, "BURN", PALETTE.fire);
          this.asteroids.splice(i, 1);
          continue;
        }
      }
      a.x += (a.vx + (a.kind === "rock" ? Math.sin(a.wob) * 14 : 0)) * wdt * mv;
      a.y += a.vy * (this.mode === "attract" ? 0.5 : 1) * wdt * mv;
      a.rot += a.vr * wdt;

      if ((this.mode === "play" || this.mode === "boss") && p.alive && !a.near && a.y > p.y + a.r) {
        a.near = true;
        if (Math.abs(a.x - p.x) < a.r + 46) {
          this.addScore(5 * this.pointMult(), a.x, a.y, "close", PALETTE.violet);
        }
      }

      if (a.y > this.H + a.r + 60 || a.x < -a.r - 80 || a.x > this.W + a.r + 80) {
        this.asteroids.splice(i, 1);
        continue;
      }

      if (p.alive && (this.mode === "play" || this.mode === "boss")) {
        const rr = a.r * 0.82 + p.r * 0.95;
        if ((a.x - p.x) ** 2 + (a.y - p.y) ** 2 < rr * rr) {
          if (p.shield > 0) {
            p.shield = 0;
            this.explodeAsteroid(a);
            this.asteroids.splice(i, 1);
            this.shake = Math.max(this.shake, 9);
            this.vibrate([30, 30, 50]);
            this.cb.sfx.shieldBreak();
            this.emitPowers(true);
          } else {
            this.hitPlayer();
            this.asteroids.splice(i, 1);
          }
        }
      }
    }

    /* --- pickups --- */
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const u = this.pickups[i];
      if (!u) continue;
      u.spin += wdt * 2.4;
      u.y += u.vy * (this.mode === "attract" ? 0.5 : 1) * wdt;

      if (p.alive && (this.mode === "play" || this.mode === "boss")) {
        const dx = p.x - u.x;
        const dy = p.y - u.y;
        const d2 = dx * dx + dy * dy;
        // coin-magnet active: every pickup within a large radius gets sucked hard
        if (this.fxMagnet > 0 && u.kind === "shard") {
          const bigR = 220;
          if (d2 < bigR * bigR) {
            const d = Math.sqrt(d2) || 1;
            // cross-screen pull, scaled by proximity
            const pull = (1 - d / bigR) * 1100 + 220;
            u.x += (dx / d) * pull * wdt;
            u.y += (dy / d) * pull * wdt;
            // spark trail
            if (Math.random() < 0.4) {
              this.particles.push({
                x: u.x, y: u.y, vx: (Math.random() - 0.5) * 30, vy: 40,
                life: 0.35, max: 0.35, size: 2.4, glow: "amber", streak: false,
              });
            }
          }
        }
        const magR = u.kind === "shard" ? 88 : 86;
        if (d2 < magR * magR) {
          const d = Math.sqrt(d2) || 1;
          const pull = (1 - d / magR) * 620;
          u.x += (dx / d) * pull * wdt;
          u.y += (dy / d) * pull * wdt;
        }
        if (d2 < (p.r + u.r + 4) ** 2) {
          this.collect(u);
          this.pickups.splice(i, 1);
          continue;
        }
      }
      if (u.y > this.H + 30) {
        if (u.kind === "shard" && (this.mode === "play" || this.mode === "boss") && this.combo > 1) {
          this.combo = 1;
        }
        this.pickups.splice(i, 1);
      }
    }

    /* --- alien interceptors --- */
    if (this.mode === "play" || this.mode === "boss") this.updateAliens(wdt, dt);

    /* --- multi-pilot squadron: formation flight + saturation fire --- */
    if (this.squadronT > 0) {
      this.squadronT -= dt;
      const pl = this.player;
      const a = this.ability;
      for (const w of this.squadron) {
        w.phase += dt * 2.2;
        // hold formation with a light weave
        const tx = pl.x + w.ox + Math.sin(w.phase) * 10;
        const ty = pl.y + w.oy + Math.cos(w.phase * 0.8) * 8;
        const k = 1 - Math.exp(-dt * 8);
        w.x += (tx - w.x) * k;
        w.y += (ty - w.y) * k;

        // heavy, rapid fire — this is the point of the power-up
        w.fireT -= dt;
        if (w.fireT <= 0 && pl.alive) {
          w.fireT = 0.14;
          // lead the nearest target, else straight up
          let ax = 0, ay = -1;
          let best = Infinity;
          const aim = (txx: number, tyy: number) => {
            const d = (txx - w.x) ** 2 + (tyy - w.y) ** 2;
            if (d < best) { best = d; const l = Math.sqrt(d) || 1; ax = (txx - w.x) / l; ay = (tyy - w.y) / l; }
          };
          if (this.bossActive && this.bossActive.entered) aim(this.bossActive.x, this.bossActive.y);
          for (const al of this.aliens) aim(al.x, al.y);
          for (const ast of this.asteroids) if (!ast.isBossProjectile) aim(ast.x, ast.y);
          this.shootBullet(
            w.x, w.y - 8, ax, ay,
            w.hue, "#ffffff",
            a.gun.damage * 0.9,
            a.gun.speed * 1.15,
            { r: 4, life: 1.2, owner: 2 },
          );
        }
      }
      if (this.squadronT <= 0) {
        this.squadronT = 0;
        for (const w of this.squadron) this.burst(w.x, w.y, 10, "cyan", 220);
        this.squadron = [];
        this.floaters.push({
          x: this.floatX(this.player.x), y: this.freeFloatY(this.player.x, this.player.y - 40),
          txt: "SQUADRON RTB", life: 1.4, col: "rgba(148,163,184,",
        });
      }
    }


    /* --- Supernova auto-recharge (20s, independent of combo) --- */
    if ((this.mode === "play" || this.mode === "boss") && !this.ultReady && this.ultActive <= 0) {
      this.ultCharge -= dt;
      if (this.ultCharge <= 0) {
        this.ultCharge = 0;
        this.ultReady = true;
        this.floaters.push({
          x: this.floatX(p.x), y: this.freeFloatY(p.x, p.y - 44),
          txt: "SUPERNOVA READY", life: 1.6, col: "rgba(250,204,21,",
        });
        this.cb.sfx.upgrade();
        this.emitUlt(true);
      }
      this.emitUltCharge();
    }

    /* --- weapon uptime: an orb keeps the gun online for 10 seconds --- */
    if (this.weaponArmed && (this.mode === "play" || this.mode === "boss")) {
      this.weaponT -= dt;
      if (this.weaponT <= 0) {
        this.weaponArmed = false;
        this.weaponT = 0;
        this.gunCharges = 0;
        this.floaters.push({
          x: this.floatX(p.x), y: this.freeFloatY(p.x, p.y - 46), txt: "WEAPON OFFLINE", life: 1.4, col: "rgba(248,113,113,",
        });
        this.cb.sfx.shieldBreak();
        this.emitGun(true);
      }
    }

    /* --- automatic weapon fire (no button — armed by weapon orbs) --- */
    if (this.weaponArmed && p.alive && (this.mode === "play" || this.mode === "boss")) {
      const cadence = this.ability.gun.rate;
      if (this.time - this.lastFireT >= cadence) {
        this.lastFireT = this.time;
        this.fireBullet();
      }
    }

    /* --- bullets --- */
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      if (!b) continue;   // defeatBoss() can clear this array mid-loop
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (b.life <= 0 || b.x < -40 || b.x > this.W + 40 || b.y < -40 || b.y > this.H + 40) {
        this.bullets.splice(i, 1);
        continue;
      }
      // homing: rotate velocity toward the boss if present
      if (b.homing > 0 && this.bossActive) {
        const bb = this.bossActive;
        const tdx = bb.x - b.x;
        const tdy = bb.y - b.y;
        const tlen = Math.hypot(tdx, tdy) || 1;
        const targetVx = (tdx / tlen) * Math.hypot(b.vx, b.vy);
        const targetVy = (tdy / tlen) * Math.hypot(b.vx, b.vy);
        const blend = Math.min(1, b.homing * dt);
        b.vx += (targetVx - b.vx) * blend;
        b.vy += (targetVy - b.vy) * blend;
      }
      b.wob += dt;
      b.age += dt;
      // hit boss
      if (this.bossActive && this.mode === "boss" && this.bossActive.entered) {
        const bb = this.bossActive;
        const rr = (bb.r * 0.7) + 4;
        const dx = b.x - bb.x;
        const dy = b.y - bb.y;
        if (dx * dx + dy * dy < rr * rr) {
          this.damageBoss(bb, b.damage);
          this.applyEffectToBoss(b, bb);
          this.burst(b.x, b.y, 6, "white", 200);
          if (b.pierce > 0) { b.pierce--; }   // punch through and keep going
          else { this.bullets.splice(i, 1); continue; }
        }
      }
      // hit small asteroid (during play too)
      if (this.mode === "play" || this.mode === "boss") {
        for (let k = this.asteroids.length - 1; k >= 0; k--) {
          const a = this.asteroids[k];
          if (!a) continue;   // array can shrink underneath us via AoE effects
          if ((a.x - b.x) ** 2 + (a.y - b.y) ** 2 < (a.r + b.r) ** 2) {
            const hx = a.x, hy = a.y;
            // Glacier's blades leave a surviving rock chilled while still
            // dealing their full direct damage; other weapons retain one-hit rocks.
            if (b.effect === "slow" || b.effect2 === "slow") {
              a.slowT = Math.max(a.slowT ?? 0, 3.2);
              a.hp = (a.hp ?? 3) - b.damage;
              this.burst(hx, hy, 7, "ice", 170);
              if ((a.hp ?? 0) <= 0) {
                this.explodeAsteroid(a);
                this.asteroids.splice(k, 1);
                this.addScore(8 * this.pointMult(), hx, hy, "+8", PALETTE.amber);
              } else {
                this.applyEffectOnImpact(b, hx, hy);
              }
            } else {
              this.explodeAsteroid(a);
              this.asteroids.splice(k, 1);
              this.applyEffectOnImpact(b, hx, hy);
              this.addScore(8 * this.pointMult(), hx, hy, "+8", PALETTE.amber);
            }
            this.cb.sfx.hit();
            if (b.pierce > 0) { b.pierce--; break; }
            if (b.bounces > 0 && this.ricochet(b)) break;
            this.bullets.splice(i, 1);
            break;
          }
        }
      }
    }

    /* --- particles / floaters --- */
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const q = this.particles[i];
      q.life -= dt;
      if (q.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.vx *= 1 - dt * 2.2;
      q.vy *= 1 - dt * 2.2;
      q.vy += dt * 60;
    }
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i];
      f.life -= dt;
      f.y -= dt * 44;
      if (f.life <= 0) this.floaters.splice(i, 1);
    }

    this.shake *= Math.exp(-realDt * 7);
    this.flash *= Math.exp(-realDt * 4);
    this.bossFlash *= Math.exp(-realDt * 5);

    this.emitPowers();
  }

  /* ---------------- boss logic ---------------- */

  private spawnBoss() {
    const stage = STAGES[this.stageN - 1];
    // A boss fight must always be winnable: if the player somehow arrives
    // without having picked up a weapon orb, arm them now.
    if (!this.weaponArmed) {
      this.weaponArmed = true;
      this.weaponT = WEAPON_DURATION;
      this.gunCharges = Math.max(1, this.gunCharges);
      this.floaters.push({
        x: this.player.x, y: this.player.y - 50,
        txt: `${this.ability.gun.name.toUpperCase()} ONLINE`,
        life: 1.8, col: "rgba(103,232,249,",
      });
      this.emitGun(true);
    }
    const base = Math.max(44, Math.min(this.W * 0.2, 80 - this.stageN * 1.2));
    const r = base * (stage.boss.scale ?? 1);
    this.prerenderBoss();   // guarantee the sprite matches this stage
    const boss: Boss = {
      def: stage.boss,
      stageN: this.stageN,
      hp: stage.boss.hp,
      hpMax: stage.boss.hp,
      x: this.W / 2,
      y: -r - 40,
      vx: 0,
      vy: 0,
      r,
      t: 0,
      pattern: stage.boss.ability.pattern(1),
      shakeT: 0,
      lastShotT: 0,
      hintShown: false,
      deathT: -1,
      entered: false,
      slowT: 0,
      burnT: 0,
      burnDps: 0,
      gravT: 0,
      windDir: 1,
      windT: 0,
    };
    this.awaitingBoss = boss;
    this.transT = 0;
    this.mode = "transition";
    this.cb.sfx.boss();
    this.cb.onBossSpawn(stage.boss.name, stage.boss.title, stage.boss.body, boss.hp, boss.hpMax, stage.boss.ability.hint);
    this.cb.onBossHp(boss.hp, boss.hpMax);
  }

  private updateBoss(wdt: number) {
    const b = this.bossActive;
    if (!b) return;
    // chill slows the boss's whole action clock
    if (b.slowT > 0) { b.slowT -= wdt; wdt *= 0.45; }
    // burn ticks damage over time
    if (b.burnT > 0) {
      b.burnT -= wdt;
      this.damageBoss(b, b.burnDps * wdt, true);
      if (Math.random() < wdt * 7) {
        this.particles.push({
          x: b.x + (Math.random() - 0.5) * b.r, y: b.y + (Math.random() - 0.5) * b.r,
          vx: (Math.random() - 0.5) * 30, vy: -50 - Math.random() * 40,
          life: 0.4, max: 0.4, size: 3, glow: "fire", streak: false,
        });
      }
    }
    b.t += wdt;
    b.shakeT = Math.max(0, b.shakeT - wdt);

    // entry
    // --- entry glide: finishes on a threshold so the fight can actually begin ---
    if (!b.entered) {
      const target = b.r + 152;
      b.y += (target - b.y) * Math.min(1, wdt * 4.5);
      b.x = this.W / 2 + Math.sin(b.t * 1.6) * (this.W * 0.22);
      if (Math.abs(target - b.y) < 4) {
        b.y = target;
        b.entered = true;
        b.lastShotT = 0.6;   // opens fire almost immediately on arrival
      }
      return;
    }

    /* ---- unique movement signature per boss ---- */
    const p = this.player;
    const midX = this.W / 2;
    const topY = b.r + 152;   // clear of the top meter and the score / lives HUD
    switch (b.pattern) {
      case "swarm": // MERCURY — fast, skittish, darts across the top
        b.x += Math.sin(b.t * 2.6) * 190 * wdt;
        b.y = topY + Math.sin(b.t * 3.1) * 26;
        break;
      case "ring": // VENUS — almost stationary, slow heavy pulse
        b.x += Math.sin(b.t * 0.45) * 40 * wdt;
        b.y = topY + Math.sin(b.t * 0.7) * 10;
        break;
      case "crescent": // EARTH — tracks the player's column steadily
        b.x += Math.sign(p.x - b.x) * Math.min(Math.abs(p.x - b.x), 70) * wdt;
        b.y = topY + Math.sin(b.t * 1.3) * 18;
        break;
      case "sandstorm": // MARS — wide slow sweeps corner to corner
        b.x = midX + Math.sin(b.t * 0.6) * (this.W * 0.3);
        b.y = topY + Math.cos(b.t * 0.9) * 30;
        break;
      case "pull": // JUPITER — immense, barely moves, drags the player in
        b.x = midX + Math.sin(b.t * 0.3) * 30;
        b.y = topY + 8;
        if (p.alive) {
          const dx = b.x - p.x;
          const dy = b.y - p.y;
          const d = Math.hypot(dx, dy) || 1;
          const g = 120 / Math.max(0.6, d / 180);
          p.tx += (dx / d) * g * wdt;
          p.ty += (dy / d) * g * wdt;
        }
        break;
      case "rings": // SATURN — glides in a wide steady orbit
        b.x = midX + Math.cos(b.t * 0.8) * (this.W * 0.28);
        b.y = topY + Math.sin(b.t * 1.6) * 22;
        break;
      case "ice_storm": // URANUS — tilted, rolls side to side
        b.x = midX + Math.sin(b.t * 1.1) * (this.W * 0.24);
        b.y = topY + Math.sin(b.t * 2.2) * 14;
        break;
      case "current": // NEPTUNE — surges then drifts, like a tide
        b.x += Math.sin(b.t * 0.5) * 150 * wdt * (1 + Math.sin(b.t * 2) * 0.6);
        b.y = topY + Math.sin(b.t * 0.8) * 24;
        break;
      case "flares": // PLUTO — erratic teleport-like jitters
        if (Math.floor(b.t * 1.5) !== Math.floor((b.t - wdt) * 1.5)) {
          b.x = 60 + Math.random() * (this.W - 120);
          this.burst(b.x, b.y, 14, "violet", 240);
        }
        b.y = topY + Math.sin(b.t * 2.4) * 18;
        break;
      case "supernova": // THE SUN — centre of the arena, slow menacing pulse
        b.x = midX + Math.sin(b.t * 0.35) * 24;
        b.y = topY + 20 + Math.sin(b.t * 0.6) * 12;
        break;
      default:
        b.x += Math.sin(b.t * 0.9) * 90 * wdt;
        b.y = topY + Math.sin(b.t * 1.1) * 18;
    }
    b.x = Math.max(b.r + 24, Math.min(this.W - b.r - 24, b.x));

    /* ---- attack cadence varies per boss ---- */
    const cadence: Record<string, number> = {
      swarm: 0.95, ring: 2.15, crescent: 1.15, sandstorm: 1.6, pull: 2.0,
      rings: 1.35, ice_storm: 1.1, current: 1.3, flares: 1.5, supernova: 1.75,
    };
    b.lastShotT += wdt;
    if (b.lastShotT > (cadence[b.pattern] ?? 0.9)) {
      b.lastShotT = 0;
      this.bossFire(b);
    }

    if (b.pattern === "pull") {
      b.gravT -= wdt;
      if (b.gravT <= 0) {
        b.gravT = 3.4;
        // spawn giant rocks from corners
        for (let i = 0; i < 3; i++) {
          const side = i % 2 === 0 ? -1 : 1;
          this.asteroids.push({
            x: side < 0 ? 30 : this.W - 30,
            y: this.H * 0.2 + Math.random() * (this.H * 0.4),
            vx: -side * (60 + Math.random() * 60),
            vy: (Math.random() - 0.3) * 80,
            r: 26 + Math.random() * 18,
            rot: 0,
            vr: (Math.random() - 0.5) * 1.5,
            verts: [1, 1, 1, 1, 1, 1],
            hue: PALETTE.amber,
            kind: "rock",
            wob: 0,
            near: true,
          });
        }
      }
    }
    if (b.pattern === "current") {
      b.windT -= wdt;
      if (b.windT <= 0) {
        b.windT = 6;
        b.windDir = (b.windDir === 1 ? -1 : 1) as 1 | -1;
      }
      // drift player
      const p = this.player;
      if (p.alive) p.tx += b.windDir * 90 * wdt;
    }

    if (b.shakeT > 0) this.shake = Math.max(this.shake, 4);
  }

  /** Every boss attacks with its own distinct geometry. */
  private bossFire(b: Boss) {
    const cx = b.x, cy = b.y;
    const t = b.t;
    const p = this.player;
    const aim = Math.atan2(p.y - cy, p.x - cx);
    const shot = (ang: number, r = 7) =>
      this.spawnBossProjectile(cx, cy, Math.cos(ang), Math.sin(ang), r, 1, b.pattern);

    switch (b.pattern) {
      // MERCURY — aimed buckshot: a tight cone fired straight at the comet
      case "swarm": {
        for (let i = -1; i <= 1; i++) shot(aim + i * 0.14 + (Math.random() - 0.5) * 0.05, 7);
        break;
      }
      // VENUS — full pressure ring with ONE rotating safe gap to slip through
      case "ring": {
        const n = 14;
        const gap = (t * 0.9) % (Math.PI * 2);
        for (let i = 0; i < n; i++) {
          const ang = (i / n) * Math.PI * 2;
          let d = Math.abs(ang - gap);
          if (d > Math.PI) d = Math.PI * 2 - d;
          if (d < 0.42) continue;         // the gap
          shot(ang, 6);
        }
        break;
      }
      // EARTH — a sweeping wall that wipes across the arena like a terminator
      case "crescent": {
        const sweep = Math.sin(t * 0.8);
        for (let i = 0; i < 5; i++) {
          const spread = (i - 2) * 0.2;
          shot(Math.PI / 2 + spread + sweep * 0.55, 7);
        }
        break;
      }
      // MARS — dust curtain: slow boulders rain down across the full width
      case "sandstorm": {
        for (let i = 0; i < 3; i++) {
          const x = (this.W / 3) * (i + 0.5) + (Math.random() - 0.5) * 30;
          this.asteroids.push({
            x, y: -16,
            vx: (Math.random() - 0.5) * 30, vy: 120 + Math.random() * 40,
            r: 11 + Math.random() * 5, rot: Math.random() * 6,
            vr: (Math.random() - 0.5) * 1.1, verts: [1, 1, 1],
            hue: PALETTE.rose, kind: "dart", wob: 0, near: true,
            isBossProjectile: true, weapon: "dustBall",
          });
        }
        break;
      }
      // JUPITER — twin counter-rotating spiral arms
      case "pull": {
        for (let arm = 0; arm < 2; arm++) {
          const base = t * 2.2 + arm * Math.PI;
          for (let i = 0; i < 2; i++) shot(base + i * 0.3, 9);
        }
        break;
      }
      // SATURN — a flat ring belt fired along the planet's ring plane
      case "rings": {
        const tilt = -0.32;
        for (let i = 0; i < 6; i++) {
          const f = (i / 5) * 2 - 1;        // -1..1 across the belt
          shot(tilt + (f < 0 ? Math.PI : 0) + f * 0.22, 7);
        }
        break;
      }
      // URANUS — alternating side walls; the safe side flips each volley
      case "ice_storm": {
        const fromLeft = Math.floor(t * 0.7) % 2 === 0;
        for (let i = 0; i < 4; i++) {
          const y = this.H * (0.2 + i * 0.13);
          this.asteroids.push({
            x: fromLeft ? -16 : this.W + 16, y,
            vx: (fromLeft ? 1 : -1) * (150 + i * 12), vy: 22,
            r: 8, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 2,
            verts: [1, 1, 1], hue: PALETTE.ice, kind: "dart", wob: 0,
            near: true, isBossProjectile: true, weapon: "iceChunk",
          });
        }
        break;
      }
      // NEPTUNE — a serpentine current that snakes down the screen
      case "current": {
        for (let i = 0; i < 3; i++) {
          const ang = Math.PI / 2 + Math.sin(t * 2.4 + i * 0.5) * 0.7;
          shot(ang, 6);
        }
        break;
      }
      // PLUTO — erratic flare clusters at random bearings
      case "flares": {
        const bursts = 1 + Math.floor(Math.random() * 2);
        for (let k = 0; k < bursts; k++) {
          const base = Math.random() * Math.PI * 2;
          for (let i = 0; i < 2; i++) shot(base + i * 0.18, 6);
        }
        break;
      }
      // THE SUN — alternates a full corona ring with an aimed lance volley
      case "supernova": {
        const ringPhase = Math.floor(t * 0.75) % 2 === 0;
        if (ringPhase) {
          for (let i = 0; i < 14; i++) shot((i / 14) * Math.PI * 2 + t * 0.4, 6);
        } else {
          for (let i = -2; i <= 2; i++) shot(aim + i * 0.15, 7);
        }
        break;
      }
    }
  }

  /** Atmospheric density per stage — 0 = airless rock, >1 = stellar corona. */
  private static readonly ATMOS: Record<number, number> = {
    1: 0,     // Mercury — no atmosphere
    2: 1.0,   // Venus    — crushing cloud deck
    3: 0.55,  // Earth
    4: 0.18,  // Mars     — thin
    5: 0.85,  // Jupiter
    6: 0.7,   // Saturn
    7: 0.75,  // Uranus
    8: 0.8,   // Neptune
    9: 0.04,  // Pluto    — tenuous
    10: 1.5,  // The Sun  — corona
  };

  /** Each boss pattern fires the weapon that suits its planetary nature. */
  private static readonly BOSS_WEAPON: Record<string, { weapon: NonNullable<Asteroid["weapon"]>; hue: [number, number, number]; speed: number; spin: number }> = {
    swarm:     { weapon: "rock",         hue: PALETTE.amber,  speed: 240, spin: 3.0 }, // Mercury — molten pebbles
    ring:      { weapon: "pressureRing", hue: PALETTE.gold,   speed: 170, spin: 0   }, // Venus   — pressure rings
    crescent:  { weapon: "moonShard",    hue: PALETTE.frost,  speed: 230, spin: 1.6 }, // Earth   — lunar shards
    sandstorm: { weapon: "dustBall",     hue: PALETTE.rose,   speed: 150, spin: 1.1 }, // Mars    — dust boulders
    pull:      { weapon: "stormBolt",    hue: PALETTE.fire,   speed: 260, spin: 0   }, // Jupiter — storm bolts
    rings:     { weapon: "iceChunk",     hue: PALETTE.gold,   speed: 250, spin: 2.4 }, // Saturn  — ring ice
    ice_storm: { weapon: "iceChunk",     hue: PALETTE.ice,    speed: 200, spin: 2.0 }, // Uranus  — ice fragments
    current:   { weapon: "windLance",    hue: PALETTE.sky,    speed: 300, spin: 0   }, // Neptune — wind lances
    flares:    { weapon: "frostFlare",   hue: PALETTE.nebula, speed: 215, spin: 0   }, // Pluto   — frozen flares
    supernova: { weapon: "solarLance",   hue: PALETTE.fire,   speed: 280, spin: 0   }, // Sun     — solar lances
  };

  private spawnBossProjectile(x: number, y: number, dx: number, dy: number, r: number, _dmg: number, pattern = "swarm") {
    const w = NovaEngine.BOSS_WEAPON[pattern] ?? NovaEngine.BOSS_WEAPON.swarm;
    const len = Math.hypot(dx, dy) || 1;
    this.asteroids.push({
      x, y,
      vx: (dx / len) * w.speed,
      vy: (dy / len) * w.speed,
      r,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * w.spin,
      verts: [1, 1, 1],
      hue: w.hue,
      kind: "dart",
      wob: 0,
      near: true,
      isBossProjectile: true,
      weapon: w.weapon,
    });
  }

  /* ---------------- weapon effects ---------------- */

  /** Status effects a bullet inflicts on a boss it strikes. */
  private applyEffectToBoss(b: Bullet, boss: Boss) {
    for (const eff of [b.effect, b.effect2]) {
      switch (eff) {
        case "slow":
          boss.slowT = Math.max(boss.slowT, 2.5);
          this.burst(b.x, b.y, 4, "ice", 120);
          break;
        case "burn":
          boss.burnT = Math.max(boss.burnT, 3.5);
          boss.burnDps = Math.max(boss.burnDps, b.damage * 0.8);
          break;
        case "explosive":
          this.detonate(b.x, b.y, 62, b.damage * 0.7, "cosmic");
          break;
        case "radiant":
          this.detonate(b.x, b.y, 48, b.damage * 0.5, "gold");
          break;
      }
    }
  }

  /** Status effects applied where a bullet lands (asteroid / miss). */
  private applyEffectOnImpact(b: Bullet, x: number, y: number) {
    for (const eff of [b.effect, b.effect2]) {
      switch (eff) {
        case "slow":
          this.chillNearby(x, y, 82, b.damage);
          break;
        case "burn":
          this.igniteNearby(x, y, 56, b.damage * 0.8);
          break;
        case "explosive":
          this.detonate(x, y, 62, b.damage * 0.7, "cosmic");
          break;
        case "radiant":
          this.detonate(x, y, 48, b.damage * 0.5, "gold");
          break;
      }
    }
  }

  /** AoE blast: damages the boss and clears nearby hostile fire. */
  private detonate(x: number, y: number, radius: number, dmg: number, glow: string) {
    this.burst(x, y, 14, glow, 280);
    const r2 = radius * radius;
    for (let i = this.asteroids.length - 1; i >= 0; i--) {
      const a = this.asteroids[i];
      if ((a.x - x) ** 2 + (a.y - y) ** 2 < r2) {
        this.explodeAsteroid(a);
        this.asteroids.splice(i, 1);
      }
    }
    for (let i = this.aliens.length - 1; i >= 0; i--) {
      const al = this.aliens[i];
      if ((al.x - x) ** 2 + (al.y - y) ** 2 < r2) al.hp -= dmg;
    }
    if (this.bossActive && this.bossActive.entered) {
      const bb = this.bossActive;
      if ((bb.x - x) ** 2 + (bb.y - y) ** 2 < (radius + bb.r) ** 2) this.damageBoss(bb, dmg);
    }
  }

  private applyEffectToAlien(b: Bullet, alien: Alien) {
    for (const eff of [b.effect, b.effect2]) {
      if (eff === "burn") {
        // Alien burn is represented as immediate extra damage to avoid a
        // separate timer system; the primary bullet damage is always retained.
        alien.hp -= b.damage * 0.35;
      } else if (eff === "explosive") {
        this.detonate(alien.x, alien.y, 62, b.damage * 0.7, "cosmic");
      } else if (eff === "radiant") {
        this.detonate(alien.x, alien.y, 48, b.damage * 0.5, "gold");
      }
    }
  }

  /** Glacier's chill: slows rocks AND alien craft, and chips at them. */
  private chillNearby(x: number, y: number, radius: number, dmg = 0) {
    const r2 = radius * radius;
    for (const a of this.asteroids) {
      if ((a.x - x) ** 2 + (a.y - y) ** 2 < r2) {
        a.slowT = Math.max(a.slowT ?? 0, 3.2);
        if (dmg > 0) {
          a.burnT = Math.max(a.burnT ?? 0, 0.8);
          a.burnDps = Math.max(a.burnDps ?? 0, dmg * 0.5);
        }
      }
    }
    for (const al of this.aliens) {
      if ((al.x - x) ** 2 + (al.y - y) ** 2 < r2) {
        al.slowT = Math.max(al.slowT ?? 0, 3.2);
        if (dmg > 0) al.hp -= dmg * 0.35;
      }
    }
  }

  private igniteNearby(x: number, y: number, radius: number, dps: number) {
    const r2 = radius * radius;
    for (const a of this.asteroids) {
      if ((a.x - x) ** 2 + (a.y - y) ** 2 < r2) {
        a.burnT = Math.max(a.burnT ?? 0, 2.5);
        a.burnDps = Math.max(a.burnDps ?? 0, dps);
      }
    }
  }

  /** Redirect a bullet at the next nearest target. Returns false if none. */
  private ricochet(b: Bullet): boolean {
    let bx = 0, by = 0, best = Infinity;
    const consider = (tx: number, ty: number) => {
      const d = (tx - b.x) ** 2 + (ty - b.y) ** 2;
      if (d < best && d > 4) { best = d; bx = tx; by = ty; }
    };
    for (const a of this.asteroids) if (!a.isBossProjectile) consider(a.x, a.y);
    for (const al of this.aliens) consider(al.x, al.y);
    if (this.bossActive) consider(this.bossActive.x, this.bossActive.y);
    if (best === Infinity || best > 260 * 260) return false;
    const sp = Math.hypot(b.vx, b.vy) || 1;
    const dx = bx - b.x, dy = by - b.y;
    const d = Math.hypot(dx, dy) || 1;
    b.vx = (dx / d) * sp;
    b.vy = (dy / d) * sp;
    b.bounces--;
    b.life = Math.max(b.life, 0.7);
    this.burst(b.x, b.y, 4, "lime", 140);
    return true;
  }

  private damageBoss(b: Boss, dmg: number, silent = false) {
    b.hp = Math.max(0, b.hp - dmg);
    if (!silent) {
      b.shakeT = 0.2;
      this.bossFlash = 1;
      this.shake = Math.max(this.shake, 5);
    }
    this.cb.onBossHp(b.hp, b.hpMax);
    if (b.hp <= 0) this.defeatBoss();
  }

  private defeatBoss() {
    if (!this.bossActive) return;
    const b = this.bossActive;
    const bonus = 50 + this.stageN * 30;
    this.addScore(bonus, b.x, b.y, `BOSS +${bonus}`, PALETTE.gold, { credit: bonus, isBoss: true });
    void STAGES;
    for (let k = 0; k < 40; k++) {
      const ang = (k / 40) * Math.PI * 2;
      this.particles.push({
        x: b.x,
        y: b.y,
        vx: Math.cos(ang) * 340,
        vy: Math.sin(ang) * 340,
        life: 0.6,
        max: 0.6,
        size: 4 + Math.random() * 5,
        glow: k % 3 === 0 ? "gold" : k % 3 === 1 ? "amber" : "red",
        streak: k % 2 === 0,
      });
    }
    this.shake = 22;
    this.flash = 1;
    this.cb.sfx.stageClear();
    this.cb.sfx.explosion();
    this.vibrate([30, 40, 30, 40, 60]);

    this.cb.onBossDefeated(this.stageN, bonus);

    this.bossActive = null;
    this.awaitingBoss = null;
    this.asteroids = [];
    this.aliens = [];
    this.cb.onBossHp(0, 0);

    // Victory lap: the comet throttles up and streaks off-screen before the
    // stage-complete card appears. finishStage() runs when the flyout ends.
    this.mode = "flyout";
    this.flyoutT = 0;
    this.timeScale = 1;
    this.pickups = [];
    this.bullets = [];
    this.trail = [];
    this.weaponArmed = false;
    this.weaponT = 0;
    this.fxSlow = 0;
    this.fxDouble = 0;
    this.fxMagnet = 0;
  }

  /** Called once the victory flyout finishes — hands control back to the host. */
  private finishStage() {
    const grade = this.computeGrade();
    this.stagesCleared++;
    this.bestStageReached = Math.max(this.bestStageReached, this.stageN + 1);
    this.mode = "attract";
    this.trail = [];
    this.cb.onLevelComplete({ ...grade, finalScore: Math.floor(this.score) });
  }


  private computeGrade(): StarGrade {
    const stage = STAGES[this.stageN - 1];
    const passed = this.score >= stage.starThresholds[0];
    let stars = 0;
    if (this.score >= stage.starThresholds[2]) stars = 3;
    else if (this.score >= stage.starThresholds[1]) stars = 2;
    else if (this.score >= stage.starThresholds[0]) stars = 1;
    return { stars, passed, finalScore: Math.floor(this.score), deaths: this.deathsThisRun };
  }

  /* ---------------- spawning helpers ---------------- */

  private spawnAsteroid() {
    const t = this.playTime;
    const dart = t > 22 && Math.random() < Math.min(0.32, 0.1 + t * 0.002 + (this.stageN - 1) * 0.03);
    const r = dart ? 11 + Math.random() * 6 : 16 + Math.random() * 26;
    const hues = [PALETTE.cyan, PALETTE.violet, PALETTE.pink];
    const n = dart ? 3 : 6 + Math.floor(Math.random() * 3);
    const verts: number[] = [];
    for (let i = 0; i < n; i++) verts.push(0.72 + Math.random() * 0.5);
    this.asteroids.push({
      x: r + Math.random() * (this.W - r * 2),
      y: -r - 30,
      vx: dart ? 0 : (Math.random() - 0.5) * 40,
      vy: (dart ? 1.32 : 0.85 + Math.random() * 0.35) * this.speed(),
      r,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 2.4,
      verts,
      hue: dart ? PALETTE.red : hues[Math.floor(Math.random() * hues.length)],
      kind: dart ? "dart" : "rock",
      wob: Math.random() * 7,
      near: false,
    });
  }

  /* ---------------- alien interceptors ---------------- */

  private spawnAlienShip() {
    const styles: Alien["style"][] = ["drifter", "strafer", "circler", "ambusher"];
    const style = styles[Math.floor(Math.random() * styles.length)];
    const hues = ["#4ade80", "#34d399", "#a3e635", "#2dd4bf"];
    const fromLeft = Math.random() < 0.5;
    this.aliens.push({
      x: fromLeft ? -30 : this.W + 30,
      y: this.H * (0.12 + Math.random() * 0.3),
      vx: (fromLeft ? 1 : -1) * (40 + Math.random() * 50),
      vy: 0,
      hp: 3 + Math.floor(this.tierLevel() / 3),
      hpMax: 3 + Math.floor(this.tierLevel() / 3),
      r: 15,
      t: 0,
      style,
      fireT: 1 + Math.random(),
      gx: this.W * (0.2 + Math.random() * 0.6),
      gy: this.H * (0.12 + Math.random() * 0.3),
      goalT: 0,
      hue: hues[Math.floor(Math.random() * hues.length)],
      bob: Math.random() * 7,
    });
  }

  private updateAliens(wdt: number, dt: number) {
    const p = this.player;
    for (let i = this.aliens.length - 1; i >= 0; i--) {
      const al = this.aliens[i];
      if (!al) continue;
      // status: frozen solid halts the craft entirely; chill makes it sluggish
      let amv = 1;
      if (al.slowT && al.slowT > 0) { al.slowT -= wdt; amv = 0.4; }
      if (al.frozenT && al.frozenT > 0) {
        al.frozenT -= wdt;
        amv = 0;
        al.fireT = Math.max(al.fireT, 0.25);   // weapons offline while iced
      }
      al.t += wdt * amv;
      al.bob += wdt * 3 * amv;
      al.goalT -= wdt * amv;

      // --- random movement styles ---
      if (al.goalT <= 0) {
        // re-roll a wander goal; each style biases where it likes to sit
        al.goalT = 1.2 + Math.random() * 1.8;
        switch (al.style) {
          case "drifter":
            al.gx = 40 + Math.random() * (this.W - 80);
            al.gy = this.H * (0.1 + Math.random() * 0.35);
            break;
          case "strafer":
            // darts side to side at a fixed-ish altitude
            al.gx = Math.random() < 0.5 ? 50 : this.W - 50;
            al.gy = this.H * (0.12 + Math.random() * 0.22);
            break;
          case "circler":
            // orbits a point above the player
            al.gx = p.x + Math.cos(al.t * 1.6) * this.W * 0.3;
            al.gy = this.H * 0.2 + Math.sin(al.t * 1.2) * this.H * 0.1;
            break;
          case "ambusher":
            // swoops toward the player's column, then retreats
            al.gx = p.x + (Math.random() - 0.5) * 80;
            al.gy = this.H * (Math.random() < 0.4 ? 0.45 : 0.14);
            break;
        }
      }
      if (al.style === "circler") {
        al.gx = p.x + Math.cos(al.t * 1.5) * this.W * 0.32;
        al.gy = this.H * 0.22 + Math.sin(al.t * 1.1) * this.H * 0.08;
      }

      // steer toward goal with inertia (feels like a craft, not a lerp)
      const accel = al.style === "strafer" ? 520 : al.style === "ambusher" ? 460 : 300;
      const dx = al.gx - al.x;
      const dy = al.gy - al.y;
      const d = Math.hypot(dx, dy) || 1;
      al.vx += (dx / d) * accel * wdt;
      al.vy += (dy / d) * accel * wdt;
      const drag = Math.exp(-wdt * 1.9);
      al.vx *= drag;
      al.vy *= drag;
      const maxV = al.style === "strafer" ? 300 : 210;
      const sp = Math.hypot(al.vx, al.vy);
      if (sp > maxV) {
        al.vx = (al.vx / sp) * maxV;
        al.vy = (al.vy / sp) * maxV;
      }
      al.x += al.vx * wdt * amv;
      al.y += al.vy * wdt * amv;
      al.x = Math.max(24, Math.min(this.W - 24, al.x));
      al.y = Math.max(this.H * 0.07, Math.min(this.H * 0.62, al.y));

      // --- shooting at the comet: each craft type carries its own weapon ---
      al.fireT -= wdt * amv;
      if (amv > 0 && al.fireT <= 0 && p.alive && (this.mode === "play" || this.mode === "boss")) {
        const aim = Math.atan2(p.y - al.y, p.x - al.x);
        const fire = (ang: number, weapon: NonNullable<Asteroid["weapon"]>, sp: number, r: number, hue: [number, number, number]) => {
          this.asteroids.push({
            x: al.x, y: al.y + al.r * 0.6,
            vx: Math.cos(ang) * sp,
            vy: Math.sin(ang) * sp,
            r, rot: 0, vr: 0,
            verts: [1, 1, 1],
            hue,
            kind: "dart",
            wob: 0,
            near: true,
            isBossProjectile: true,
            weapon,
          });
        };

        switch (al.style) {
          case "strafer": // rapid plasma burst — three quick blobs
            al.fireT = 1.5 + Math.random() * 0.8;
            for (let s = -1; s <= 1; s++) fire(aim + s * 0.14, "alienPlasma", 230, 5, PALETTE.lime);
            break;
          case "circler": // precise laser line
            al.fireT = 1.8 + Math.random() * 0.9;
            fire(aim, "alienLaser", 340, 5, PALETTE.cyan);
            break;
          case "ambusher": // drops a slow spiked mine
            al.fireT = 2.4 + Math.random() * 1.2;
            fire(aim, "alienMine", 95, 9, PALETTE.lime);
            break;
          default: // drifter — lobbed plasma
            al.fireT = 2.0 + Math.random() * 1.1;
            fire(aim + (Math.random() - 0.5) * 0.18, "alienPlasma", 200, 6, PALETTE.lime);
        }
      }

      // --- player bullets hit it ---
      for (let k = this.bullets.length - 1; k >= 0; k--) {
        const b = this.bullets[k];
        if (!b) continue;
        if ((b.x - al.x) ** 2 + (b.y - al.y) ** 2 < (al.r + b.r) ** 2) {
          al.hp -= b.damage;
          if (b.effect === "slow" || b.effect2 === "slow") {
            al.slowT = Math.max(al.slowT ?? 0, 3.2);
            this.burst(al.x, al.y, 6, "ice", 150);
          } else {
            this.applyEffectToAlien(b, al);
          }
          this.bullets.splice(k, 1);
          this.burst(al.x, al.y, 5, "lime", 180);
          this.cb.sfx.hit();
          if (al.hp <= 0) break;
        }
      }
      if (al.hp <= 0) {
        this.burst(al.x, al.y, 22, "lime", 300);
        this.addScore(40 * this.pointMult(), al.x, al.y, "+40", PALETTE.lime);
        this.cb.sfx.explodeSmall();
        this.aliens.splice(i, 1);
        this.emitScore(true);
        continue;
      }

      // --- ramming the player ---
      if (p.alive && (this.mode === "play" || this.mode === "boss")) {
        const rr = al.r * 0.8 + p.r * 0.9;
        if ((al.x - p.x) ** 2 + (al.y - p.y) ** 2 < rr * rr) {
          if (p.shield > 0) {
            p.shield = 0;
            this.burst(al.x, al.y, 18, "lime", 280);
            this.aliens.splice(i, 1);
            this.cb.sfx.shieldBreak();
            this.emitPowers(true);
          } else {
            this.hitPlayer();
          }
        }
      }
    }
    void dt;
  }

  private drawAlien(al: Alien) {
    const { ctx } = this;
    const bobY = Math.sin(al.bob) * 2;
    ctx.save();
    ctx.translate(al.x, al.y + bobY);
    // banking into the turn
    ctx.rotate(Math.max(-0.4, Math.min(0.4, al.vx / 600)));

    // engine glow underneath
    ctx.globalCompositeOperation = "lighter";
    this.drawGlow(this.glows.get("lime"), 0, al.r * 0.7, al.r * 2.6, 0.55);
    ctx.globalCompositeOperation = "source-over";

    // saucer hull
    const hull = ctx.createLinearGradient(0, -al.r * 0.6, 0, al.r * 0.6);
    hull.addColorStop(0, "#e2e8f0");
    hull.addColorStop(0.45, "#64748b");
    hull.addColorStop(1, "#1e293b");
    ctx.fillStyle = hull;
    ctx.beginPath();
    ctx.ellipse(0, 0, al.r, al.r * 0.42, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(15,23,42,0.9)";
    ctx.lineWidth = 1.2;
    ctx.stroke();

    // glass dome
    const dome = ctx.createRadialGradient(-al.r * 0.15, -al.r * 0.35, 0, 0, -al.r * 0.2, al.r * 0.6);
    dome.addColorStop(0, "rgba(255,255,255,0.95)");
    dome.addColorStop(0.5, al.hue);
    dome.addColorStop(1, "rgba(16,70,50,0.9)");
    ctx.fillStyle = dome;
    ctx.beginPath();
    ctx.ellipse(0, -al.r * 0.22, al.r * 0.52, al.r * 0.44, 0, Math.PI, 0);
    ctx.fill();
    ctx.strokeStyle = "rgba(226,232,240,0.5)";
    ctx.lineWidth = 0.8;
    ctx.stroke();

    // under-lights
    for (let k = -1; k <= 1; k++) {
      const on = Math.sin(al.bob * 2 + k * 2) > -0.2;
      ctx.fillStyle = on ? al.hue : "rgba(30,41,59,0.9)";
      ctx.beginPath();
      ctx.arc(k * al.r * 0.5, al.r * 0.3, 1.8, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // HP pips above the craft
    if (al.hp > 0) {
      const total = al.hpMax;
      const w = 3;
      const gap = 2;
      const fullW = total * w + (total - 1) * gap;
      for (let k = 0; k < total; k++) {
        ctx.fillStyle = k < al.hp ? al.hue : "rgba(100,116,139,0.35)";
        ctx.fillRect(al.x - fullW / 2 + k * (w + gap), al.y - al.r - 8 + bobY, w, 2.5);
      }
    }
  }

  private spawnPickup(kind: Pickup["kind"]) {
    const speeds: Record<Pickup["kind"], number> = { shard: 0.6, shield: 0.52, slowmo: 0.5, double: 0.46, life: 0.4, gun: 0.95, magnet: 0.5, copilot: 0.5, squadron: 0.44 };
    const radii: Record<Pickup["kind"], number> = { shard: 9, shield: 13, slowmo: 13, double: 12, life: 13, gun: 14, magnet: 14, copilot: 15, squadron: 17 };
    // weapon orbs bias toward the middle third so they're easy to intercept
    const rad = radii[kind];
    const margin = rad + 10;
    const x = kind === "gun"
      ? this.W * 0.25 + Math.random() * this.W * 0.5
      : margin + Math.random() * Math.max(1, this.W - margin * 2);
    const p: Pickup = {
      x,
      y: -30,
      vy: this.speed() * speeds[kind],
      r: rad,
      kind,
      spin: Math.random() * 7,
    };
    this.pickups.push(p);
  }

  /* ---------------- fire / ultimate ---------------- */

  private fireBullet() {
    const p = this.player;
    const a = this.ability;
    const isUlt = this.ultActive > 0;
    const sp = (isUlt ? a.gun.speed * 1.4 : a.gun.speed) ;
    const dmg = (isUlt ? a.gun.damage * 2 : a.gun.damage) ;
    const col = isUlt ? a.ultimate.color : a.gun.color;
    const core = isUlt ? a.ultimate.color2 : a.gun.coreColor;
    const x = p.x;
    const y = p.y - p.r;
    const w = this.time;

    // muzzle flash — a short-lived bright burst at the barrel
    const muzzleN = a.archetype === "machinegun" ? 3 : a.archetype === "wavegun" ? 7 : a.archetype === "prismLance" ? 6 : 5;
    for (let i = 0; i < muzzleN; i++) {
      const spread = (Math.random() - 0.5) * (a.archetype === "prismLance" ? 0.5 : 1.1);
      const sp = 120 + Math.random() * 180;
      this.particles.push({
        x, y,
        vx: Math.sin(spread) * sp,
        vy: -Math.cos(spread) * sp - 60,
        life: 0.1 + Math.random() * 0.1,
        max: 0.2,
        size: 2 + Math.random() * 3.5,
        glow: a.archetype === "iceslash" ? "ice" : a.archetype === "wavegun" ? "fire" : a.archetype === "seeking" ? "cosmic" : "white",
        streak: true,
      });
    }

    // per-archetype firing pattern + orb bullet-count extension
    switch (a.archetype) {
      case "machinegun": {
        // tight stream — 1 fast shot + extra straight shots from count
        const n = 1;
        for (let i = 0; i < n; i++) {
          const jx = (i - (n - 1) / 2) * 2;
          this.shootBullet(x + jx, y, 0, -1, col, core, dmg, sp * (1 + 0.03 * i), { r: 4 });
        }
        break;
      }
      case "iceslash": {
        // 3-blade scissor spread
        const spread = 0.32;
        const dirs: Array<[number, number]> = [
          [0, -1],
          [-Math.sin(spread), -Math.cos(spread)],
          [Math.sin(spread), -Math.cos(spread)],
        ];
        for (const [dx, dy] of dirs) this.shootBullet(x, y, dx, dy, col, core, dmg, sp, { r: 5 });
        break;
      }
      case "wavegun": {
        // twin wave pulses per shot — alternating phase
        const phase = Math.sin(w * 18) * 0.18;
        this.shootBullet(x - 6, y, -0.1 + phase, -0.99, col, core, dmg, sp, { r: 5 });
        this.shootBullet(x + 6, y, 0.1 - phase, -0.99, col, core, dmg, sp, { r: 5 });
        break;
      }
      case "seeking": {
        // 2 homing missiles that curve toward the boss
        this.shootBullet(x - 4, y, -0.18, -0.98, col, core, dmg, sp, { homing: 4, r: 5, life: 1.8 });
        this.shootBullet(x + 4, y, 0.18, -0.98, col, core, dmg, sp, { homing: 4, r: 5, life: 1.8 });
        break;
      }
      case "prismLance": {
        // one focused lance of white light — power concentrated, not sprayed
        this.shootBullet(x, y, 0, -1, col, core, dmg, sp, { r: 6, life: 1.5 });
        break;
      }
      case "laser":
      default: {
        // thin focused beam
        this.shootBullet(x, y, 0, -1, col, core, dmg, sp, { r: 3 });
        break;
      }
    }

    this.cb.sfx.gun();
  }

  /**
   * Each character's ultimate is its own mechanic, matching the shop text.
   * Called repeatedly while the ultimate is active.
   */
  private fireUltPulse() {
    const a = this.ability;
    const p = this.player;
    const dmg = a.gun.damage * 2.2;

    if (this.prismCycle) {
      this.firePrismDestructionWave();
      return;
    }

    switch (a.ultimate.kind) {
      /* PULSE — NOVA BURST: expanding shockwave rings detonate outward */
      case "novaBurst": {
        const radius = 70 + ((this.time * 420) % 320);
        this.detonate(p.x, p.y, radius, dmg * 0.11, "cyan");
        if (this.ultRings.length < 6) this.ultRings.push({ x: p.x, y: p.y, r: 20, max: 330, life: 0.7, hue: "103,232,249" });
        this.shake = Math.max(this.shake, 3);
        break;
      }

      /* GLACIER — ABSOLUTE ZERO: the field freezes solid, then shatters */
      case "absoluteZero": {
        // An expanding wall of absolute cold. Anything the wave front touches
        // is flash-frozen SOLID — it stops dead — then fractures apart.
        const waveR = this.ultFreezeR;
        const w0 = Math.max(0, waveR - 120);

        for (const ast of this.asteroids) {
          const d = Math.hypot(ast.x - p.x, ast.y - p.y);
          if (d <= waveR) {
            // frozen solid for as long as the ultimate runs, plus a grace period
            ast.frozenT = Math.max(ast.frozenT ?? 0, this.ultActive + 1.6);
            ast.vx *= 0.3; ast.vy *= 0.3;
            // the ice itself crushes them
            ast.burnT = Math.max(ast.burnT ?? 0, 0.5);
            ast.burnDps = Math.max(ast.burnDps ?? 0, dmg * 0.9);
            // crystal shards burst off the moment the front hits
            if (d > w0 && this.particles.length < 150 && Math.random() < 0.3) {
              this.particles.push({
                x: ast.x, y: ast.y,
                vx: (Math.random() - 0.5) * 90, vy: (Math.random() - 0.5) * 90,
                life: 0.4, max: 0.4, size: 2 + Math.random() * 2.5,
                glow: "ice", streak: true,
              });
            }
          }
        }
        for (const al of this.aliens) {
          const d = Math.hypot(al.x - p.x, al.y - p.y);
          if (d <= waveR) {
            al.frozenT = Math.max(al.frozenT ?? 0, this.ultActive + 1.6);
            al.hp -= dmg * 0.08;
          }
        }
        // the boss is only chilled, never fully frozen
        if (this.bossActive?.entered) {
          const d = Math.hypot(this.bossActive.x - p.x, this.bossActive.y - p.y);
          if (d <= waveR + this.bossActive.r) {
            this.bossActive.slowT = Math.max(this.bossActive.slowT, 1.2);
            this.damageBoss(this.bossActive, dmg * 0.07, true);
          }
        }

        // the visible wave front
        if (this.ultRings.length < 3) {
          this.ultRings.push({ x: p.x, y: p.y, r: waveR * 0.85, max: waveR, life: 0.4, hue: "186,230,253" });
        }
        // drifting frost in the air
        if (this.particles.length < 150) {
          this.particles.push({
            x: Math.random() * this.W, y: Math.random() * this.H,
            vx: (Math.random() - 0.5) * 20, vy: 20 + Math.random() * 30,
            life: 0.6, max: 0.6, size: 2 + Math.random() * 3,
            glow: "ice", streak: false,
          });
        }
        break;
      }

      /* INFERNO — SOLAR FLARE: a sustained flamethrower beam up the screen */
      case "solarFlare": {
        const sweep = Math.sin(this.time * 2.2) * 0.3;
        for (let i = 0; i < 3; i++) {
          const ang = -Math.PI / 2 + sweep + (i - 1) * 0.1 + (Math.random() - 0.5) * 0.08;
          this.shootBullet(
            p.x, p.y - p.r, Math.cos(ang), Math.sin(ang),
            a.ultimate.color, a.ultimate.color2,
            dmg * 0.5, a.gun.speed * 1.15,
            { r: 7 + Math.random() * 4, life: 0.85 },
          );
        }
        // ignite anything already caught in the column
        for (const ast of this.asteroids) {
          if (Math.abs(ast.x - p.x) < 90 && ast.y < p.y) {
            ast.burnT = Math.max(ast.burnT ?? 0, 1.4);
            ast.burnDps = Math.max(ast.burnDps ?? 0, dmg * 0.4);
          }
        }
        break;
      }

      /* NEBULA — BLACK HOLE: a gravity well drags everything in and crushes it */
      case "blackHole": {
        // A collapsing singularity. It rips in EVERYTHING on screen — rocks,
        // alien craft, hostile fire, loose pickups — and shreds whatever gets
        // close. The boss is far too massive to be moved by it.
        const wx = p.x;
        const wy = p.y - this.H * 0.2;
        const R = Math.max(this.W, this.H) * 1.2;   // effectively the whole screen
        const EVENT_HORIZON = 54;

        // --- asteroids and hostile fire: violent inward acceleration ---
        for (let ai = this.asteroids.length - 1; ai >= 0; ai--) {
          const ast = this.asteroids[ai];
          if (!ast) continue;
          const dx = wx - ast.x, dy = wy - ast.y;
          const d = Math.hypot(dx, dy) || 1;
          if (d > R) continue;
          // inverse-falloff pull — brutal up close, still firm far away
          const pull = 2600 / Math.max(0.35, d / 150) + 900;
          ast.vx += (dx / d) * pull * 0.05;
          ast.vy += (dy / d) * pull * 0.05;
          // violent spin as they're torn in
          ast.vr += (Math.random() - 0.5) * 2.2;
          // tangential shear so they spiral rather than fall straight
          ast.vx += (-dy / d) * 150 * 0.05;
          ast.vy += (dx / d) * 150 * 0.05;
          // heavy damage to anything caught in the stream
          ast.burnT = Math.max(ast.burnT ?? 0, 0.4);
          ast.burnDps = Math.max(ast.burnDps ?? 0, dmg * 1.6);
          // crossing the event horizon destroys it outright
          if (d < EVENT_HORIZON) {
            this.explodeAsteroid(ast);
            this.asteroids.splice(ai, 1);
            this.addScore(6 * this.pointMult(), wx, wy, "", PALETTE.nebula);
            this.burst(wx, wy, 4, "cosmic", 180);
          }
        }

        // --- alien craft: dragged in and crushed ---
        for (let li = this.aliens.length - 1; li >= 0; li--) {
          const al = this.aliens[li];
          if (!al) continue;
          const dx = wx - al.x, dy = wy - al.y;
          const d = Math.hypot(dx, dy) || 1;
          if (d > R) continue;
          const pull = 900 / Math.max(0.4, d / 180) + 260;
          al.x += (dx / d) * pull * 0.05;
          al.y += (dy / d) * pull * 0.05;
          al.hp -= dmg * 0.18;                       // significant, not a tickle
          if (d < EVENT_HORIZON || al.hp <= 0) {
            this.burst(al.x, al.y, 18, "cosmic", 280);
            this.addScore(40 * this.pointMult(), al.x, al.y, "+40", PALETTE.lime);
            this.aliens.splice(li, 1);
            this.cb.sfx.explodeSmall();
          }
        }

        // --- loose pickups get hoovered toward the player as a bonus ---
        for (const u of this.pickups) {
          const dx = p.x - u.x, dy = p.y - u.y;
          const d = Math.hypot(dx, dy) || 1;
          u.x += (dx / d) * 420 * 0.05;
          u.y += (dy / d) * 420 * 0.05;
        }

        // --- the boss resists entirely; it only takes modest chip damage ---
        if (this.bossActive?.entered) this.damageBoss(this.bossActive, dmg * 0.05, true);

        // --- accretion debris spiralling into the core ---
        if (this.particles.length < 150) {
          for (let k = 0; k < 2; k++) {
            const ang = Math.random() * Math.PI * 2;
            const dist = 120 + Math.random() * 160;
            this.particles.push({
              x: wx + Math.cos(ang) * dist,
              y: wy + Math.sin(ang) * dist,
              vx: -Math.cos(ang) * 340 - Math.sin(ang) * 190,
              vy: -Math.sin(ang) * 340 + Math.cos(ang) * 190,
              life: 0.45, max: 0.45, size: 2 + Math.random() * 3,
              glow: Math.random() < 0.5 ? "cosmic" : "nebula", streak: true,
            });
          }
        }
        this.shake = Math.max(this.shake, 4);
        this.ultWell = { x: wx, y: wy, t: 0.3 };
        break;
      }

      /* PRISM — SPECTRUM STORM: rotating prism lances sweep the field */
      case "spectrumStorm":
      default: {
        const arms = 5;
        const spin = this.time * 2.6;
        for (let i = 0; i < arms; i++) {
          const ang = spin + (i / arms) * Math.PI * 2;
          this.shootBullet(
            p.x, p.y, Math.cos(ang), Math.sin(ang),
            a.ultimate.color, a.ultimate.color2,
            dmg * 0.6, a.gun.speed * 1.1,
            { r: 6, life: 1.1 },
          );
        }
        break;
      }
    }
    const uk = a.ultimate.kind;
    if (uk === "solarFlare" || uk === "spectrumStorm") this.cb.sfx.gun();
  }

  /** Prism's five-second radial wipe: repeated expanding rings clear hazards. */
  private firePrismDestructionWave() {
    const p = this.player;
    const radius = Math.max(this.W, this.H) * 1.35;
    const damage = Math.max(8, this.ability.gun.damage * 2.5);
    for (let i = this.asteroids.length - 1; i >= 0; i--) {
      const hazard = this.asteroids[i];
      if (!hazard) continue;
      this.burst(hazard.x, hazard.y, 5, "white", 210);
      this.asteroids.splice(i, 1);
    }
    for (let i = this.aliens.length - 1; i >= 0; i--) {
      const alien = this.aliens[i];
      if (!alien) continue;
      this.burst(alien.x, alien.y, 14, "white", 260);
      this.addScore(40 * this.pointMult(), alien.x, alien.y, "SHATTER", PALETTE.lime);
      this.aliens.splice(i, 1);
    }
    if (this.bossActive?.entered) this.damageBoss(this.bossActive, damage, true);
    this.ultRings.push({
      x: p.x, y: p.y, r: 18, max: radius, life: 0.42,
      hue: "255,255,255",
    });
    if (this.ultRings.length > 8) this.ultRings.shift();
    this.shake = Math.max(this.shake, 5);
    this.flash = Math.max(this.flash, 0.08);
    this.burst(p.x, p.y - 24, 8, "white", 240);
  }

  private shootBullet(
    x: number,
    y: number,
    dx: number,
    dy: number,
    color: string,
    core: string,
    dmg: number,
    speed: number,
    opts?: { homing?: number; r?: number; life?: number; owner?: 1 | 2; wob?: number },
  ) {
    const len = Math.hypot(dx, dy) || 1;
    this.bullets.push({
      x, y,
      vx: (dx / len) * speed,
      vy: (dy / len) * speed,
      life: opts?.life ?? 1.4,
      r: opts?.r ?? 5,
      color,
      core,
      damage: dmg,
      homing: opts?.homing ?? 0,
      owner: opts?.owner ?? 1,
      wob: opts?.wob ?? 0,
      arche: this.ability.archetype,
      effect: this.ability.effect,
      effect2: this.ability.effect2,
      pierce: this.ability.effect === "pierce" ? 3 : 0,
      bounces: this.ability.effect === "ricochet" || this.ability.effect2 === "ricochet" ? 2 : 0,
      age: 0,
    });
  }

  /* ---------------- collecting ---------------- */

  private collect(u: Pickup) {
    const p = this.player;
    switch (u.kind) {
      case "shard": {
        this.combo = Math.min(COMBO_MAX, this.combo + 1);
        this.comboT = COMBO_WINDOW;
        const gain = 10 * this.combo * this.pointMult();
        this.addScore(gain, u.x, u.y, `+${gain}`, PALETTE.cyan);
        this.burst(u.x, u.y, this.quality === 0 ? 6 : 10, this.trailGlowName(0), 160);
        this.cb.sfx.pickup(this.combo);
        this.emitScore(true);
        break;
      }
      case "shield": {
        p.shield = SHIELD_DURATION;
        this.addScore(25 * this.pointMult(), u.x, u.y, "SHIELD", PALETTE.amber);
        this.burst(u.x, u.y, 16, "amber", 200);
        this.cb.sfx.shieldUp();
        this.vibrate(25);
        this.emitScore(true);
        this.emitPowers(true);
        break;
      }
      case "slowmo": {
        this.fxSlow = 5.5;
        this.addScore(15 * this.pointMult(), u.x, u.y, "SLOW-MO", PALETTE.sky);
        this.burst(u.x, u.y, 16, "sky", 200);
        this.cb.sfx.slowmo();
        this.vibrate(20);
        this.emitScore(true);
        this.emitPowers(true);
        break;
      }
      case "double": {
        this.fxDouble = 8;
        this.addScore(10, u.x, u.y, "×2 SCORE", PALETTE.pink);
        this.burst(u.x, u.y, 16, "pink", 200);
        this.cb.sfx.doublePts();
        this.vibrate(20);
        this.emitScore(true);
        this.emitPowers(true);
        break;
      }
      case "life": {
        if (p.lives < 5) {
          p.lives++;
          this.addScore(10, u.x, u.y, "EXTRA LIFE", PALETTE.rose);
        } else {
          this.addScore(60 * this.pointMult(), u.x, u.y, "+60", PALETTE.rose);
        }
        this.burst(u.x, u.y, 20, "rose", 220);
        this.cb.sfx.life();
        this.vibrate([25, 30, 25]);
        this.emitScore(true);
        this.emitPowers(true);
        break;
      }
      case "gun": {
        this.gunCharges = Math.min(3, this.gunCharges + 1);
        const firstArm = !this.weaponArmed;
        this.weaponArmed = true;      // weapons go live & auto-fire from here on
        this.weaponT = WEAPON_DURATION;  // refresh the 10s uptime window
        if (firstArm) {
          this.floaters.push({
            x: this.floatX(p.x), y: this.freeFloatY(p.x, p.y - 56),
            txt: `${this.ability.gun.name.toUpperCase()} ONLINE`,
            life: 1.6, col: "rgba(103,232,249,",
          });
        }
        this.burst(u.x, u.y, 18, "violet", 220);
        this.cb.sfx.gun();
        this.vibrate([18, 18, 18]);
        this.emitScore(true);
        this.emitGun();
        break;
      }
      case "copilot": {
        if (this.copilots.length >= MAX_COPILOTS) {
          // already at the cap — top every pilot back up instead
          for (const c of this.copilots) c.t = COPILOT_DURATION;
          this.floaters.push({
            x: this.floatX(u.x), y: this.freeFloatY(u.x, u.y - 26),
            txt: "WING REFUELLED", life: 1.4, col: "rgba(217,70,239,",
          });
        } else {
          const slot = this.copilots.length;
          this.copilots.push({
            x: p.x + (slot - 1) * 46,
            y: p.y - 26,
            t: COPILOT_DURATION,
            fireT: 0.12 * slot,
            phase: Math.random() * 7,
            slot,
            shield: 1.5,
          });
          this.floaters.push({
            x: this.floatX(u.x), y: this.freeFloatY(u.x, u.y - 26),
            txt: `CO-PILOT ${this.copilots.length}/${MAX_COPILOTS}`,
            life: 1.5, col: "rgba(217,70,239,",
          });
        }
        this.burst(u.x, u.y, 26, "cosmic", 300);
        this.cb.sfx.life();
        this.vibrate([20, 25, 20]);
        break;
      }
      case "squadron": {
        this.squadronT = SQUADRON_DURATION;
        const hues = ["#67e8f9", "#a855f7", "#34d399", "#fbbf24"];
        this.squadron = [];
        for (let k = 0; k < SQUADRON_SIZE; k++) {
          // V-formation slots behind and beside the comet
          const side = k % 2 === 0 ? -1 : 1;
          const rank = Math.floor(k / 2) + 1;
          this.squadron.push({
            x: p.x, y: p.y,
            ox: side * rank * 46,
            oy: rank * 30,
            fireT: 0.1 * k,
            phase: Math.random() * 7,
            hue: hues[k % hues.length],
          });
        }
        this.burst(u.x, u.y, 38, "cyan", 420);
        this.shake = Math.max(this.shake, 9);
        this.cb.sfx.squadron();
        this.vibrate([30, 25, 30, 25, 40]);
        this.floaters.push({
          x: this.floatX(u.x), y: this.freeFloatY(u.x, u.y - 64),
          txt: "SQUADRON INBOUND", life: 1.8, col: "rgba(103,232,249,",
        });
        break;
      }
      case "magnet": {
        this.fxMagnet = MAGNET_DURATION;
        this.burst(u.x, u.y, 22, "gold", 240);
        this.cb.sfx.shieldUp();
        this.vibrate(20);
        this.floaters.push({ x: this.floatX(u.x), y: this.freeFloatY(u.x, u.y - 22), txt: "MAGNET", life: 1.2, col: "rgba(250,204,21," });
        break;
      }
    }
  }

  private addScore(n: number, x: number, y: number, label: string, col: [number, number, number], opts?: { credit?: number; isBoss?: boolean }) {
    this.score += n;
    // money ONLY comes from boss kills now
    if (opts?.isBoss && opts.credit) this.cb.onCredits(opts.credit, label);
    if (this.floaters.length < 14) {
      this.floaters.push({ x: this.floatX(x), y: this.freeFloatY(x, y), txt: label, life: 0.8, col: `rgba(${col[0]},${col[1]},${col[2]},` });
    }
  }



  /* ---------------- emitters ---------------- */

  /** keep floater text clear of the screen edges / HUD gutters */
  private floatX(x: number): number {
    const m = Math.min(96, this.W * 0.28);
    return Math.max(m, Math.min(this.W - m, x));
  }

  /** nudge a floater upward until it isn't sitting on another one */
  private freeFloatY(x: number, y: number): number {
    let yy = y;
    for (let guard = 0; guard < 8; guard++) {
      const clash = this.floaters.some((f) => Math.abs(f.x - x) < 120 && Math.abs(f.y - yy) < 24);
      if (!clash) break;
      yy -= 26;
    }
    return yy;
  }

  private emitScore(force = false) {
    const now = performance.now();
    if (force || now - this.lastScoreCb > 66) {
      this.lastScoreCb = now;
      this.cb.onScore(Math.floor(this.score));
    }
  }


  private emitDistance(force = false) {
    const now = performance.now();
    if (force || now - this.lastDistCb > 110) {
      this.lastDistCb = now;
      const boss = this.bossActive ? this.bossActive.def.name : STAGES[this.stageN - 1].name;
      this.cb.onDistance(this.distance, this.distanceTarget, boss);
    }
  }

  private emitPowers(force = false) {
    const now = performance.now();
    const key = `${this.fxSlow.toFixed(1)}|${this.fxDouble.toFixed(1)}|${this.player.shield > 0}|${this.player.lives}|${this.ultActive.toFixed(1)}`;
    if (force || (key !== this.lastPowersKey && now - this.lastPowersCb > 100)) {
      this.lastPowersKey = key;
      this.lastPowersCb = now;
      this.cb.onPowers({
        slow: Math.max(0, this.fxSlow),
        double: Math.max(0, this.fxDouble),
        shield: this.player.shield > 0,
        shieldT: Math.max(0, this.player.shield),
        lives: this.player.lives,
      });
    }
  }

  private emitGun(force = false) {
    if (force || this.lastGunCb !== this.gunCharges) {
      this.lastGunCb = this.gunCharges;
      this.cb.onGunReady(this.gunCharges);
    }
  }

  private emitUltCharge() { /* polled by the host via ultChargeFrac */ }

  private emitUlt(force = false) {
    if (force || this.lastUltCb !== this.ultReady) {
      this.lastUltCb = this.ultReady;
      this.cb.onUltReady(this.ultReady);
    }
  }

  /* ---------------- death / win ---------------- */

  private hitPlayer() {
    const p = this.player;
    if (p.lives > 0) {
      p.lives--;
      p.shield = 3;
      this.shake = Math.max(this.shake, 15);
      this.flash = Math.max(this.flash, 0.7);
      this.burst(p.x, p.y, 26, "rose", 340);
      this.vibrate([60, 30, 60]);
      this.cb.sfx.revive();
      this.floaters.push({ x: p.x, y: p.y - 34, txt: "LIFE SPENT", life: 1.1, col: "rgba(251,113,133," });
      this.emitPowers(true);
      return;
    }
    this.killPlayer();
  }

  private killPlayer() {
    const p = this.player;
    p.alive = false;
    this.mode = "dying";
    this.timeScale = 0.22;
    this.dieClock = 0;
    this.shake = 20;
    this.flash = 1;
    this.deathsThisRun++;
    this.burst(p.x, p.y, this.quality === 0 ? 24 : 44, "pink", 380);
    this.burst(p.x, p.y, 20, this.ball.trail === "rainbow" ? "cyan" : this.ball.trail, 300);
    this.cb.sfx.explosion();
    this.vibrate([70, 40, 110]);
  }

  private finalizeDeath() {
    const final = Math.floor(this.score);
    const isNewBest = final > this.best;
    if (isNewBest) {
      this.best = final;
      try { localStorage.setItem("nova-best", String(final)); } catch { /* private */ }
    }
    const grade = this.computeGrade();
    this.timeScale = 1;
    this.mode = "attract";
    this.player.alive = true;
    this.asteroids = [];
    this.pickups = [];
    this.bullets = [];
    this.bossActive = null;
    this.trail = [];
    const banked = final + this.stagesCleared * 50;
    this.cb.onGameOver({
      score: final,
      best: this.best,
      isNewBest,
      livesUsed: this.deathsThisRun,
      stagesCleared: this.stagesCleared,
      banked,
      totalCredits: 0,
      grade,
    });
  }

  /* ---------------- particles ---------------- */

  private burst(x: number, y: number, n: number, glow: string, power: number) {
    const budget = this.quality === 0 ? 70 : this.quality === 1 ? 110 : 150;
    for (let i = 0; i < n && this.particles.length < budget; i++) {
      const ang = Math.random() * Math.PI * 2;
      const v = power * (0.3 + Math.random() * 0.9);
      this.particles.push({
        x, y,
        vx: Math.cos(ang) * v,
        vy: Math.sin(ang) * v,
        life: 0.45 + Math.random() * 0.5,
        max: 0.8,
        size: 3 + Math.random() * 7,
        glow,
        streak: Math.random() < 0.4,
      });
    }
  }

  private explodeAsteroid(a: Asteroid) {
    const name =
      a.hue === PALETTE.cyan ? "cyan" : a.hue === PALETTE.pink ? "pink" : a.hue === PALETTE.red ? "red" : "violet";
    this.burst(a.x, a.y, 18, name, 260);
  }

  private trailGlowName(i: number): string {
    if (this.ball.trail === "rainbow") {
      return RAINBOW_CYCLE[(Math.floor(this.time * 3) + Math.floor(i / 2)) % RAINBOW_CYCLE.length];
    }
    return this.ball.trail;
  }

  /* ---------------- render ---------------- */

  private render() {
    const { ctx, W, H } = this;
    const sx = (Math.random() - 0.5) * this.shake;
    const sy = (Math.random() - 0.5) * this.shake;

    ctx.save();
    ctx.translate(sx, sy);

    if (this.bgSprite) {
      ctx.drawImage(this.bgSprite, -24, -24, W + 48, H + 48);
    } else {
      ctx.fillStyle = "#05060f";
      ctx.fillRect(-24, -24, W + 48, H + 48);
    }

    const bgCfg = this.currentBg();
    for (const s of this.stars) {
      const a = 0.35 + 0.5 * Math.abs(Math.sin(this.time * (0.6 + s.z) + s.tw));
      ctx.fillStyle = `rgba(${bgCfg.star},${a * s.z * bgCfg.starAlpha})`;
      ctx.fillRect(s.x, s.y, s.r, s.r * 3.2);
    }

    if (this.fxSlow > 0) {
      ctx.fillStyle = `rgba(56,189,248,${0.05 + 0.03 * Math.sin(this.time * 3)})`;
      ctx.fillRect(-24, -24, W + 48, H + 48);
    }

    ctx.globalCompositeOperation = "lighter";

    for (const q of this.particles) {
      if (q.x < -40 || q.x > this.W + 40 || q.y < -40 || q.y > this.H + 40) continue;
      const t = q.life / q.max;
      const g = this.glows.get(q.glow) ?? this.glows.get("white")!;
      if (q.streak) {
        ctx.strokeStyle = `rgba(255,255,255,${0.5 * t})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(q.x, q.y);
        ctx.lineTo(q.x - q.vx * 0.045, q.y - q.vy * 0.045);
        ctx.stroke();
      }
      this.drawGlow(g, q.x, q.y, q.size * (0.5 + t) * 3.2, t * 0.9);
    }

    ctx.globalCompositeOperation = "source-over";

    for (const u of this.pickups) this.drawPickup(u);
    for (const a of this.asteroids) this.drawAsteroid(a);
    for (const al of this.aliens) this.drawAlien(al);

    /* boss */
    if (this.bossActive) this.drawBoss(this.bossActive);

    /* bullets */
    for (const b of this.bullets) this.drawBullet(b);

    /* player */
    const p = this.player;
    if (p.alive) {
      const pal = this.ball;
      const isRainbow = this.ballId === "rainbow";
      const outerName = isRainbow ? RAINBOW_CYCLE[Math.floor(this.time * 3) % RAINBOW_CYCLE.length] : pal.outer;
      const innerName = isRainbow
        ? RAINBOW_CYCLE[(Math.floor(this.time * 3) + 3) % RAINBOW_CYCLE.length]
        : pal.inner;
      const flick = this.ballId === "fire" ? 0.84 + 0.16 * Math.sin(this.time * 22) : 1;
      const mat = MATERIALS[this.ballId as CometId] ?? MATERIALS.pulse;

      /* ---------- DUST TAIL — broad, curved, lags behind the path ---------- */
      ctx.globalCompositeOperation = "lighter";
      const tLen = this.trail.length;
      for (let i = tLen - 1; i >= 0; i--) {
        const t = 1 - i / tLen;              // 1 at head, 0 at tail end
        const tp = this.trail[i];
        const age = i / Math.max(1, tLen);
        // dust lags: offset sideways & downward the further back it is
        const lag = age * age * 16;
        const dustCol = isRainbow ? this.trailGlowName(i) : pal.trail;
        this.drawGlow(
          this.glows.get(dustCol)!,
          tp.x + lag * 0.35,
          tp.y + lag,
          14 + t * 30,
          t * 0.30,
        );
      }
      /* ---------- ION TAIL — narrow, straight, cool, points dead astern ---------- */
      for (let i = tLen - 1; i >= 0; i--) {
        const t = 1 - i / tLen;
        const tp = this.trail[i];
        this.drawGlow(this.ionSprite ?? undefined, tp.x, tp.y, (7 + t * 9) * 2, t * 0.42);
      }

      /* ---------- COMA — diffuse sublimation envelope ---------- */
      const comaR = p.r * (3.4 + Math.sin(this.time * 2.2) * 0.18) * flick;
      const coma = ctx.createRadialGradient(p.x, p.y, p.r * 0.5, p.x, p.y, comaR);
      coma.addColorStop(0, `rgba(${mat.coma},0.55)`);
      coma.addColorStop(0.42, `rgba(${mat.coma},0.2)`);
      coma.addColorStop(1, `rgba(${mat.coma},0)`);
      ctx.fillStyle = coma;
      ctx.beginPath();
      ctx.arc(p.x, p.y, comaR, 0, Math.PI * 2);
      ctx.fill();
      this.drawGlow(this.glows.get(outerName)!, p.x, p.y, p.r * 6.4, 0.42 * flick);

      /* ---------- VENTING JETS — collimated gas streams off the sunward face ---------- */
      for (let k = 0; k < mat.jets; k++) {
        const base = -Math.PI * 0.72 + (k / Math.max(1, mat.jets - 1)) * Math.PI * 0.62;
        const wob = Math.sin(this.time * 3.1 + k * 2.3) * 0.12;
        const ang = base + wob;
        const len = p.r * (2.2 + Math.sin(this.time * 4 + k) * 0.5);
        const jg = ctx.createLinearGradient(
          p.x + Math.cos(ang) * p.r * 0.6, p.y + Math.sin(ang) * p.r * 0.6,
          p.x + Math.cos(ang) * len,       p.y + Math.sin(ang) * len,
        );
        jg.addColorStop(0, `rgba(${mat.coma},0.55)`);
        jg.addColorStop(1, `rgba(${mat.coma},0)`);
        ctx.strokeStyle = jg;
        ctx.lineWidth = p.r * 0.3;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(p.x + Math.cos(ang) * p.r * 0.6, p.y + Math.sin(ang) * p.r * 0.6);
        ctx.lineTo(p.x + Math.cos(ang) * len, p.y + Math.sin(ang) * len);
        ctx.stroke();
      }
      ctx.lineCap = "butt";
      ctx.globalCompositeOperation = "source-over";

      /* ---------- NUCLEUS — detailed, slowly tumbling icy body ---------- */
      const blinking = p.shield > 0 && (this.mode === "play" || this.mode === "boss") && Math.sin(this.time * 16) > 0.65;
      if ((!blinking || p.shield < 2.6) && this.nucleusSprite) {
        this.nucleusSpin += 0.0;
        const nSize = p.r * 3.05;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(this.time * 0.22);     // slow natural tumble
        ctx.drawImage(this.nucleusSprite, -nSize / 2, -nSize / 2, nSize, nSize);
        ctx.restore();
        // hot inner glow bleeding through the crust
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get(innerName)!, p.x, p.y, p.r * 2.1, 0.5 * flick);
        ctx.globalCompositeOperation = "source-over";
      }

      /* ---------- character flourishes ---------- */
      if (this.ballId === "cosmic") {
        ctx.globalCompositeOperation = "lighter";
        for (let k = 0; k < 3; k++) {
          const ang = this.time * 2.2 + (k * Math.PI * 2) / 3;
          const mx = p.x + Math.cos(ang) * p.r * 2.4;
          const my = p.y + Math.sin(ang) * p.r * 2.4 * 0.5;
          this.drawGlow(this.glows.get("cosmic")!, mx, my, 10, 0.85);
          ctx.fillStyle = "#fae8ff";
          ctx.beginPath();
          ctx.arc(mx, my, 1.4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalCompositeOperation = "source-over";
      } else if (isRainbow) {
        ctx.globalCompositeOperation = "lighter";
        for (let k = 0; k < 5; k++) {
          const ang = this.time * 2.4 + (k * Math.PI * 2) / 5;
          const mx = p.x + Math.cos(ang) * p.r * 2.0;
          const my = p.y + Math.sin(ang) * p.r * 2.0;
          this.drawGlow(this.glows.get(RAINBOW_CYCLE[(k + Math.floor(this.time * 4)) % RAINBOW_CYCLE.length])!, mx, my, 11, 0.8);
        }
        ctx.globalCompositeOperation = "source-over";
      }

      if (p.shield > 0) {
        const pulse = 1 + Math.sin(this.time * 6) * 0.05;
        const low = p.shield < 2 ? (Math.sin(this.time * 14) > 0 ? 0.9 : 0.25) : 0.85;
        ctx.strokeStyle = `rgba(251,191,36,${low})`;
        ctx.lineWidth = 2;
        for (let k = 0; k < 2; k++) {
          const a0 = this.time * 2.4 * (k ? -1 : 1) + k * 2.4;
          ctx.beginPath();
          ctx.arc(p.x, p.y, (p.r + 13) * pulse, a0, a0 + Math.PI * 0.85);
          ctx.stroke();
        }
        this.drawGlow(this.glows.get("amber")!, p.x, p.y, p.r * 6, 0.3);
      }
    }

    /* summoned squadron — arrowhead fighters in formation */
    for (const w of this.squadron) {
      ctx.save();
      ctx.translate(w.x, w.y);
      // engine glow
      ctx.globalCompositeOperation = "lighter";
      const eg = ctx.createRadialGradient(0, 7, 0, 0, 7, 13);
      eg.addColorStop(0, w.hue);
      eg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = eg;
      ctx.beginPath();
      ctx.arc(0, 7, 13, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = "source-over";
      // hull
      ctx.fillStyle = "#e2e8f0";
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.lineTo(7, 6);
      ctx.lineTo(0, 2.5);
      ctx.lineTo(-7, 6);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = w.hue;
      ctx.lineWidth = 1.2;
      ctx.stroke();
      // cockpit
      ctx.fillStyle = w.hue;
      ctx.beginPath();
      ctx.ellipse(0, -3, 1.9, 3.4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    /* ultimate FX — shockwave rings and the gravity well */
    for (const r of this.ultRings) {
      const a = Math.max(0, Math.min(1, r.life / 0.7));
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = `rgba(${r.hue},${a * 0.8})`;
      ctx.lineWidth = 3 + a * 5;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = `rgba(255,255,255,${a * 0.5})`;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.r * 0.92, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalCompositeOperation = "source-over";
    }
    if (this.ultWell) {
      const w = this.ultWell;
      const spin = this.time * 3;
      ctx.save();
      ctx.translate(w.x, w.y);
      // accretion disc
      ctx.globalCompositeOperation = "lighter";
      for (let k = 0; k < 3; k++) {
        const rr = 46 + k * 26;
        ctx.strokeStyle = `rgba(168,85,247,${0.5 - k * 0.13})`;
        ctx.lineWidth = 5 - k;
        ctx.beginPath();
        ctx.ellipse(0, 0, rr, rr * 0.34, spin * (k % 2 ? -1 : 1) * 0.5, 0, Math.PI * 2);
        ctx.stroke();
      }
      this.drawGlow(this.glows.get("nebula"), 0, 0, 170, 0.6);
      ctx.globalCompositeOperation = "source-over";
      // the singularity itself
      const core = ctx.createRadialGradient(0, 0, 0, 0, 0, 34);
      core.addColorStop(0, "#000000");
      core.addColorStop(0.62, "#0b0618");
      core.addColorStop(1, "rgba(168,85,247,0)");
      ctx.fillStyle = core;
      ctx.beginPath();
      ctx.arc(0, 0, 34, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    /* AI co-pilot drones — quadrotor craft with spinning rotors and nav lights */
    for (const co of this.copilots) {
      const low = co.t < 3 && Math.sin(this.time * 12) > 0;   // blink when expiring
      const spin = this.time * 34 + co.slot;
      const bank = Math.max(-0.35, Math.min(0.35, (co.x - this.player.x) * -0.004));
      ctx.save();
      ctx.translate(co.x, co.y);
      ctx.rotate(bank);
      ctx.globalAlpha = low ? 0.5 : 1;

      // downwash glow beneath the airframe
      ctx.globalCompositeOperation = "lighter";
      this.drawGlow(this.glows.get("nebula"), 0, 7, 26, 0.35);
      ctx.globalCompositeOperation = "source-over";

      const ARM = 9.5;          // rotor-arm reach
      const arms: Array<[number, number]> = [[-ARM, -6], [ARM, -6], [-ARM, 6], [ARM, 6]];

      // 1. carbon arms
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 2.4;
      ctx.lineCap = "round";
      for (const [ax, ay] of arms) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(ax, ay);
        ctx.stroke();
      }

      // 2. rotor discs — motion-blurred blades
      for (let k = 0; k < arms.length; k++) {
        const [ax, ay] = arms[k];
        const dir = k % 2 === 0 ? 1 : -1;
        // blur disc
        ctx.globalAlpha = (low ? 0.5 : 1) * 0.22;
        ctx.fillStyle = "#93c5fd";
        ctx.beginPath();
        ctx.arc(ax, ay, 6.2, 0, Math.PI * 2);
        ctx.fill();
        // two blades caught mid-rotation
        ctx.globalAlpha = (low ? 0.5 : 1) * 0.75;
        ctx.strokeStyle = "#cbd5e1";
        ctx.lineWidth = 1.4;
        for (let b = 0; b < 2; b++) {
          const a0 = spin * dir + b * Math.PI;
          ctx.beginPath();
          ctx.moveTo(ax - Math.cos(a0) * 6, ay - Math.sin(a0) * 6);
          ctx.lineTo(ax + Math.cos(a0) * 6, ay + Math.sin(a0) * 6);
          ctx.stroke();
        }
        // motor hub
        ctx.globalAlpha = low ? 0.5 : 1;
        ctx.fillStyle = "#475569";
        ctx.beginPath();
        ctx.arc(ax, ay, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      // 3. fuselage — rounded chassis with a panel seam
      const body = ctx.createLinearGradient(0, -7, 0, 8);
      body.addColorStop(0, "#e2e8f0");
      body.addColorStop(0.55, "#94a3b8");
      body.addColorStop(1, "#334155");
      ctx.fillStyle = body;
      ctx.beginPath();
      ctx.moveTo(0, -8.5);
      ctx.quadraticCurveTo(5.5, -6, 5.2, 1);
      ctx.quadraticCurveTo(4.2, 7.5, 0, 8.5);
      ctx.quadraticCurveTo(-4.2, 7.5, -5.2, 1);
      ctx.quadraticCurveTo(-5.5, -6, 0, -8.5);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#1e293b";
      ctx.lineWidth = 0.9;
      ctx.stroke();
      ctx.strokeStyle = "rgba(15,23,42,0.5)";
      ctx.lineWidth = 0.7;
      ctx.beginPath();
      ctx.moveTo(-4.4, 0.5);
      ctx.lineTo(4.4, 0.5);
      ctx.stroke();

      // 4. sensor eye — glowing camera gimbal
      ctx.globalCompositeOperation = "lighter";
      const eye = ctx.createRadialGradient(0, -3, 0, 0, -3, 4.2);
      eye.addColorStop(0, "#ffffff");
      eye.addColorStop(0.4, "#d946ef");
      eye.addColorStop(1, "rgba(217,70,239,0)");
      ctx.fillStyle = eye;
      ctx.beginPath();
      ctx.arc(0, -3, 4.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "#0b1020";
      ctx.beginPath();
      ctx.arc(0, -3, 2.1, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#f0abfc";
      ctx.beginPath();
      ctx.arc(-0.6, -3.7, 0.8, 0, Math.PI * 2);
      ctx.fill();

      // 5. nav lights — port red / starboard green, blinking out of phase
      const nav = Math.sin(this.time * 6 + co.slot) > 0;
      ctx.fillStyle = nav ? "#f87171" : "rgba(120,30,30,0.6)";
      ctx.beginPath();
      ctx.arc(-ARM, 6, 1.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = nav ? "rgba(20,80,40,0.6)" : "#4ade80";
      ctx.beginPath();
      ctx.arc(ARM, 6, 1.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.globalAlpha = 1;
      ctx.lineCap = "butt";
      ctx.restore();
    }

    ctx.textAlign = "center";
    for (const f of this.floaters) {
      const t = Math.min(1, f.life / 0.35);
      ctx.font = "600 14px 'Space Grotesk', sans-serif";
      ctx.fillStyle = `${f.col}${t})`;
      ctx.fillText(f.txt, f.x, f.y);
    }

    ctx.restore();

    if (this.flash > 0.02) {
      ctx.fillStyle = `rgba(244,63,94,${this.flash * 0.28})`;
      ctx.fillRect(0, 0, W, H);
    }
  }

  private drawGlow(img: HTMLCanvasElement | undefined, x: number, y: number, size: number, alpha: number) {
    const sprite = img ?? this.glows.get("white");
    if (!sprite || !(size > 0)) return;
    const { ctx } = this;
    ctx.globalAlpha = Math.min(1, alpha);
    ctx.drawImage(sprite, x - size / 2, y - size / 2, size, size);
    ctx.globalAlpha = 1;
  }



  /** Bespoke art for boss + alien weapons, matched to their nature. */
  private drawHostileWeapon(a: Asteroid) {
    const { ctx } = this;
    const [cr, cg, cb] = a.hue;
    const col = `${cr},${cg},${cb}`;
    const ang = Math.atan2(a.vy, a.vx);
    ctx.save();
    ctx.translate(a.x, a.y);

    switch (a.weapon) {
      case "rock": { // MERCURY — molten pebble
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("amber"), 0, 0, a.r * 4.2, 0.5);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(a.rot);
        ctx.fillStyle = `rgb(${col})`;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const t = (i / 6) * Math.PI * 2;
          const rr = a.r * (i % 2 ? 0.75 : 1);
          i ? ctx.lineTo(Math.cos(t) * rr, Math.sin(t) * rr) : ctx.moveTo(Math.cos(t) * rr, Math.sin(t) * rr);
        }
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "rgba(255,240,200,0.8)";
        ctx.beginPath();
        ctx.arc(-a.r * 0.25, -a.r * 0.25, a.r * 0.3, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "pressureRing": { // VENUS — expanding pressure ring
        ctx.globalCompositeOperation = "lighter";
        const pulse = 1 + Math.sin(this.time * 9) * 0.12;
        ctx.strokeStyle = `rgba(${col},0.95)`;
        ctx.lineWidth = a.r * 0.5;
        ctx.beginPath();
        ctx.arc(0, 0, a.r * 1.25 * pulse, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = `rgba(255,255,255,0.6)`;
        ctx.lineWidth = a.r * 0.18;
        ctx.beginPath();
        ctx.arc(0, 0, a.r * 0.85 * pulse, 0, Math.PI * 2);
        ctx.stroke();
        break;
      }
      case "moonShard": { // EARTH — lunar rock shard
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("frost"), 0, 0, a.r * 3.6, 0.45);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(a.rot);
        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.moveTo(0, -a.r * 1.4);
        ctx.lineTo(a.r * 0.8, 0);
        ctx.lineTo(0, a.r * 1.4);
        ctx.lineTo(-a.r * 0.8, 0);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.85)";
        ctx.lineWidth = 1;
        ctx.stroke();
        break;
      }
      case "dustBall": { // MARS — tumbling dust boulder
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("rose"), 0, 0, a.r * 4, 0.42);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(a.rot);
        ctx.fillStyle = `rgb(${col})`;
        ctx.beginPath();
        ctx.arc(0, 0, a.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "rgba(90,40,25,0.75)";
        ctx.beginPath();
        ctx.arc(a.r * 0.25, a.r * 0.15, a.r * 0.35, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(-a.r * 0.3, -a.r * 0.2, a.r * 0.22, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "stormBolt": { // JUPITER — jagged lightning bolt
        ctx.rotate(ang);
        ctx.globalCompositeOperation = "lighter";
        ctx.strokeStyle = `rgba(${col},0.95)`;
        ctx.lineWidth = a.r * 0.5;
        ctx.lineJoin = "miter";
        ctx.beginPath();
        ctx.moveTo(-a.r * 1.8, 0);
        ctx.lineTo(-a.r * 0.4, -a.r * 0.7);
        ctx.lineTo(a.r * 0.2, a.r * 0.4);
        ctx.lineTo(a.r * 1.8, -a.r * 0.2);
        ctx.stroke();
        ctx.strokeStyle = "rgba(255,255,255,0.95)";
        ctx.lineWidth = a.r * 0.2;
        ctx.stroke();
        break;
      }
      case "iceChunk": { // SATURN / URANUS — angular ice block
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("ice"), 0, 0, a.r * 3.8, 0.5);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(a.rot);
        ctx.fillStyle = `rgba(${col},0.9)`;
        ctx.beginPath();
        ctx.moveTo(-a.r, -a.r * 0.5);
        ctx.lineTo(a.r * 0.3, -a.r);
        ctx.lineTo(a.r, a.r * 0.4);
        ctx.lineTo(-a.r * 0.4, a.r);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.9)";
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-a.r * 0.5, -a.r * 0.3);
        ctx.lineTo(a.r * 0.4, a.r * 0.2);
        ctx.stroke();
        break;
      }
      case "windLance": { // NEPTUNE — supersonic wind lance
        ctx.rotate(ang);
        ctx.globalCompositeOperation = "lighter";
        const g = ctx.createLinearGradient(-a.r * 4, 0, a.r * 1.6, 0);
        g.addColorStop(0, "rgba(0,0,0,0)");
        g.addColorStop(0.7, `rgba(${col},0.75)`);
        g.addColorStop(1, "rgba(255,255,255,0.95)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(a.r * 1.8, 0);
        ctx.lineTo(-a.r * 4, -a.r * 0.45);
        ctx.lineTo(-a.r * 4, a.r * 0.45);
        ctx.closePath();
        ctx.fill();
        break;
      }
      case "frostFlare": { // PLUTO — frozen flare burst
        ctx.globalCompositeOperation = "lighter";
        const fg = ctx.createRadialGradient(0, 0, 0, 0, 0, a.r * 2.6);
        fg.addColorStop(0, "rgba(255,255,255,1)");
        fg.addColorStop(0.4, `rgba(${col},0.8)`);
        fg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.arc(0, 0, a.r * 2.6, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = `rgba(${col},0.9)`;
        ctx.lineWidth = 1.4;
        for (let i = 0; i < 4; i++) {
          const t = this.time * 2 + (i / 4) * Math.PI * 2;
          ctx.beginPath();
          ctx.moveTo(Math.cos(t) * a.r * 0.5, Math.sin(t) * a.r * 0.5);
          ctx.lineTo(Math.cos(t) * a.r * 2, Math.sin(t) * a.r * 2);
          ctx.stroke();
        }
        break;
      }
      case "solarLance": { // SUN — searing plasma lance
        ctx.rotate(ang);
        ctx.globalCompositeOperation = "lighter";
        const sg = ctx.createLinearGradient(-a.r * 5, 0, a.r * 2, 0);
        sg.addColorStop(0, "rgba(0,0,0,0)");
        sg.addColorStop(0.5, `rgba(${col},0.85)`);
        sg.addColorStop(1, "rgba(255,255,220,1)");
        ctx.fillStyle = sg;
        ctx.beginPath();
        ctx.ellipse(-a.r * 1.4, 0, a.r * 3.4, a.r * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
        const hg = ctx.createRadialGradient(a.r, 0, 0, a.r, 0, a.r * 2);
        hg.addColorStop(0, "rgba(255,255,255,1)");
        hg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = hg;
        ctx.beginPath();
        ctx.arc(a.r, 0, a.r * 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "alienPlasma": { // alien — green plasma blob
        ctx.globalCompositeOperation = "lighter";
        const pg = ctx.createRadialGradient(0, 0, 0, 0, 0, a.r * 2.4);
        pg.addColorStop(0, "rgba(255,255,255,0.95)");
        pg.addColorStop(0.35, `rgba(${col},0.9)`);
        pg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = pg;
        ctx.beginPath();
        ctx.arc(0, 0, a.r * 2.4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "alienLaser": { // alien — thin precise beam
        ctx.rotate(ang);
        ctx.globalCompositeOperation = "lighter";
        ctx.strokeStyle = `rgba(${col},0.95)`;
        ctx.lineWidth = a.r * 0.45;
        ctx.beginPath();
        ctx.moveTo(-a.r * 3.4, 0);
        ctx.lineTo(a.r * 1.6, 0);
        ctx.stroke();
        ctx.strokeStyle = "rgba(255,255,255,0.95)";
        ctx.lineWidth = a.r * 0.16;
        ctx.stroke();
        break;
      }
      case "alienMine": { // alien — spiked drifting mine
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("lime"), 0, 0, a.r * 3.4, 0.5);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(this.time * 1.6);
        ctx.strokeStyle = `rgba(${col},0.95)`;
        ctx.lineWidth = 1.6;
        for (let i = 0; i < 8; i++) {
          const t = (i / 8) * Math.PI * 2;
          ctx.beginPath();
          ctx.moveTo(Math.cos(t) * a.r * 0.6, Math.sin(t) * a.r * 0.6);
          ctx.lineTo(Math.cos(t) * a.r * 1.5, Math.sin(t) * a.r * 1.5);
          ctx.stroke();
        }
        ctx.fillStyle = "#1e293b";
        ctx.beginPath();
        ctx.arc(0, 0, a.r * 0.7, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = Math.sin(this.time * 9) > 0 ? `rgb(${col})` : "rgba(40,60,50,0.9)";
        ctx.beginPath();
        ctx.arc(0, 0, a.r * 0.3, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
    }
    ctx.restore();
  }

  private drawAsteroid(a: Asteroid) {
    // hostile weapons have bespoke art
    if (a.weapon) { this.drawHostileWeapon(a); return; }

    const { ctx } = this;
    const [r, g, b] = a.hue;
    const glowName =
      a.hue === PALETTE.cyan ? "cyan" : a.hue === PALETTE.pink ? "pink" : a.hue === PALETTE.red ? "red" : "violet";

    ctx.globalCompositeOperation = "lighter";
    this.drawGlow(this.glows.get(glowName)!, a.x, a.y, a.r * 4.6, a.isBossProjectile ? 0.6 : 0.34);
    ctx.globalCompositeOperation = "source-over";

    ctx.save();
    ctx.translate(a.x, a.y);
    ctx.rotate(a.rot);

    ctx.beginPath();
    const n = a.verts.length;
    for (let i = 0; i <= n; i++) {
      const idx = i % n;
      const ang = (idx / n) * Math.PI * 2;
      const rr = a.r * a.verts[idx];
      const px = Math.cos(ang) * rr;
      const py = Math.sin(ang) * rr;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fillStyle = "rgba(8,10,26,0.92)";
    ctx.fill();
    ctx.strokeStyle = a.isBossProjectile
      ? "rgba(251,191,36,0.95)"
      : `rgba(${r},${g},${b},0.95)`;
    ctx.lineWidth = a.isBossProjectile ? 2 : 1.6;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-a.r * 0.35, -a.r * 0.1);
    ctx.lineTo(0, -a.r * 0.42);
    ctx.lineTo(a.r * 0.3, -a.r * 0.05);
    ctx.strokeStyle = `rgba(${r},${g},${b},0.4)`;
    ctx.lineWidth = 1;
    ctx.stroke();

    // status overlays so the player can read what their weapon is doing
    if (a.frozenT && a.frozenT > 0) {
      // encased in a solid block of ice
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = "rgba(186,230,253,0.42)";
      ctx.beginPath();
      ctx.arc(0, 0, a.r * 1.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = "rgba(240,252,255,0.95)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      // angular ice shell
      for (let k = 0; k <= 7; k++) {
        const t2 = (k / 7) * Math.PI * 2;
        const rr = a.r * (1.18 + (k % 2) * 0.22);
        const px = Math.cos(t2) * rr, py = Math.sin(t2) * rr;
        k ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
      // internal fracture lines
      ctx.strokeStyle = "rgba(255,255,255,0.75)";
      ctx.lineWidth = 0.9;
      for (let k = 0; k < 3; k++) {
        const t2 = (k / 3) * Math.PI * 2 + 0.5;
        ctx.beginPath();
        ctx.moveTo(Math.cos(t2) * a.r * 1.1, Math.sin(t2) * a.r * 1.1);
        ctx.lineTo(Math.cos(t2 + 2.1) * a.r * 0.5, Math.sin(t2 + 2.1) * a.r * 0.5);
        ctx.stroke();
      }
    } else if (a.slowT && a.slowT > 0) {
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = "rgba(186,230,253,0.3)";
      ctx.beginPath();
      ctx.arc(0, 0, a.r * 1.05, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(224,242,254,0.85)";
      ctx.lineWidth = 1.2;
      for (let k = 0; k < 3; k++) {
        const t2 = (k / 3) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(t2) * a.r * 0.45, Math.sin(t2) * a.r * 0.45);
        ctx.lineTo(Math.cos(t2) * a.r * 1.05, Math.sin(t2) * a.r * 1.05);
        ctx.stroke();
      }
      ctx.globalCompositeOperation = "source-over";
    }
    if (a.burnT && a.burnT > 0) {
      ctx.globalCompositeOperation = "lighter";
      const fl = 0.45 + Math.random() * 0.3;
      const bg = ctx.createRadialGradient(0, 0, 0, 0, 0, a.r * 1.6);
      bg.addColorStop(0, `rgba(253,224,71,${fl})`);
      bg.addColorStop(0.5, `rgba(251,146,60,${fl * 0.7})`);
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.beginPath();
      ctx.arc(0, 0, a.r * 1.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = "source-over";
    }

    ctx.restore();
  }

  private drawBoss(b: Boss) {
    const { ctx } = this;
    if (!this.bossCanvas) return;
    const sx = (Math.random() - 0.5) * (b.shakeT * 8);
    const sy = (Math.random() - 0.5) * (b.shakeT * 8);
    const size = b.r * 2.05;  // b.r already carries the planet's relative scale
    ctx.save();
    ctx.translate(b.x + sx, b.y + sy);
    // pulsing aura
    const pulse = 1 + Math.sin(b.t * 4) * 0.04;
    ctx.scale(pulse, pulse);
    ctx.globalCompositeOperation = "lighter";
    const atmosGlow = NovaEngine.ATMOS[b.stageN] ?? 0.4;
    if (atmosGlow > 0.02) this.drawGlow(this.bossCanvas, 0, 0, size * 1.28, 0.26 * atmosGlow);
    ctx.globalCompositeOperation = "source-over";
    ctx.drawImage(this.bossCanvas, -size / 2, -size / 2, size, size);
    if (!b.entered) {
      // arrival shield — telegraphs that the boss can't be hurt yet
      ctx.globalCompositeOperation = "lighter";
      const sp = 0.35 + Math.sin(this.time * 9) * 0.15;
      ctx.strokeStyle = `rgba(148,197,255,${sp})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, b.r * 0.92, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalCompositeOperation = "source-over";
    }
    if (this.bossFlash > 0) {
      ctx.globalCompositeOperation = "lighter";
      ctx.fillStyle = `rgba(255,255,255,${this.bossFlash * 0.6})`;
      ctx.beginPath();
      ctx.arc(0, 0, b.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = "source-over";
    }
    ctx.restore();
  }

  private drawBullet(b: Bullet) {
    const { ctx } = this;
    const ang = Math.atan2(b.vy, b.vx);
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(ang);
    ctx.globalCompositeOperation = "lighter";

    // --- ALLY ROUNDS: unmistakably different from your own fire ---
    // A compact magenta dart with a hard white core and a short twin tracer,
    // so you always know which shots are yours.
    if (b.owner === 2) {
      const L = b.r * 2.6;
      // twin tracer rails
      ctx.strokeStyle = "rgba(255,255,255,0.4)";
      ctx.lineWidth = 0.9;
      for (const off of [-b.r * 0.5, b.r * 0.5]) {
        ctx.beginPath();
        ctx.moveTo(-L * 1.8, off);
        ctx.lineTo(-L * 0.3, off);
        ctx.stroke();
      }
      // halo — tinted by the firing craft so squadron fighters stay distinct
      const ally = b.color || "#d946ef";
      const hg = ctx.createRadialGradient(0, 0, 0, 0, 0, b.r * 2.4);
      hg.addColorStop(0, "rgba(255,255,255,0.9)");
      hg.addColorStop(0.35, ally);
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(0, 0, b.r * 2.4, 0, Math.PI * 2);
      ctx.fill();
      // dart body
      ctx.fillStyle = ally;
      ctx.beginPath();
      ctx.moveTo(L, 0);
      ctx.lineTo(-L * 0.4, -b.r * 0.62);
      ctx.lineTo(-L * 0.15, 0);
      ctx.lineTo(-L * 0.4, b.r * 0.62);
      ctx.closePath();
      ctx.fill();
      // white-hot core
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.ellipse(L * 0.3, 0, b.r * 0.55, b.r * 0.3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    switch (b.arche) {
      /* ========== PLASMA BOLT (Pulse) — superheated ionised core ========== */
      case "machinegun": {
        const L = b.r * 8;
        // ionised wake
        const st = ctx.createLinearGradient(-L, 0, b.r * 1.6, 0);
        st.addColorStop(0, "rgba(0,0,0,0)");
        st.addColorStop(0.55, `rgba(${this.rgbOf(b.color)},0.4)`);
        st.addColorStop(1, `rgba(${this.rgbOf(b.color)},0.95)`);
        ctx.fillStyle = st;
        ctx.beginPath();
        ctx.moveTo(-L, -b.r * 0.2);
        ctx.lineTo(b.r * 1.6, -b.r * 0.55);
        ctx.lineTo(b.r * 1.6, b.r * 0.55);
        ctx.lineTo(-L, b.r * 0.2);
        ctx.closePath();
        ctx.fill();
        // containment ripples along the bolt
        ctx.strokeStyle = `rgba(${this.rgbOf(b.color)},0.5)`;
        ctx.lineWidth = 1;
        for (let k = 1; k <= 3; k++) {
          const px = -k * b.r * 1.7;
          const amp = b.r * (0.5 - k * 0.1) * (1 + Math.sin(b.wob * 22 + k) * 0.3);
          ctx.beginPath();
          ctx.ellipse(px, 0, b.r * 0.3, amp, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
        // white-hot plasma head
        const tip = ctx.createRadialGradient(b.r * 0.8, 0, 0, b.r * 0.8, 0, b.r * 2.8);
        tip.addColorStop(0, "rgba(255,255,255,1)");
        tip.addColorStop(0.3, b.core);
        tip.addColorStop(0.6, `rgba(${this.rgbOf(b.color)},0.6)`);
        tip.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = tip;
        ctx.beginPath();
        ctx.arc(b.r * 0.8, 0, b.r * 2.8, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      /* ========== ICE SHARD (Glacier) — faceted crystal with frost trail ========== */
      case "iceslash": {
        const L = b.r * 3.8;
        const W = b.r * 1.0;
        // cold aura
        const au = ctx.createRadialGradient(0, 0, 0, 0, 0, L * 1.2);
        au.addColorStop(0, `rgba(${this.rgbOf(b.color)},0.45)`);
        au.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = au;
        ctx.beginPath();
        ctx.arc(0, 0, L * 1.2, 0, Math.PI * 2);
        ctx.fill();
        // crystal body — sharp, asymmetric, faceted
        ctx.fillStyle = b.core;
        ctx.beginPath();
        ctx.moveTo(L, 0);
        ctx.lineTo(L * 0.2, -W);
        ctx.lineTo(-L * 0.6, -W * 0.45);
        ctx.lineTo(-L * 0.45, 0);
        ctx.lineTo(-L * 0.6, W * 0.45);
        ctx.lineTo(L * 0.2, W);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = `rgba(${this.rgbOf(b.color)},0.95)`;
        ctx.lineWidth = 1.1;
        ctx.stroke();
        // internal refraction facets
        ctx.strokeStyle = "rgba(255,255,255,0.9)";
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(L * 0.9, 0); ctx.lineTo(-L * 0.4, 0);
        ctx.moveTo(L * 0.2, -W * 0.8); ctx.lineTo(L * 0.1, W * 0.8);
        ctx.stroke();
        // shed frost crystals
        ctx.fillStyle = "rgba(226,250,255,0.85)";
        for (let k = 1; k <= 4; k++) {
          const px = -L * 0.5 - k * b.r * 1.1;
          const py = Math.sin(b.wob * 10 + k * 1.7) * b.r * 0.85;
          const sz = 2.2 - k * 0.35;
          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(b.wob * 6 + k);
          ctx.fillRect(-sz / 2, -sz / 2, sz, sz);
          ctx.restore();
        }
        break;
      }

      /* ========== FLAME BURST (Inferno) — churning fireball + smoke ========== */
      case "wavegun": {
        const grow = 1 + b.age * 1.6;
        const R = b.r * 1.5 * grow;
        // outer flame envelope
        const fl = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 2.1);
        fl.addColorStop(0, "rgba(255,255,255,0.95)");
        fl.addColorStop(0.22, "#fde047");
        fl.addColorStop(0.5, `rgba(${this.rgbOf(b.color)},0.85)`);
        fl.addColorStop(0.78, "rgba(190,40,10,0.42)");
        fl.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = fl;
        ctx.beginPath();
        ctx.arc(0, 0, R * 2.1, 0, Math.PI * 2);
        ctx.fill();
        // licking flame tongues, animated
        ctx.fillStyle = "rgba(255,190,70,0.6)";
        for (let k = 0; k < 5; k++) {
          const a0 = (k / 5) * Math.PI * 2 + b.wob * 9;
          const len = R * (1.0 + Math.sin(b.wob * 16 + k * 2) * 0.45);
          ctx.beginPath();
          ctx.moveTo(Math.cos(a0) * R * 0.45, Math.sin(a0) * R * 0.45);
          ctx.lineTo(Math.cos(a0 + 0.3) * len, Math.sin(a0 + 0.3) * len);
          ctx.lineTo(Math.cos(a0 - 0.3) * len, Math.sin(a0 - 0.3) * len);
          ctx.closePath();
          ctx.fill();
        }
        // trailing smoke puffs
        ctx.globalCompositeOperation = "source-over";
        for (let k = 1; k <= 3; k++) {
          ctx.fillStyle = `rgba(60,40,36,${0.2 / k})`;
          ctx.beginPath();
          ctx.arc(-R * 1.3 * k, Math.sin(b.wob * 7 + k) * b.r * 0.6, R * 0.55 * k * 0.7, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalCompositeOperation = "lighter";
        break;
      }

      /* ========== LIGHTNING LANCE (Nebula) — forked electric bolt ========== */
      case "seeking": {
        const L = b.r * 3.2;
        // electric corona
        const co = ctx.createRadialGradient(0, 0, 0, 0, 0, L * 1.5);
        co.addColorStop(0, `rgba(${this.rgbOf(b.color)},0.6)`);
        co.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = co;
        ctx.beginPath();
        ctx.arc(0, 0, L * 1.5, 0, Math.PI * 2);
        ctx.fill();
        // jagged bolt body — re-forks every frame for a live crackle
        const seed = Math.floor(b.wob * 30);
        const rnd = (i: number) => ((Math.sin(seed * 12.9898 + i * 78.233) * 43758.5453) % 1 + 1) % 1;
        const drawFork = (scale: number, alpha: number, width: number) => {
          ctx.strokeStyle = `rgba(${this.rgbOf(b.color)},${alpha})`;
          ctx.lineWidth = width;
          ctx.lineJoin = "miter";
          ctx.beginPath();
          ctx.moveTo(-L * 1.4 * scale, 0);
          for (let k = 1; k <= 4; k++) {
            const px = -L * 1.4 * scale + (L * 2.4 * scale * k) / 4;
            const py = (rnd(k) - 0.5) * b.r * 1.5 * scale;
            ctx.lineTo(px, py);
          }
          ctx.stroke();
        };
        drawFork(1, 0.85, b.r * 0.5);
        drawFork(0.6, 0.5, b.r * 0.28);
        // white-hot core streak
        ctx.strokeStyle = "rgba(255,255,255,0.95)";
        ctx.lineWidth = b.r * 0.18;
        drawFork(1, 0.95, b.r * 0.18);
        // arc head
        const hd = ctx.createRadialGradient(L * 0.9, 0, 0, L * 0.9, 0, b.r * 1.8);
        hd.addColorStop(0, "#ffffff");
        hd.addColorStop(0.4, b.core);
        hd.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = hd;
        ctx.beginPath();
        ctx.arc(L * 0.9, 0, b.r * 1.8, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      /* ====== PRISM LANCE (Prism) — white light refracting into spectrum ====== */
      case "prismLance": {
        const L = b.r * 5.5;
        const spectrum = ["#ff3b6b", "#ff9a3c", "#ffe14d", "#49e07f", "#3ad7f0", "#5b7cff", "#b45bff"];

        // 1. the dispersed rainbow fan trailing behind — white light splitting
        for (let k = 0; k < spectrum.length; k++) {
          const f = k / (spectrum.length - 1);          // 0..1 across the band
          const off = (f - 0.5) * b.r * 2.4;            // vertical separation
          const g = ctx.createLinearGradient(-L * 2.1, off, L * 0.2, off * 0.2);
          g.addColorStop(0, "rgba(0,0,0,0)");
          g.addColorStop(0.55, `${spectrum[k]}66`);
          g.addColorStop(1, `${spectrum[k]}dd`);
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.moveTo(-L * 2.1, off);
          ctx.lineTo(L * 0.25, off * 0.18 - b.r * 0.2);
          ctx.lineTo(L * 0.25, off * 0.18 + b.r * 0.2);
          ctx.closePath();
          ctx.fill();
        }

        // 2. the lance itself — a hard white shaft
        const shaft = ctx.createLinearGradient(-L * 0.9, 0, L, 0);
        shaft.addColorStop(0, "rgba(255,255,255,0)");
        shaft.addColorStop(0.45, "rgba(255,255,255,0.85)");
        shaft.addColorStop(1, "rgba(255,255,255,1)");
        ctx.fillStyle = shaft;
        ctx.beginPath();
        ctx.moveTo(L, 0);
        ctx.lineTo(L * 0.1, -b.r * 0.46);
        ctx.lineTo(-L * 0.9, -b.r * 0.14);
        ctx.lineTo(-L * 0.9, b.r * 0.14);
        ctx.lineTo(L * 0.1, b.r * 0.46);
        ctx.closePath();
        ctx.fill();

        // 3. the refracting prism head — a crystalline wedge
        ctx.fillStyle = "rgba(255,255,255,0.95)";
        ctx.beginPath();
        ctx.moveTo(L * 1.15, 0);
        ctx.lineTo(L * 0.45, -b.r * 0.78);
        ctx.lineTo(L * 0.45, b.r * 0.78);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(190,230,255,0.9)";
        ctx.lineWidth = 0.9;
        ctx.stroke();

        // 4. lens flare at the tip
        const fl = ctx.createRadialGradient(L * 0.95, 0, 0, L * 0.95, 0, b.r * 3);
        fl.addColorStop(0, "rgba(255,255,255,1)");
        fl.addColorStop(0.3, "rgba(226,240,255,0.7)");
        fl.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = fl;
        ctx.beginPath();
        ctx.arc(L * 0.95, 0, b.r * 3, 0, Math.PI * 2);
        ctx.fill();

        // 5. horizontal anamorphic streak — the cinematic signature
        ctx.strokeStyle = "rgba(255,255,255,0.55)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-L * 1.2, 0);
        ctx.lineTo(L * 1.5, 0);
        ctx.stroke();
        break;
      }

      /* ---------- LASER / default — focused energy bolt ---------- */
      default: {
        const L = b.r * 4;
        const g = ctx.createLinearGradient(-L, 0, L, 0);
        g.addColorStop(0, "rgba(0,0,0,0)");
        g.addColorStop(0.5, `rgba(${this.rgbOf(b.color)},0.9)`);
        g.addColorStop(1, "rgba(255,255,255,0.95)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(0, 0, L, b.r * 0.42, 0, 0, Math.PI * 2);
        ctx.fill();
        const cg = ctx.createRadialGradient(0, 0, 0, 0, 0, b.r * 2.4);
        cg.addColorStop(0, "rgba(255,255,255,0.95)");
        cg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = cg;
        ctx.beginPath();
        ctx.arc(0, 0, b.r * 2.4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
    }

    ctx.restore();
  }

  private drawPickup(u: Pickup) {
    const { ctx } = this;
    const pulse = 1 + Math.sin(this.time * 5 + u.spin * 3) * 0.12;

    ctx.save();
    ctx.translate(u.x, u.y);

    switch (u.kind) {
      case "shard": {
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("cyan")!, 0, 0, u.r * 5.4 * pulse, 0.7);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(u.spin);
        const s = u.r * pulse;
        ctx.beginPath();
        ctx.moveTo(0, -s);
        ctx.lineTo(s * 0.62, 0);
        ctx.lineTo(0, s);
        ctx.lineTo(-s * 0.62, 0);
        ctx.closePath();
        ctx.fillStyle = "rgba(224,254,255,0.95)";
        ctx.fill();
        ctx.strokeStyle = "rgba(103,232,249,0.9)";
        ctx.lineWidth = 1.4;
        ctx.stroke();
        break;
      }
      case "shield": {
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("amber"), 0, 0, u.r * 6 * pulse, 0.8);
        ctx.globalCompositeOperation = "source-over";
        // heraldic shield crest
        const sw = u.r * 0.95 * pulse;
        const sh = u.r * 1.15 * pulse;
        ctx.beginPath();
        ctx.moveTo(0, -sh);
        ctx.lineTo(sw, -sh * 0.55);
        ctx.lineTo(sw, sh * 0.15);
        ctx.quadraticCurveTo(sw * 0.6, sh * 0.85, 0, sh);
        ctx.quadraticCurveTo(-sw * 0.6, sh * 0.85, -sw, sh * 0.15);
        ctx.lineTo(-sw, -sh * 0.55);
        ctx.closePath();
        ctx.fillStyle = "rgba(254,243,199,0.92)";
        ctx.fill();
        ctx.strokeStyle = "rgba(180,83,9,0.95)";
        ctx.lineWidth = 1.6;
        ctx.stroke();
        // centre bar
        ctx.fillStyle = "rgba(180,83,9,0.8)";
        ctx.fillRect(-sw * 0.16, -sh * 0.45, sw * 0.32, sh * 1.0);
        break;
      }
      case "slowmo": {
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("sky")!, 0, 0, u.r * 6 * pulse, 0.8);
        ctx.globalCompositeOperation = "source-over";
        ctx.strokeStyle = "rgba(125,211,252,0.95)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, u.r * pulse, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = "rgba(240,249,255,0.95)";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(this.time * 1.4 - 1.57) * u.r * 0.62, Math.sin(this.time * 1.4 - 1.57) * u.r * 0.62);
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(this.time * 8 - 1.57) * u.r * 0.45, Math.sin(this.time * 8 - 1.57) * u.r * 0.45);
        ctx.stroke();
        ctx.fillStyle = "#f0f9ff";
        ctx.beginPath();
        ctx.arc(0, 0, 2.4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "double": {
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("pink")!, 0, 0, u.r * 6 * pulse, 0.8);
        ctx.globalCompositeOperation = "source-over";
        ctx.strokeStyle = "rgba(244,114,182,0.9)";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.arc(0, 0, (u.r + 3) * pulse, this.time * 3, this.time * 3 + Math.PI * 1.3);
        ctx.stroke();
        ctx.font = `800 ${Math.round(u.r * 0.95)}px 'Unbounded', sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = "#fdf2f8";
        ctx.fillText("×2", 0, 1);
        ctx.textBaseline = "alphabetic";
        break;
      }
      case "life": {
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("rose")!, 0, 0, u.r * 6.6 * pulse, 0.85);
        ctx.globalCompositeOperation = "source-over";
        const s = u.r * 0.92 * pulse;
        ctx.beginPath();
        ctx.moveTo(0, s * 0.78);
        ctx.bezierCurveTo(-s * 1.55, -s * 0.32, -s * 0.55, -s * 1.15, 0, -s * 0.38);
        ctx.bezierCurveTo(s * 0.55, -s * 1.15, s * 1.55, -s * 0.32, 0, s * 0.78);
        ctx.closePath();
        ctx.fillStyle = "rgba(251,113,133,0.95)";
        ctx.fill();
        ctx.strokeStyle = "rgba(255,228,230,0.9)";
        ctx.lineWidth = 1.4;
        ctx.stroke();
        break;
      }
      case "gun": {
        // weapon orb — arms the comet's gun (no upgrade tiers)
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("violet"), 0, 0, u.r * 6 * pulse, 0.9);
        ctx.globalCompositeOperation = "source-over";
        ctx.rotate(this.time * 1.6);
        ctx.strokeStyle = "rgba(168,85,247,0.95)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, (u.r + 3) * pulse, 0, Math.PI * 2);
        ctx.stroke();
        // inner triangle (bullet symbol)
        ctx.fillStyle = this.ability.gun.color;
        ctx.beginPath();
        ctx.moveTo(0, -u.r * 0.55 * pulse);
        ctx.lineTo(u.r * 0.42 * pulse, u.r * 0.32 * pulse);
        ctx.lineTo(-u.r * 0.42 * pulse, u.r * 0.32 * pulse);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.7)";
        ctx.lineWidth = 1.2;
        ctx.stroke();
        break;
      }
      case "copilot": {
        // drone dispatch beacon — a quadrotor silhouette in a hex frame
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("cosmic"), 0, 0, u.r * 6.2 * pulse, 0.9);
        ctx.globalCompositeOperation = "source-over";
        ctx.save();
        ctx.rotate(this.time * 0.9);
        ctx.strokeStyle = "rgba(217,70,239,0.95)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i2 = 0; i2 < 6; i2++) {
          const t2 = (i2 / 6) * Math.PI * 2;
          const px = Math.cos(t2) * (u.r * 0.96) * pulse;
          const py = Math.sin(t2) * (u.r * 0.96) * pulse;
          i2 ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();
        ctx.restore();
        // quadrotor glyph
        const q = u.r * 0.58 * pulse;
        ctx.strokeStyle = "#e2e8f0";
        ctx.lineWidth = 1.5;
        ctx.lineCap = "round";
        for (const [sx, sy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as Array<[number, number]>) {
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(sx * q, sy * q * 0.8);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(sx * q, sy * q * 0.8, q * 0.46, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.lineCap = "butt";
        ctx.fillStyle = "#fae8ff";
        ctx.beginPath();
        ctx.arc(0, 0, q * 0.4, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "squadron": {
        // four chevrons orbiting a core — a whole wing in one orb
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("cyan"), 0, 0, u.r * 7 * pulse, 0.95);
        ctx.globalCompositeOperation = "source-over";
        ctx.strokeStyle = "rgba(103,232,249,0.95)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, (u.r + 3) * pulse, 0, Math.PI * 2);
        ctx.stroke();
        const hues4 = ["#67e8f9", "#a855f7", "#34d399", "#fbbf24"];
        for (let k = 0; k < 4; k++) {
          const ang = this.time * 1.8 + (k / 4) * Math.PI * 2;
          const rr = u.r * 0.62 * pulse;
          const px = Math.cos(ang) * rr;
          const py = Math.sin(ang) * rr;
          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(ang + Math.PI / 2);
          ctx.fillStyle = hues4[k];
          ctx.beginPath();
          ctx.moveTo(0, -4.2);
          ctx.lineTo(3, 3);
          ctx.lineTo(0, 1.2);
          ctx.lineTo(-3, 3);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        }
        ctx.fillStyle = "#f0f9ff";
        ctx.beginPath();
        ctx.arc(0, 0, u.r * 0.2 * pulse, 0, Math.PI * 2);
        ctx.fill();
        break;
      }
      case "magnet": {
        // gold coin stamped with a downward horseshoe magnet
        ctx.globalCompositeOperation = "lighter";
        this.drawGlow(this.glows.get("amber"), 0, 0, u.r * 6.4 * pulse, 0.9);
        ctx.globalCompositeOperation = "source-over";
        const cr = u.r * pulse;
        const cg = ctx.createLinearGradient(-cr, -cr, cr, cr);
        cg.addColorStop(0, "#fff7d6");
        cg.addColorStop(0.5, "#fcd34d");
        cg.addColorStop(1, "#b45309");
        ctx.fillStyle = cg;
        ctx.beginPath();
        ctx.arc(0, 0, cr, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#7c2d12";
        ctx.lineWidth = 1.4;
        ctx.stroke();
        ctx.strokeStyle = "rgba(124,45,18,0.4)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(0, 0, cr * 0.74, 0, Math.PI * 2);
        ctx.stroke();
        // glyph flipped so the arc can never read as a smile
        ctx.rotate(Math.PI);
        ctx.strokeStyle = "#7f1d1d";
        ctx.lineWidth = cr * 0.26;
        ctx.beginPath();
        ctx.arc(0, cr * 0.08, cr * 0.4, Math.PI, 0);
        ctx.stroke();
        ctx.fillStyle = "#7f1d1d";
        ctx.fillRect(-cr * 0.53, cr * 0.08, cr * 0.26, cr * 0.36);
        ctx.fillRect(cr * 0.27, cr * 0.08, cr * 0.26, cr * 0.36);
        break;
      }
    }
    ctx.restore();
  }
}
