/* Nova Rush — persistent bank + persistent per-stage grade + checkpoint system */

import { STAGES } from "./stages";

/* ---------------- credits ---------------- */

export function readCredits(): number {
  return Number(localStorage.getItem("nova-credits") ?? 0) || 0;
}

export function addCredits(n: number): number {
  const next = readCredits() + Math.max(0, Math.floor(n));
  try { localStorage.setItem("nova-credits", String(next)); } catch { /* private */ }
  return next;
}

export function spendCredits(n: number): { ok: boolean; remaining: number } {
  const cur = readCredits();
  if (cur < n) return { ok: false, remaining: cur };
  const next = cur - n;
  try { localStorage.setItem("nova-credits", String(next)); } catch { /* private */ }
  return { ok: true, remaining: next };
}

/* ---------------- per-stage grade persistence ---------------- */

export function readStageStars(stageN: number): number {
  try {
    const raw = JSON.parse(localStorage.getItem("nova-stars") ?? "{}");
    return Math.max(0, Math.min(3, Number(raw?.[stageN] ?? 0) | 0));
  } catch {
    return 0;
  }
}

export function writeStageStar(stageN: number, stars: number): number {
  const prev = readStageStars(stageN);
  if (stars <= prev) return prev;
  const obj: Record<number, number> = {};
  try { Object.assign(obj, JSON.parse(localStorage.getItem("nova-stars") ?? "{}")); } catch { /* corrupt */ }
  obj[stageN] = stars;
  try { localStorage.setItem("nova-stars", JSON.stringify(obj)); } catch { /* private */ }
  return stars;
}

export function readAllStars(): Record<number, number> {
  try { return JSON.parse(localStorage.getItem("nova-stars") ?? "{}") ?? {}; } catch { return {}; }
}

export function totalStars(): number {
  const all = readAllStars();
  return Object.values(all).reduce<number>((s, v) => s + (typeof v === "number" ? v : 0), 0);
}

/* ---------------- chapter progress ---------------- */

export function highestStageCleared(): number {
  return Math.max(0, Number(localStorage.getItem("nova-progress") ?? 0) | 0);
}

export function writeProgress(stageN: number) {
  const prev = highestStageCleared();
  if (stageN > prev) {
    try { localStorage.setItem("nova-progress", String(stageN)); } catch { /* private */ }
  }
}

export function chapterProgress(_chapterN = 1): { cleared: number; total: number; stars: number; totalStars: number } {
  const stars = readAllStars();
  let cleared = 0;
  let totalStars = 0;
  for (const s of STAGES) {
    if ((stars[s.n] ?? 0) > 0) cleared++;
    totalStars += (stars[s.n] ?? 0);
  }
  return { cleared, total: STAGES.length, stars: totalStars, totalStars };
}

/* ---------------- settings ---------------- */

export interface Settings {
  sfx: boolean;
  music: boolean;
  quality: "auto" | "high" | "med" | "low";
  reducedMotion: boolean;
}

export function readSettings(): Settings {
  try {
    const raw = JSON.parse(localStorage.getItem("nova-settings") ?? "{}");
    return {
      sfx: raw.sfx ?? true,
      music: raw.music ?? true,
      quality: raw.quality ?? "auto",
      reducedMotion: raw.reducedMotion ?? false,
    };
  } catch {
    return { sfx: true, music: true, quality: "auto", reducedMotion: false };
  }
}

export function writeSettings(s: Settings) {
  try { localStorage.setItem("nova-settings", JSON.stringify(s)); } catch { /* private */ }
}
