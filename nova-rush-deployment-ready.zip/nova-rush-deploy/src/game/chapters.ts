/* Nova Rush — chapter list */

export interface Chapter {
  n: number;
  title: string;
  subtitle: string;
  unlock: { stars: number; chapter: number };
  body: string;
}

export const CHAPTERS: Chapter[] = [
  {
    n: 1,
    title: "The Milky Way",
    subtitle: "Chapter 01",
    unlock: { stars: 0, chapter: 0 },
    body: "Ten worlds. One star. Nova's first stop in a galaxy that doesn't sound like home.",
  },
  {
    n: 2,
    title: "Andromeda",
    subtitle: "Chapter 02",
    unlock: { stars: 28, chapter: 1 },
    body: "The nearest spiral. A thousand billion suns older than ours.",
  },
  {
    n: 3,
    title: "The Triangulum",
    subtitle: "Chapter 03",
    unlock: { stars: 60, chapter: 2 },
    body: "A small galaxy that refuses to fall. Nova follows a signal in its tail.",
  },
  {
    n: 4,
    title: "The Sculptor Group",
    subtitle: "Chapter 04",
    unlock: { stars: 90, chapter: 3 },
    body: "An empty corner of the local sheet. Something is breathing there.",
  },
  {
    n: 5,
    title: "The Virgo Cluster",
    subtitle: "Chapter 05",
    unlock: { stars: 120, chapter: 4 },
    body: "A thousand galaxies in one frame. Nova must cross it without losing the song.",
  },
  {
    n: 6,
    title: "The Boötes Void",
    subtitle: "Chapter 06",
    unlock: { stars: 160, chapter: 5 },
    body: "A bubble of almost nothing. 330 million light-years across. Almost nothing.",
  },
  {
    n: 7,
    title: "The Great Attractor",
    subtitle: "Chapter 07",
    unlock: { stars: 200, chapter: 6 },
    body: "Everything is falling. Nova is falling. The question is what she's falling toward.",
  },
  {
    n: 8,
    title: "The Cosmic Web",
    subtitle: "Chapter 08",
    unlock: { stars: 240, chapter: 7 },
    body: "Filaments of light between dark. The galaxy isn't alone. Nothing is.",
  },
  {
    n: 9,
    title: "The Edge",
    subtitle: "Chapter 09",
    unlock: { stars: 280, chapter: 8 },
    body: "Where the universe forgets to be a universe. The last long dark before the home signal.",
  },
];

export function isChapterUnlocked(n: number, totalStars: number): boolean {
  const ch = CHAPTERS.find((c) => c.n === n);
  if (!ch) return false;
  return totalStars >= ch.unlock.stars;
}
