/* ==========================================================================
   Nova Rush — comet character art
   Paints a detailed, physically-inspired comet nucleus for each character.

   Real comet anatomy used here:
     • NUCLEUS — small irregular icy body, cratered, low albedo with bright
       fresh-ice patches where jets have blown out the crust.
     • COMA     — diffuse glowing envelope of sublimated gas around nucleus.
     • JETS     — collimated streams of gas/dust venting from active areas.
     • TAILS    — drawn by the engine (straight ion tail + curved dust tail).
   ========================================================================== */

export type CometId = "pulse" | "ice" | "fire" | "cosmic" | "rainbow";

export interface CometMaterial {
  /** base rock/ice body tones, dark → light */
  shadow: string;
  body: string;
  highlight: string;
  /** emissive material that glows from cracks / facets / core */
  emissive: string;
  emissive2: string;
  /** coma (atmosphere) tint */
  coma: string;
  /** ion tail (straight, gas) */
  ion: string;
  /** dust tail (curved, reflective grains) */
  dust: string;
  /** number of visible venting jets */
  jets: number;
}

export const MATERIALS: Record<CometId, CometMaterial> = {
  pulse: {
    shadow: "#0a1626",
    body: "#1e3a5f",
    highlight: "#7dd3fc",
    emissive: "#22d3ee",
    emissive2: "#a855f7",
    coma: "103,232,249",
    ion: "56,189,248",
    dust: "196,224,255",
    jets: 3,
  },
  ice: {
    shadow: "#0b2436",
    body: "#1e4e6b",
    highlight: "#e0f7ff",
    emissive: "#bae6fd",
    emissive2: "#ffffff",
    coma: "186,230,253",
    ion: "125,211,252",
    dust: "235,250,255",
    jets: 4,
  },
  fire: {
    shadow: "#1a0a04",
    body: "#3d1708",
    highlight: "#fdba74",
    emissive: "#fb923c",
    emissive2: "#fde047",
    coma: "251,146,60",
    ion: "248,113,113",
    dust: "254,215,170",
    jets: 5,
  },
  cosmic: {
    shadow: "#120826",
    body: "#2e1065",
    highlight: "#e9d5ff",
    emissive: "#d946ef",
    emissive2: "#818cf8",
    coma: "168,85,247",
    ion: "192,132,252",
    dust: "233,213,255",
    jets: 3,
  },
  rainbow: {
    shadow: "#160d24",
    body: "#312e5f",
    highlight: "#ffffff",
    emissive: "#fb7185",
    emissive2: "#34d399",
    coma: "226,232,240",
    ion: "125,211,252",
    dust: "255,255,255",
    jets: 4,
  },
};

/* ---------------- deterministic noise ---------------- */

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SEEDS: Record<CometId, number> = { pulse: 7, ice: 23, fire: 41, cosmic: 59, rainbow: 83 };

/** Irregular nucleus silhouette — comets are lumpy, never spherical. */
function nucleusShape(id: CometId, lobes = 13): number[] {
  const rand = mulberry32(SEEDS[id]);
  const out: number[] = [];
  for (let i = 0; i < lobes; i++) {
    // low-frequency lumpiness + high-frequency surface roughness
    const big = 0.82 + rand() * 0.30;
    const small = 0.96 + rand() * 0.08;
    out.push(big * small);
  }
  return out;
}

/**
 * Paint a detailed comet nucleus centred in a square canvas of side `S`.
 * Returns the canvas so callers can cache it as a sprite.
 */
export function paintCometNucleus(id: CometId, S: number): HTMLCanvasElement {
  const m = MATERIALS[id];
  const c = document.createElement("canvas");
  c.width = S;
  c.height = S;
  const x = c.getContext("2d")!;
  const cx = S / 2;
  const cy = S / 2;
  const R = S * 0.34; // nucleus radius — small vs. the coma around it
  const rand = mulberry32(SEEDS[id] + 101);
  const verts = nucleusShape(id);
  const n = verts.length;

  const radiusAt = (ang: number) => {
    const t = ((ang / (Math.PI * 2)) % 1 + 1) % 1;
    const f = t * n;
    const i0 = Math.floor(f) % n;
    const i1 = (i0 + 1) % n;
    const k = f - Math.floor(f);
    const s = k * k * (3 - 2 * k); // smoothstep between lobes
    return R * (verts[i0] * (1 - s) + verts[i1] * s);
  };

  const tracePath = (scale = 1) => {
    x.beginPath();
    const STEPS = 96;
    for (let i = 0; i <= STEPS; i++) {
      const ang = (i / STEPS) * Math.PI * 2;
      const rr = radiusAt(ang) * scale;
      const px = cx + Math.cos(ang) * rr;
      const py = cy + Math.sin(ang) * rr;
      if (i === 0) x.moveTo(px, py);
      else x.lineTo(px, py);
    }
    x.closePath();
  };

  /* ---- 1. body with terminator shading (light from upper-left) ---- */
  tracePath();
  const bodyGrad = x.createRadialGradient(cx - R * 0.42, cy - R * 0.46, R * 0.05, cx, cy, R * 1.25);
  bodyGrad.addColorStop(0, m.highlight);
  bodyGrad.addColorStop(0.3, m.body);
  bodyGrad.addColorStop(1, m.shadow);
  x.fillStyle = bodyGrad;
  x.fill();

  /* ---- 2. surface craters & pits ---- */
  x.save();
  tracePath();
  x.clip();
  const craterCount = 11;
  for (let i = 0; i < craterCount; i++) {
    const ang = rand() * Math.PI * 2;
    const dist = Math.sqrt(rand()) * R * 0.86;
    const px = cx + Math.cos(ang) * dist;
    const py = cy + Math.sin(ang) * dist;
    const cr = R * (0.07 + rand() * 0.15);
    // crater floor (shadowed)
    const g = x.createRadialGradient(px - cr * 0.2, py - cr * 0.2, 0, px, py, cr);
    g.addColorStop(0, m.shadow);
    g.addColorStop(0.75, `${m.shadow}00`);
    g.addColorStop(1, `${m.shadow}00`);
    x.globalAlpha = 0.55;
    x.fillStyle = g;
    x.beginPath();
    x.arc(px, py, cr, 0, Math.PI * 2);
    x.fill();
    // sunlit rim arc on the upper-left edge
    x.globalAlpha = 0.5;
    x.strokeStyle = m.highlight;
    x.lineWidth = Math.max(0.6, cr * 0.13);
    x.beginPath();
    x.arc(px, py, cr * 0.92, Math.PI * 0.78, Math.PI * 1.85);
    x.stroke();
  }
  x.globalAlpha = 1;

  /* ---- 3. material-specific surface treatment ---- */
  paintSurface(x, id, cx, cy, R, m, rand);

  x.restore();

  /* ---- 4. rim light along the lit limb ---- */
  x.save();
  tracePath();
  x.clip();
  x.globalCompositeOperation = "lighter";
  const rim = x.createRadialGradient(cx - R * 0.5, cy - R * 0.55, R * 0.2, cx - R * 0.3, cy - R * 0.3, R * 1.5);
  rim.addColorStop(0, "rgba(255,255,255,0.4)");
  rim.addColorStop(0.5, "rgba(255,255,255,0.05)");
  rim.addColorStop(1, "rgba(255,255,255,0)");
  x.fillStyle = rim;
  x.fillRect(0, 0, S, S);
  x.restore();

  /* ---- 5. thin terminator outline so it reads against the coma ---- */
  x.save();
  tracePath();
  x.strokeStyle = "rgba(255,255,255,0.22)";
  x.lineWidth = 1;
  x.stroke();
  x.restore();

  return c;
}

/* ---------------- per-material surface detail ---------------- */

function paintSurface(
  x: CanvasRenderingContext2D,
  id: CometId,
  cx: number,
  cy: number,
  R: number,
  m: CometMaterial,
  rand: () => number,
) {
  switch (id) {
    case "pulse": {
      // fresh-ice fracture veins glowing with sublimating gas
      x.globalCompositeOperation = "lighter";
      x.strokeStyle = m.emissive;
      for (let i = 0; i < 5; i++) {
        const a0 = rand() * Math.PI * 2;
        x.globalAlpha = 0.3 + rand() * 0.3;
        x.lineWidth = R * (0.025 + rand() * 0.03);
        x.beginPath();
        let px = cx + Math.cos(a0) * R * 0.85;
        let py = cy + Math.sin(a0) * R * 0.85;
        x.moveTo(px, py);
        for (let k = 0; k < 4; k++) {
          px += (rand() - 0.5) * R * 0.5;
          py += (rand() - 0.5) * R * 0.5;
          x.lineTo(px, py);
        }
        x.stroke();
      }
      x.globalAlpha = 1;
      x.globalCompositeOperation = "source-over";
      break;
    }
    case "ice": {
      // crystalline facets — flat planes catching light
      x.globalCompositeOperation = "lighter";
      for (let i = 0; i < 9; i++) {
        const a0 = rand() * Math.PI * 2;
        const d = rand() * R * 0.7;
        const px = cx + Math.cos(a0) * d;
        const py = cy + Math.sin(a0) * d;
        const size = R * (0.16 + rand() * 0.22);
        const rot = rand() * Math.PI;
        x.globalAlpha = 0.14 + rand() * 0.22;
        x.fillStyle = m.highlight;
        x.beginPath();
        for (let k = 0; k < 5; k++) {
          const a = rot + (k / 5) * Math.PI * 2;
          const rr = size * (0.6 + ((k * 37) % 10) / 22);
          const fx = px + Math.cos(a) * rr;
          const fy = py + Math.sin(a) * rr * 0.75;
          if (k === 0) x.moveTo(fx, fy);
          else x.lineTo(fx, fy);
        }
        x.closePath();
        x.fill();
        // facet edge glint
        x.globalAlpha = 0.5;
        x.strokeStyle = "#ffffff";
        x.lineWidth = 0.8;
        x.stroke();
      }
      x.globalAlpha = 1;
      x.globalCompositeOperation = "source-over";
      break;
    }
    case "fire": {
      // molten crust — a crackle network with lava glowing underneath
      x.globalCompositeOperation = "lighter";
      for (let i = 0; i < 7; i++) {
        const a0 = rand() * Math.PI * 2;
        const grd = x.createLinearGradient(
          cx + Math.cos(a0) * R,
          cy + Math.sin(a0) * R,
          cx - Math.cos(a0) * R,
          cy - Math.sin(a0) * R,
        );
        grd.addColorStop(0, m.emissive2);
        grd.addColorStop(0.5, m.emissive);
        grd.addColorStop(1, "rgba(0,0,0,0)");
        x.strokeStyle = grd;
        x.globalAlpha = 0.5 + rand() * 0.4;
        x.lineWidth = R * (0.03 + rand() * 0.05);
        x.beginPath();
        let px = cx + Math.cos(a0) * R * 0.9;
        let py = cy + Math.sin(a0) * R * 0.9;
        x.moveTo(px, py);
        for (let k = 0; k < 5; k++) {
          px += (rand() - 0.5) * R * 0.55;
          py += (rand() - 0.5) * R * 0.55;
          x.lineTo(px, py);
        }
        x.stroke();
      }
      // hot core bleeding through
      x.globalAlpha = 0.55;
      const core = x.createRadialGradient(cx, cy + R * 0.15, 0, cx, cy + R * 0.15, R * 0.75);
      core.addColorStop(0, m.emissive2);
      core.addColorStop(0.45, m.emissive);
      core.addColorStop(1, "rgba(0,0,0,0)");
      x.fillStyle = core;
      x.beginPath();
      x.arc(cx, cy, R, 0, Math.PI * 2);
      x.fill();
      x.globalAlpha = 1;
      x.globalCompositeOperation = "source-over";
      break;
    }
    case "cosmic": {
      // a pocket galaxy embedded in the ice — swirl + starfield
      x.globalCompositeOperation = "lighter";
      for (let arm = 0; arm < 2; arm++) {
        x.globalAlpha = 0.5;
        x.strokeStyle = arm === 0 ? m.emissive : m.emissive2;
        x.lineWidth = R * 0.14;
        x.beginPath();
        for (let t = 0; t < 40; t++) {
          const f = t / 40;
          const ang = arm * Math.PI + f * Math.PI * 1.9;
          const rr = f * R * 0.85;
          const px = cx + Math.cos(ang) * rr;
          const py = cy + Math.sin(ang) * rr * 0.85;
          if (t === 0) x.moveTo(px, py);
          else x.lineTo(px, py);
        }
        x.stroke();
      }
      // galactic core
      x.globalAlpha = 0.9;
      const gc = x.createRadialGradient(cx, cy, 0, cx, cy, R * 0.3);
      gc.addColorStop(0, "#ffffff");
      gc.addColorStop(0.4, m.emissive);
      gc.addColorStop(1, "rgba(0,0,0,0)");
      x.fillStyle = gc;
      x.beginPath();
      x.arc(cx, cy, R * 0.3, 0, Math.PI * 2);
      x.fill();
      // embedded stars
      for (let i = 0; i < 18; i++) {
        const a0 = rand() * Math.PI * 2;
        const d = Math.sqrt(rand()) * R * 0.9;
        x.globalAlpha = 0.5 + rand() * 0.5;
        x.fillStyle = "#ffffff";
        x.beginPath();
        x.arc(cx + Math.cos(a0) * d, cy + Math.sin(a0) * d, rand() * 1.3 + 0.4, 0, Math.PI * 2);
        x.fill();
      }
      x.globalAlpha = 1;
      x.globalCompositeOperation = "source-over";
      break;
    }
    case "rainbow": {
      // iridescent oil-slick shell — thin-film interference banding
      x.globalCompositeOperation = "lighter";
      const hues = ["#fb7185", "#fb923c", "#facc15", "#34d399", "#22d3ee", "#818cf8", "#d946ef"];
      for (let i = 0; i < hues.length; i++) {
        const f = i / hues.length;
        x.globalAlpha = 0.3;
        x.strokeStyle = hues[i];
        x.lineWidth = R * 0.16;
        x.beginPath();
        x.arc(cx - R * 0.15, cy - R * 0.15, R * (0.32 + f * 0.72), f * 1.4, f * 1.4 + Math.PI * 1.1);
        x.stroke();
      }
      // specular prism glint
      x.globalAlpha = 0.85;
      const gl = x.createRadialGradient(cx - R * 0.35, cy - R * 0.4, 0, cx - R * 0.35, cy - R * 0.4, R * 0.42);
      gl.addColorStop(0, "#ffffff");
      gl.addColorStop(1, "rgba(255,255,255,0)");
      x.fillStyle = gl;
      x.beginPath();
      x.arc(cx - R * 0.35, cy - R * 0.4, R * 0.42, 0, Math.PI * 2);
      x.fill();
      x.globalAlpha = 1;
      x.globalCompositeOperation = "source-over";
      break;
    }
  }
}

/**
 * Paint a full "portrait" of the comet (nucleus + coma + tails) — used by the
 * shop so the character preview matches what you fly in-game.
 */
export function paintCometPortrait(id: CometId, W: number, H: number): HTMLCanvasElement {
  const m = MATERIALS[id];
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const x = c.getContext("2d")!;
  const cx = W * 0.62;
  const cy = H * 0.5;
  const nucSize = Math.min(W, H) * 0.56;

  // --- dust tail: broad, curved, warm, lags behind the orbit ---
  x.save();
  x.globalCompositeOperation = "lighter";
  for (let i = 0; i < 26; i++) {
    const f = i / 26;
    const curve = f * f * H * 0.22;
    const px = cx - f * W * 0.72;
    const py = cy + curve;
    const rr = (1 - f) * nucSize * 0.42 + 4;
    const g = x.createRadialGradient(px, py, 0, px, py, rr);
    g.addColorStop(0, `rgba(${hexToRgb(m.dust)},${0.2 * (1 - f)})`);
    g.addColorStop(1, "rgba(0,0,0,0)");
    x.fillStyle = g;
    x.beginPath();
    x.arc(px, py, rr, 0, Math.PI * 2);
    x.fill();
  }
  // --- ion tail: narrow, straight, cool blue, points dead away ---
  for (let i = 0; i < 24; i++) {
    const f = i / 24;
    const px = cx - f * W * 0.85;
    const py = cy - f * H * 0.05;
    const rr = (1 - f) * nucSize * 0.16 + 2;
    const g = x.createRadialGradient(px, py, 0, px, py, rr);
    g.addColorStop(0, `rgba(${m.ion.includes(",") ? m.ion : hexToRgb(m.ion)},${0.34 * (1 - f)})`);
    g.addColorStop(1, "rgba(0,0,0,0)");
    x.fillStyle = g;
    x.beginPath();
    x.arc(px, py, rr, 0, Math.PI * 2);
    x.fill();
  }
  x.restore();

  // --- coma: diffuse gas envelope ---
  x.save();
  x.globalCompositeOperation = "lighter";
  const coma = x.createRadialGradient(cx, cy, nucSize * 0.18, cx, cy, nucSize * 0.92);
  coma.addColorStop(0, `rgba(${m.coma},0.55)`);
  coma.addColorStop(0.45, `rgba(${m.coma},0.2)`);
  coma.addColorStop(1, `rgba(${m.coma},0)`);
  x.fillStyle = coma;
  x.beginPath();
  x.arc(cx, cy, nucSize * 0.92, 0, Math.PI * 2);
  x.fill();
  x.restore();

  // --- venting jets ---
  x.save();
  x.globalCompositeOperation = "lighter";
  for (let i = 0; i < m.jets; i++) {
    const ang = Math.PI * 0.75 + (i / Math.max(1, m.jets - 1)) * Math.PI * 0.6;
    const len = nucSize * (0.42 + (i % 2) * 0.2);
    const g = x.createLinearGradient(cx, cy, cx + Math.cos(ang) * len, cy + Math.sin(ang) * len);
    g.addColorStop(0, `rgba(${m.coma},0.5)`);
    g.addColorStop(1, `rgba(${m.coma},0)`);
    x.strokeStyle = g;
    x.lineWidth = nucSize * 0.07;
    x.lineCap = "round";
    x.beginPath();
    x.moveTo(cx + Math.cos(ang) * nucSize * 0.2, cy + Math.sin(ang) * nucSize * 0.2);
    x.lineTo(cx + Math.cos(ang) * len, cy + Math.sin(ang) * len);
    x.stroke();
  }
  x.restore();

  // --- nucleus ---
  const nuc = paintCometNucleus(id, Math.round(nucSize));
  x.drawImage(nuc, cx - nucSize / 2, cy - nucSize / 2, nucSize, nucSize);

  return c;
}

function hexToRgb(h: string): string {
  if (h.includes(",")) return h;
  const n = parseInt(h.replace("#", ""), 16);
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}
