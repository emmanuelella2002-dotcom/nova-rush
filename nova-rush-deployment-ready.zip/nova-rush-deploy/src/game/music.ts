/* ==========================================================================
   Nova Rush — synthesized theme song (WebAudio, zero assets)
   Six sci-fi scores built from modal/atonal harmony — drifting drones, metallic
   arps and sub-bass. Nothing resolves the way pop music does, by design.
   Intensity adapts: menu = chill, gameplay = full throttle.
   ========================================================================== */

const BARS = 4;

export interface Track {
  id: string;
  name: string;
  bpm: number;
  /** 4-bar chord progression (midi) */
  chords: number[][];
  /** bass root per bar */
  bass: number[];
  /** which chord tone the arp walks each 16th */
  arp: number[];
  /** drum feel */
  drums: "fourfloor" | "breaks" | "halftime" | "driving";
  /** lead oscillator flavour */
  lead: OscillatorType;
  bassWave: OscillatorType;
  /** arp octave offset */
  arpOct: number;
}

export const TRACKS: Track[] = [
  {
    // Lydian-tinged, wide and weightless — deep-space travel
    id: "driftfield",
    name: "Driftfield",
    bpm: 104,
    chords: [[50, 57, 61], [52, 59, 62], [48, 55, 59], [53, 60, 64]],
    bass: [38, 40, 36, 41],
    arp: [0, 2, 1, 2],
    drums: "halftime",
    lead: "sine",
    bassWave: "sawtooth",
    arpOct: 24,
  },
  {
    // Phrygian menace — stalking something much larger than you
    id: "eventhorizon",
    name: "Event Horizon",
    bpm: 88,
    chords: [[45, 49, 52], [46, 50, 53], [45, 48, 52], [43, 47, 50]],
    bass: [33, 34, 33, 31],
    arp: [0, 1, 0, 2],
    drums: "halftime",
    lead: "triangle",
    bassWave: "sawtooth",
    arpOct: 24,
  },
  {
    // Whole-tone ambiguity — nothing here resolves
    id: "ionstorm",
    name: "Ion Storm",
    bpm: 132,
    chords: [[50, 54, 58], [52, 56, 60], [48, 52, 56], [54, 58, 62]],
    bass: [38, 40, 36, 42],
    arp: [0, 1, 2, 1],
    drums: "driving",
    lead: "sawtooth",
    bassWave: "square",
    arpOct: 12,
  },
  {
    // Locrian unease, broken rhythm — derelict machinery
    id: "derelict",
    name: "Derelict Signal",
    bpm: 112,
    chords: [[47, 50, 53], [49, 52, 56], [45, 48, 51], [50, 53, 57]],
    bass: [35, 37, 33, 38],
    arp: [0, 2, 1, 0],
    drums: "breaks",
    lead: "square",
    bassWave: "sawtooth",
    arpOct: 12,
  },
  {
    // Octatonic drive — the chase
    id: "singularity",
    name: "Singularity Run",
    bpm: 148,
    chords: [[45, 48, 54], [48, 51, 57], [51, 54, 60], [42, 45, 51]],
    bass: [33, 36, 39, 30],
    arp: [0, 2, 1, 2],
    drums: "driving",
    lead: "sawtooth",
    bassWave: "square",
    arpOct: 12,
  },
  {
    // Quartal stack, slow burn — the Sun
    id: "stellarcore",
    name: "Stellar Core",
    bpm: 120,
    chords: [[48, 53, 58], [50, 55, 60], [46, 51, 56], [53, 58, 63]],
    bass: [36, 38, 34, 41],
    arp: [0, 1, 2, 1],
    drums: "fourfloor",
    lead: "triangle",
    bassWave: "sawtooth",
    arpOct: 24,
  },
];

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

class MusicEngine {
  /** index into TRACKS */
  private trackIdx = 0;
  private get track(): Track { return TRACKS[this.trackIdx] ?? TRACKS[0]; }
  private get stepDur(): number { return 60 / this.track.bpm / 4; }

  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private delaySend: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private timer: ReturnType<typeof setInterval> | null = null;

  private step = 0;
  private nextT = 0;
  private intensity = 0.45;
  private targetIntensity = 0.45;
  playing = false;
  muted: boolean;

  constructor() {
    this.muted = typeof localStorage !== "undefined" && localStorage.getItem("nova-music-muted") === "1";
    if (typeof localStorage !== "undefined") {
      const saved = Number(localStorage.getItem("nova-track") ?? 0);
      if (Number.isFinite(saved) && saved >= 0 && saved < TRACKS.length) this.trackIdx = saved;
    }
  }

  /** must be called from a user gesture */
  unlock() {
    if (!this.ctx) {
      const AC: typeof AudioContext | undefined =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.34;
      this.master.connect(this.ctx.destination);

      // echo bus for the arp — instant synthwave space
      const delay = this.ctx.createDelay(1);
      delay.delayTime.value = (60 / 118 / 4) * 3;
      const fb = this.ctx.createGain();
      fb.gain.value = 0.32;
      const wet = this.ctx.createGain();
      wet.gain.value = 0.5;
      this.delaySend = this.ctx.createGain();
      this.delaySend.connect(delay);
      delay.connect(fb).connect(delay);
      delay.connect(wet).connect(this.master);

      const len = this.ctx.sampleRate;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

      if (!this.muted) this.start();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  start() {
    if (!this.ctx || this.playing) return;
    this.playing = true;
    this.step = 0;
    this.nextT = this.ctx.currentTime + 0.08;
    this.timer = setInterval(() => this.pump(), 28);
  }

  stop() {
    this.playing = false;
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem("nova-music-muted", m ? "1" : "0");
    } catch {
      /* private mode */
    }
    if (this.master && this.ctx) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.linearRampToValueAtTime(m ? 0 : 0.34, this.ctx.currentTime + 0.15);
    }
  }

  get trackName(): string { return this.track.name; }
  get trackIndex(): number { return this.trackIdx; }
  get trackCount(): number { return TRACKS.length; }

  /** switch songs; restarts the sequencer cleanly on the new tempo */
  setTrack(idx: number) {
    const next = ((idx % TRACKS.length) + TRACKS.length) % TRACKS.length;
    if (next === this.trackIdx) return;
    this.trackIdx = next;
    try { localStorage.setItem("nova-track", String(next)); } catch { /* private */ }
    if (this.playing && this.ctx) {
      this.step = 0;
      this.nextT = this.ctx.currentTime + 0.05;
    }
  }

  nextTrack() { this.setTrack(this.trackIdx + 1); }

  /** pick a different song at random — used between stages */
  shuffle() {
    if (TRACKS.length < 2) return;
    let n = this.trackIdx;
    while (n === this.trackIdx) n = Math.floor(Math.random() * TRACKS.length);
    this.setTrack(n);
  }

  setIntensity(v: number) {
    this.targetIntensity = Math.max(0, Math.min(1, v));
  }

  private pump() {
    if (!this.ctx || !this.playing) return;
    while (this.nextT < this.ctx.currentTime + 0.14) {
      this.scheduleStep(this.step, this.nextT);
      this.nextT += this.stepDur;
      this.step = (this.step + 1) % (BARS * 16);
    }
  }

  /* ---------------- instruments ---------------- */

  private kick(t: number, v: number) {
    const c = this.ctx!;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.11);
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    o.connect(g).connect(this.master!);
    o.start(t);
    o.stop(t + 0.2);
  }

  private snare(t: number, v: number) {
    const c = this.ctx!;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf!;
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 1900;
    f.Q.value = 0.8;
    const g = c.createGain();
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
    s.connect(f).connect(g).connect(this.master!);
    s.start(t, Math.random());
    s.stop(t + 0.12);
  }

  private hat(t: number, v: number, open = false) {
    const c = this.ctx!;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf!;
    const f = c.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 6800;
    const g = c.createGain();
    const dur = open ? 0.09 : 0.028;
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.master!);
    s.start(t, Math.random());
    s.stop(t + dur + 0.02);
  }

  private bassNote(t: number, midi: number, v: number, cutoff: number) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.type = this.track.bassWave;
    o.frequency.value = mtof(midi);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(cutoff, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(120, cutoff * 0.4), t + this.stepDur * 1.9);
    f.Q.value = 4;
    const g = c.createGain();
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + this.stepDur * 1.9);
    o.connect(f).connect(g).connect(this.master!);
    o.start(t);
    o.stop(t + this.stepDur * 2);
  }

  private arpNote(t: number, midi: number, v: number) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.type = this.track.lead;
    o.frequency.value = mtof(midi);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(v, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
    o.connect(g);
    g.connect(this.master!);
    g.connect(this.delaySend!);
    o.start(t);
    o.stop(t + 0.14);
  }

  private pad(t: number, chord: number[], v: number, cutoff: number) {
    const c = this.ctx!;
    const barDur = this.stepDur * 16;
    for (const midi of chord) {
      for (const det of [-7, 7]) {
        const o = c.createOscillator();
        o.type = "sawtooth";
        o.frequency.value = mtof(midi);
        o.detune.value = det;
        const f = c.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.value = cutoff;
        const g = c.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(v / chord.length, t + barDur * 0.25);
        g.gain.setValueAtTime(v / chord.length, t + barDur * 0.7);
        g.gain.linearRampToValueAtTime(0.0001, t + barDur * 1.04);
        o.connect(f).connect(g).connect(this.master!);
        o.start(t);
        o.stop(t + barDur * 1.06);
      }
    }
  }

  /** Low sustained drone — the bed every sci-fi score sits on. */
  private drone(t: number, midi: number, dur: number, v: number) {
    const c = this.ctx!;
    const out = c.createGain();
    out.gain.setValueAtTime(0.0001, t);
    out.gain.linearRampToValueAtTime(v, t + dur * 0.35);
    out.gain.setValueAtTime(v, t + dur * 0.6);
    out.gain.linearRampToValueAtTime(0.0001, t + dur);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(260, t);
    f.frequency.linearRampToValueAtTime(520, t + dur * 0.5);
    f.frequency.linearRampToValueAtTime(220, t + dur);
    f.Q.value = 2.5;
    // three slightly detuned saws beat against each other — that slow churn
    for (const det of [-11, 0, 9]) {
      const o = c.createOscillator();
      o.type = "sawtooth";
      o.frequency.value = mtof(midi);
      o.detune.value = det;
      o.connect(f);
      o.start(t);
      o.stop(t + dur + 0.08);
    }
    f.connect(out).connect(this.master!);
  }

  /** Metallic bell shimmer — inharmonic partials, very "ship interior". */
  private shimmer(t: number, midi: number, v: number) {
    const c = this.ctx!;
    const base = mtof(midi);
    // deliberately inharmonic ratios so it reads as metal, not a piano
    for (const [ratio, amp, dur] of [[1, 1, 1.6], [2.76, 0.4, 1.1], [5.4, 0.22, 0.8]] as Array<[number, number, number]>) {
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = "sine";
      o.frequency.value = base * ratio;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(v * amp, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g);
      g.connect(this.master!);
      g.connect(this.delaySend!);
      o.start(t);
      o.stop(t + dur + 0.05);
    }
  }

  /* ---------------- sequencer ---------------- */

  private scheduleStep(step: number, t: number) {
    // ease intensity toward target for musical transitions
    this.intensity += (this.targetIntensity - this.intensity) * 0.06;
    const i = this.intensity;

    const bar = Math.floor(step / 16) % BARS;
    const st = step % 16;
    const chord = this.track.chords[bar];
    const root = this.track.bass[bar];

    // drums — each track has its own feel
    const feel = this.track.drums;
    if (i > 0.45) {
      switch (feel) {
        case "fourfloor":
          if (st % 4 === 0) this.kick(t, 0.85);
          if (st === 4 || st === 12) this.snare(t, 0.4 * Math.min(1, i * 1.3));
          break;
        case "driving":
          if (st % 4 === 0 || st === 10) this.kick(t, 0.8);
          if (st === 4 || st === 12) this.snare(t, 0.45 * Math.min(1, i * 1.3));
          break;
        case "breaks":
          if (st === 0 || st === 6 || st === 10) this.kick(t, 0.82);
          if (st === 4 || st === 12 || st === 14) this.snare(t, 0.38 * Math.min(1, i * 1.3));
          break;
        case "halftime":
          if (st === 0 || st === 8) this.kick(t, 0.9);
          if (st === 8) this.snare(t, 0.42 * Math.min(1, i * 1.3));
          break;
      }
    }
    const hatRate = feel === "halftime" ? 4 : 2;
    if (st % hatRate === 0 && i > 0.3) {
      this.hat(t, (st % 4 === 2 ? 0.14 : 0.07) * Math.min(1, i * 1.5), st === 14);
    }

    // bass — driving 8ths with an octave hop
    if (st % 2 === 0) {
      const hop = st % 8 === 6 ? 12 : st === 14 ? 7 : 0;
      this.bassNote(t, root + hop, 0.4 + 0.14 * i, 380 + i * 720);
    }

    // arp — 16th echo trail
    const arpMidi = chord[this.track.arp[st % 4]] + (st % 8 < 4 ? this.track.arpOct : this.track.arpOct + 12);
    this.arpNote(t, arpMidi, (0.05 + 0.1 * i) * (st % 4 === 0 ? 1.25 : 1));

    // pads breathe at the top of every bar
    if (st === 0) this.pad(t, chord, 0.42 * (1.15 - i * 0.45), 620 + i * 480);

    // sustained sub-drone underpins every bar
    if (st === 0) this.drone(t, root - 12, this.stepDur * 16, 0.17 + 0.05 * (1 - i));

    // metallic shimmer marks the phrase — sparse, so it stays eerie
    if (st === 0 && bar % 2 === 0) this.shimmer(t, chord[2] + 12, 0.1 + 0.05 * i);
    if (st === 10 && bar === 3) this.shimmer(t, chord[1] + 24, 0.07);
  }
}

export const music = new MusicEngine();
