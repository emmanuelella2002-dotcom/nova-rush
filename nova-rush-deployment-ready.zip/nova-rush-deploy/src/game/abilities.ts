/* Nova Rush — ball character unique abilities (gun + ultimate) */

export type BallId = "pulse" | "ice" | "fire" | "cosmic" | "rainbow";

/** Unique firing archetype per comet. Each defines how bullets spawn. */
export type BulletArchetype =
  | "machinegun"   // rapid single shot, tighter spread
  | "iceslash"     // 3-blade scissor spread
  | "wavegun"      // 2 wave pulses per shot, slow heavy
  | "seeking"      // homing missiles that curve toward boss
  | "prismLance"   // focused refracting lance that splits white light (prism)
  | "laser";       // thin continuous beam (single bolt)

/** What a weapon does to what it hits. */
/** Each ultimate is a distinct mechanic, matched to its shop description. */
export type UltKind =
  | "novaBurst"      // PULSE   — expanding shockwave rings clear the screen
  | "absoluteZero"   // GLACIER — time freezes; everything is encased in ice
  | "solarFlare"     // INFERNO — a sustained flamethrower beam that ignites
  | "blackHole"      // NEBULA  — gravity well drags everything in and crushes it
  | "spectrumStorm"; // PRISM   — rotating prism lances sweep the field

export type WeaponEffect = "pierce" | "slow" | "burn" | "explosive" | "radiant" | "ricochet";

export const EFFECT_INFO: Record<WeaponEffect, { label: string; blurb: string; color: string }> = {
  pierce:    { label: "PIERCE",    blurb: "Rounds punch clean through targets and keep going.", color: "#67e8f9" },
  slow:      { label: "CHILL",     blurb: "Frost slows whatever it strikes to a crawl.",        color: "#bae6fd" },
  burn:      { label: "BURN",      blurb: "Sets targets alight — damage keeps ticking.",        color: "#fb923c" },
  explosive: { label: "EXPLOSIVE", blurb: "Warheads detonate, damaging everything nearby.",     color: "#d946ef" },
  radiant:   { label: "RADIANT",   blurb: "Light arcs outward, searing nearby targets.",        color: "#fde68a" },
  ricochet:  { label: "RICOCHET",  blurb: "Beams bounce from target to target.",                color: "#34d399" },
};

export interface AbilityDef {
  id: BallId;
  archetype: BulletArchetype;
  /** primary on-hit effect */
  effect: WeaponEffect;
  /** optional secondary effect */
  effect2?: WeaponEffect;
  gun: {
    name: string;
    description: string;
    color: string;        // glow color
    coreColor: string;    // inner core
    rate: number;         // seconds between shots
    speed: number;        // bullet speed
    damage: number;       // hp per hit (boss)
  };
  ultimate: {
    name: string;
    description: string;
    /** how the ultimate actually behaves — not just "more bullets" */
    kind: UltKind;
    duration: number;     // seconds the ult lasts
    rate: number;         // seconds between auto-shots during ult
    color: string;
    color2: string;
  };
}

export const ABILITIES: Record<BallId, AbilityDef> = {
  pulse: {
    id: "pulse",
    effect: "pierce",
    archetype: "machinegun",
    gun: {
      name: "Machine Gun",
      description: "Relentless cyan tracers that punch clean through anything they hit.",
      color: "#67e8f9",
      coreColor: "#f0f9ff",
      rate: 0.08,
      speed: 900,
      damage: 1,
    },
    ultimate: {
      name: "Nova Burst",
      kind: "novaBurst",
      description: "Expanding shockwave rings detonate outward, clearing everything in reach.",
      duration: 9,
      rate: 0.25,
      color: "#22d3ee",
      color2: "#a855f7",
    },
  },
  ice: {
    id: "ice",
    effect: "slow",
    archetype: "iceslash",
    gun: {
      name: "Ice Slash",
      description: "Freezing blades that chill targets to a crawl on impact.",
      color: "#bae6fd",
      coreColor: "#f0f9ff",
      rate: 0.32,
      speed: 760,
      damage: 2,
    },
    ultimate: {
      name: "Absolute Zero",
      kind: "absoluteZero",
      description: "Time itself freezes. Everything on screen is locked in ice and shattered.",
      duration: 10,
      rate: 0.2,
      color: "#38bdf8",
      color2: "#ffffff",
    },
  },
  fire: {
    id: "fire",
    effect: "burn",
    archetype: "wavegun",
    gun: {
      name: "Wave Gun",
      description: "Twin wave pulses that set targets alight and keep them burning.",
      color: "#fb923c",
      coreColor: "#fff7ed",
      rate: 0.34,
      speed: 640,
      damage: 3,
    },
    ultimate: {
      name: "Solar Flare",
      kind: "solarFlare",
      description: "A sustained flamethrower beam that sets the whole field alight.",
      duration: 9,
      rate: 0.22,
      color: "#ef4444",
      color2: "#facc15",
    },
  },
  cosmic: {
    id: "cosmic",
    effect: "explosive",
    archetype: "seeking",
    gun: {
      name: "Seeking Missiles",
      description: "Homing warheads that detonate, damaging everything nearby.",
      color: "#d946ef",
      coreColor: "#fae8ff",
      rate: 0.42,
      speed: 520,
      damage: 3,
    },
    ultimate: {
      name: "Black Hole",
      kind: "blackHole",
      description: "A collapsing gravity well drags everything inward and crushes it.",
      duration: 11,
      rate: 0.28,
      color: "#a855f7",
      color2: "#7c3aed",
    },
  },
  rainbow: {
    id: "rainbow",
    effect: "ricochet",
    effect2: "radiant",
    archetype: "prismLance",
    gun: {
      name: "Prism Lance",
      description: "A refracting lance of pure white light that splits into a rainbow as it flies — ricochets between targets and sears them.",
      color: "#ffffff",
      coreColor: "#ffffff",
      rate: 0.3,
      speed: 860,
      damage: 4,
    },
    ultimate: {
      name: "Prismatic Rupture",
      kind: "spectrumStorm",
      description: "A five-second radial annihilation wave, then transforms into another comet and inherits its weapon.",
      duration: 5,
      rate: 0.08,
      color: "#fb7185",
      color2: "#34d399",
    },
  },
};
