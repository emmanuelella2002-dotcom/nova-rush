/* Nova Rush — chapter 1 (Milky Way): 10 stage/boss definitions */

export interface BossAbility {
  /** which attacks the boss uses and at which HP thresholds (fraction 0..1) */
  pattern: (hpFrac: number) => BossPattern;
  hint: string;
}

export type BossPattern =
  | "swarm" // Mercury — small fast asteroids
  | "ring" // Venus — concentric burst rings
  | "crescent" // Earth — crescents of darts
  | "sandstorm" // Mars — wide-spread slow rocks
  | "pull" // Jupiter — pulls you toward giant rocks
  | "rings" // Saturn — ring of darts around body
  | "ice_storm" // Uranus — wide ice fragments
  | "current" // Neptune — sweeps across screen
  | "flares" // Pluto — solar flare barrages
  | "supernova"; // Sun — radial omnidirectional beams

/** Painted once per stage into an offscreen canvas — the deep-space backdrop. */
export interface StageBackground {
  /** vertical gradient: top, middle, bottom */
  grad: [string, string, string];
  /** soft nebula clouds; x/y are fractions of the viewport, r of its long edge */
  nebulas: Array<{ c: string; x: number; y: number; r: number; a: number }>;
  /** starfield tint, "r,g,b" */
  star: string;
  /** starfield brightness multiplier */
  starAlpha: number;
  /** optional horizontal haze band (dust lanes, cloud decks) */
  band?: { c: string; y: number; h: number; a: number };
}

export interface StageDef {
  n: number;
  name: string;
  subtitle: string;
  distanceTarget: number; // light-years to clear
  /** the backdrop you fly through on this stage */
  bg: StageBackground;
  timeBonus: number; // extra shard award
  starThresholds: [number, number, number]; // score needed for 1/2/3 stars
  boss: {
    hp: number;
    name: string;
    title: string;
    body: string;
    ability: BossAbility;
    palette: [string, string, string]; // outer, mid, core hex
    /** relative size vs. the baseline disc (real planets differ hugely) */
    scale: number;
  };
}

export const STAGES: StageDef[] = [
  {
    n: 1,
    name: "MERCURY",
    subtitle: "The scorched wayfarer.",
    distanceTarget: 150,
    timeBonus: 40,
    starThresholds: [200, 450, 800],
    bg: {
      // scorched rock in the sun's glare — hard light, almost no atmosphere
      grad: ["#1c1008", "#0c0705", "#050302"],
      nebulas: [
        { c: "#ff9a3c", x: 0.82, y: 0.12, r: 0.95, a: 0.30 },
        { c: "#7a3b12", x: 0.15, y: 0.80, r: 0.80, a: 0.18 },
      ],
      star: "255,236,206",
      starAlpha: 0.75,
    },
    boss: {
      hp: 260,
      name: "MERCURY",
      title: "The Swift Messenger",
      body: "Nova's first glimpse of his new galaxy. Mercury darts around the void, hurling fistfuls of molten pebbles at the stranger from afar.",
      ability: { hint: "Dodge the swarms — they're small, but they never stop.", pattern: () => "swarm" },
      // real Mercury: heavily cratered grey regolith with a faint tan cast
      palette: ["#8d857a", "#4a443d", "#17150f"],
      scale: 0.7,
    },
  },
  {
    n: 2,
    name: "VENUS",
    subtitle: "The veiled furnace.",
    distanceTarget: 175,
    timeBonus: 60,
    starThresholds: [300, 700, 1200],
    bg: {
      // drowned in sulphuric haze — thick, close, stifling
      grad: ["#2b2109", "#191205", "#090703"],
      nebulas: [
        { c: "#e8c46a", x: 0.50, y: 0.30, r: 1.05, a: 0.26 },
        { c: "#8a5a2b", x: 0.25, y: 0.85, r: 0.85, a: 0.22 },
      ],
      star: "255,246,214",
      starAlpha: 0.35,
      band: { c: "#d9b36c", y: 0.46, h: 0.30, a: 0.14 },
    },
    boss: {
      hp: 385,
      name: "VENUS",
      title: "The Veiled Furnace",
      body: "Thick clouds pulse with pressure. Venus fires three explosive rings in sequence — each one bigger than the last.",
      ability: { hint: "Stay in the center, weave through the rings as they pulse outward.", pattern: () => "ring" },
      // real Venus: featureless pale cream sulphuric cloud deck
      palette: ["#fff3d0", "#e8c98a", "#9c6b33"],
      scale: 0.92,
    },
  },
  {
    n: 3,
    name: "EARTH",
    subtitle: "Home, but not yours.",
    distanceTarget: 205,
    timeBonus: 80,
    starThresholds: [400, 900, 1500],
    bg: {
      // home skies — deep ocean blue with a faint aurora curtain
      grad: ["#061024", "#030814", "#010409"],
      nebulas: [
        { c: "#2ea8ff", x: 0.20, y: 0.22, r: 0.95, a: 0.26 },
        { c: "#39e0b0", x: 0.85, y: 0.70, r: 0.85, a: 0.20 },
      ],
      star: "226,240,255",
      starAlpha: 1.0,
      band: { c: "#39e0b0", y: 0.18, h: 0.16, a: 0.10 },
    },
    boss: {
      hp: 545,
      name: "EARTH",
      title: "Home, but Not Yours",
      body: "Nova sees his own world. Earth's moon grazes him, opening a path the comet must turn into bullets.",
      ability: { hint: "The crescents sweep — sidestep and return fire when the moon's gone.", pattern: () => "crescent" },
      palette: ["#9fd8ff", "#1d6fc4", "#07263f"],
      scale: 0.96,
    },
  },
  {
    n: 4,
    name: "MARS",
    subtitle: "The rust-coloured desert.",
    distanceTarget: 235,
    timeBonus: 100,
    starThresholds: [500, 1100, 1800],
    bg: {
      // rust-coloured dust suspended in the dark
      grad: ["#1d0d08", "#110704", "#060302"],
      nebulas: [
        { c: "#c1512b", x: 0.72, y: 0.25, r: 0.90, a: 0.26 },
        { c: "#7f3a1d", x: 0.22, y: 0.76, r: 0.95, a: 0.20 },
      ],
      star: "255,226,206",
      starAlpha: 0.7,
      band: { c: "#a3542e", y: 0.60, h: 0.34, a: 0.10 },
    },
    boss: {
      hp: 720,
      name: "MARS",
      title: "Rust Wars",
      body: "Ancient storms kick up slow-moving boulders. They're easy to read, impossible to ignore.",
      ability: { hint: "Stay near the centre — the rocks blanket the edges.", pattern: () => "sandstorm" },
      palette: ["#fb7185", "#dc2626", "#7f1d1d"],
      scale: 0.78,
    },
  },
  {
    n: 5,
    name: "JUPITER",
    subtitle: "The storm-king.",
    distanceTarget: 305,
    timeBonus: 140,
    starThresholds: [600, 1300, 2200],
    bg: {
      // the storm-king's light — turbulent amber, banded and restless
      grad: ["#201306", "#140b04", "#070402"],
      nebulas: [
        { c: "#e08a3c", x: 0.22, y: 0.24, r: 1.05, a: 0.30 },
        { c: "#b5602a", x: 0.80, y: 0.72, r: 0.95, a: 0.22 },
      ],
      star: "255,238,210",
      starAlpha: 0.8,
      band: { c: "#c1703c", y: 0.44, h: 0.26, a: 0.12 },
    },
    boss: {
      hp: 915,
      name: "JUPITER",
      title: "The Storm-King",
      body: "Jupiter's gravity pulls Nova off course. Massive slate boulders barrel through the warped space.",
      ability: { hint: "Lead your shots — the gravity tugs you in.", pattern: () => "pull" },
      palette: ["#f0d2a8", "#c1703c", "#5a2c15"],
      scale: 1.38,
    },
  },
  {
    n: 6,
    name: "SATURN",
    subtitle: "The ringed sentinel.",
    distanceTarget: 270,
    timeBonus: 180,
    starThresholds: [700, 1500, 2600],
    bg: {
      // pale gold, glittering with ring debris
      grad: ["#181407", "#0f0c05", "#050402"],
      nebulas: [
        { c: "#e3c766", x: 0.28, y: 0.26, r: 0.95, a: 0.24 },
        { c: "#fff0bd", x: 0.80, y: 0.68, r: 0.80, a: 0.16 },
      ],
      star: "255,248,224",
      starAlpha: 0.9,
      band: { c: "#f5e3b3", y: 0.52, h: 0.12, a: 0.16 },
    },
    boss: {
      hp: 1130,
      name: "SATURN",
      title: "The Ringed Sentinel",
      body: "A halo of dart-sized ice chunks orbits Saturn. Nova must weave through the gap.",
      ability: { hint: "Find the opening — the ring rotates.", pattern: () => "rings" },
      palette: ["#d8cfa4", "#a8955a", "#4f452a"],
      scale: 1.26,
    },
  },
  {
    n: 7,
    name: "URANUS",
    subtitle: "The sideways wanderer.",
    distanceTarget: 350,
    timeBonus: 220,
    starThresholds: [800, 1700, 3000],
    bg: {
      // tipped on its side, cold and almost featureless
      grad: ["#04171a", "#020e11", "#010607"],
      nebulas: [
        { c: "#4fd6c4", x: 0.30, y: 0.70, r: 1.0, a: 0.24 },
        { c: "#9beef0", x: 0.78, y: 0.20, r: 0.75, a: 0.16 },
      ],
      star: "216,250,255",
      starAlpha: 0.8,
    },
    boss: {
      hp: 1385,
      name: "URANUS",
      title: "The Sideways Wanderer",
      body: "Nova tilts with the planet itself. Icy fragments rain in long waves, mirroring the axis of the world below.",
      ability: { hint: "Move with the planet, not against it.", pattern: () => "ice_storm" },
      palette: ["#b8f5e8", "#4fd6c4", "#136b63"],
      scale: 1.06,
    },
  },
  {
    n: 8,
    name: "NEPTUNE",
    subtitle: "The deep blue guardian.",
    distanceTarget: 395,
    timeBonus: 260,
    starThresholds: [900, 1900, 3400],
    bg: {
      // supersonic winds in the deep blue dark
      grad: ["#060b26", "#030617", "#01030b"],
      nebulas: [
        { c: "#2a56e0", x: 0.18, y: 0.30, r: 1.0, a: 0.30 },
        { c: "#6f4fe0", x: 0.86, y: 0.76, r: 0.85, a: 0.20 },
      ],
      star: "214,228,255",
      starAlpha: 0.95,
      band: { c: "#6fb4ff", y: 0.38, h: 0.10, a: 0.10 },
    },
    boss: {
      hp: 1655,
      name: "NEPTUNE",
      title: "The Deep Blue Guardian",
      body: "Supersonic winds sweep entire sections of the arena. The current changes every six seconds.",
      ability: { hint: "Watch the wind direction. Keep moving against it.", pattern: () => "current" },
      palette: ["#6fb4ff", "#1b43c8", "#0d1f5e"],
      scale: 1.03,
    },
  },
  {
    n: 9,
    name: "PLUTO",
    subtitle: "The exiled outrider.",
    distanceTarget: 450,
    timeBonus: 320,
    starThresholds: [1000, 2100, 3800],
    bg: {
      // the far dark — almost nothing out here
      grad: ["#0b0b10", "#060609", "#020203"],
      nebulas: [
        { c: "#6b6480", x: 0.65, y: 0.35, r: 0.85, a: 0.14 },
        { c: "#8a6f57", x: 0.25, y: 0.80, r: 0.70, a: 0.10 },
      ],
      star: "236,236,248",
      starAlpha: 1.1,
    },
    boss: {
      hp: 1950,
      name: "PLUTO",
      title: "The Exiled Outrider",
      body: "Far from the warmth of the sun, Pluto flares with rage. Solar storms erupt in every direction.",
      ability: { hint: "Take cover in the gaps between flares.", pattern: () => "flares" },
      palette: ["#d9c7b0", "#8a6f57", "#38291c"],
      scale: 0.64,
    },
  },
  {
    n: 10,
    name: "THE SUN",
    subtitle: "The keeper of the Milky Way.",
    distanceTarget: 510,
    timeBonus: 500,
    starThresholds: [1200, 2500, 4500],
    bg: {
      // the heart of the system — overwhelming light
      grad: ["#2e1606", "#1b0c03", "#090401"],
      nebulas: [
        { c: "#ffb347", x: 0.50, y: 0.16, r: 1.25, a: 0.40 },
        { c: "#ff5e2b", x: 0.18, y: 0.72, r: 0.95, a: 0.26 },
        { c: "#fff0c0", x: 0.82, y: 0.60, r: 0.80, a: 0.20 },
      ],
      star: "255,244,214",
      starAlpha: 0.55,
    },
    boss: {
      hp: 2385,
      name: "THE SUN",
      title: "Heart of the Milky Way",
      body: "Nova's first stop. The Sun bears down with every weapon the cosmos can offer — a stellar storm to end the first chapter.",
      ability: { hint: "Survive the bursts. Then strike. Then survive again.", pattern: () => "supernova" },
      palette: ["#fef3c7", "#fbbf24", "#dc2626"],
      scale: 1.55,
    },
  },
];

/** Checkpoint stages — restore lives on these stage transitions. */
export const CHECKPOINTS: readonly number[] = [4, 7, 10];

export function stageForN(n: number): StageDef {
  return STAGES[Math.max(0, Math.min(STAGES.length - 1, n - 1))];
}
