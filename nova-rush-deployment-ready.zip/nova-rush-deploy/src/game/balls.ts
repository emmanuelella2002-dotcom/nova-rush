/* Nova Rush — unlockable ball characters (shared metadata) */

export type BallId = "pulse" | "ice" | "fire" | "cosmic" | "rainbow";

export interface BallDef {
  id: BallId;
  name: string;
  tagline: string;
  price: number; // in shards
  /** CSS gradient stops for the shop preview orb */
  preview: string[];
  rainbow?: boolean;
}

export const BALL_DEFS: BallDef[] = [
  {
    id: "pulse",
    name: "PULSE",
    tagline: "The original comet-core. Standard issue, zero regrets.",
    price: 0,
    preview: ["#f8fafc", "#22d3ee", "#a855f7"],
  },
  {
    id: "ice",
    name: "GLACIER",
    tagline: "Frozen plasma that leaves snow-dust glitter in its wake.",
    price: 90,
    preview: ["#ffffff", "#bae6fd", "#38bdf8"],
  },
  {
    id: "fire",
    name: "INFERNO",
    tagline: "Suspiciously flammable. Sheds live embers as it flies.",
    price: 200,
    preview: ["#fff7ed", "#fb923c", "#ef4444"],
  },
  {
    id: "cosmic",
    name: "NEBULA",
    tagline: "A pocket galaxy, complete with orbiting moonlets.",
    price: 400,
    preview: ["#fae8ff", "#d946ef", "#7c3aed"],
  },
  {
    id: "rainbow",
    name: "PRISM",
    tagline: "Every color of the void at once. Pure flex.",
    price: 700,
    preview: ["#fb7185", "#facc15", "#34d399"],
    rainbow: true,
  },
];

export function readOwned(): BallId[] {
  try {
    const raw = JSON.parse(localStorage.getItem("nova-balls") ?? "[\"pulse\"]");
    if (Array.isArray(raw) && raw.length) return raw.filter((b) => BALL_DEFS.some((d) => d.id === b));
  } catch {
    /* corrupted */
  }
  return ["pulse"];
}

export function readEquipped(): BallId {
  const b = localStorage.getItem("nova-ball");
  return BALL_DEFS.some((d) => d.id === b) ? (b as BallId) : "pulse";
}

export function readCredits(): number {
  return Number(localStorage.getItem("nova-credits") ?? 0) || 0;
}
