/* Nova Rush — synthesized sound engine (WebAudio, zero assets) */

type AudioCtx = AudioContext;

class SoundEngine {
  private ctx: AudioCtx | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private convolver: ConvolverNode | null = null;
  /** active voice count — prevents node-spam from tanking the frame rate */
  private voices = 0;
  private readonly MAX_VOICES = 22;
  /** last-played timestamps for rate-limited sounds */
  private lastAt: Record<string, number> = {};

  /** true if this sound may play now (min gap in seconds) */
  private gate(key: string, minGap: number): boolean {
    const now = this.ctx ? this.ctx.currentTime : 0;
    if ((this.lastAt[key] ?? -99) + minGap > now) return false;
    this.lastAt[key] = now;
    return true;
  }
  private reverbSend: GainNode | null = null;
  muted: boolean;

  constructor() {
    this.muted = typeof localStorage !== "undefined" && localStorage.getItem("nova-muted") === "1";
  }

  /** must be called from a user gesture at least once */
  unlock() {
    if (!this.ctx) {
      const AC: typeof AudioContext | undefined =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      const sr = this.ctx.sampleRate;

      // --- master bus: glue compressor keeps big hits punchy without clipping
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.knee.value = 24;
      comp.ratio.value = 7;
      comp.attack.value = 0.003;
      comp.release.value = 0.22;
      comp.connect(this.ctx.destination);

      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.42;
      this.master.connect(comp);

      // --- convolution reverb: the "big empty hull" space of a ship interior
      const revLen = Math.floor(sr * 2.2);
      const ir = this.ctx.createBuffer(2, revLen, sr);
      for (let ch = 0; ch < 2; ch++) {
        const d = ir.getChannelData(ch);
        for (let i = 0; i < revLen; i++) {
          const t = i / revLen;
          // dense early reflections decaying into a long metallic tail
          d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 2.6) * (1 + Math.sin(t * 90) * 0.25);
        }
      }
      this.convolver = this.ctx.createConvolver();
      this.convolver.buffer = ir;
      const revGain = this.ctx.createGain();
      revGain.gain.value = 0.9;
      this.convolver.connect(revGain).connect(comp);
      this.reverbSend = this.ctx.createGain();
      this.reverbSend.gain.value = 1;
      this.reverbSend.connect(this.convolver);

      // shared 1s noise buffer
      const len = sr;
      this.noiseBuf = this.ctx.createBuffer(1, len, sr);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem("nova-muted", m ? "1" : "0");
    } catch {
      /* private mode */
    }
    if (this.master && this.ctx) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.linearRampToValueAtTime(m ? 0 : 0.42, this.ctx.currentTime + 0.08);
    }
  }

  private tone(
    f0: number,
    f1: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    delay = 0
  ) {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(this.master);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  /** reserve a voice slot; false means we're saturated and should skip */
  private claim(dur: number): boolean {
    if (this.voices >= this.MAX_VOICES) return false;
    this.voices++;
    setTimeout(() => { this.voices = Math.max(0, this.voices - 1); }, (dur + 0.1) * 1000);
    return true;
  }

  /** route a voice through optional stereo pan + reverb send */
  private bus(node: AudioNode, pan = 0, send = 0): AudioNode {
    if (!this.ctx || !this.master) return node;
    let out: AudioNode = node;
    if (pan !== 0 && this.ctx.createStereoPanner) {
      const sp = this.ctx.createStereoPanner();
      sp.pan.value = Math.max(-1, Math.min(1, pan));
      out.connect(sp);
      out = sp;
    }
    out.connect(this.master);
    if (send > 0 && this.reverbSend) {
      const g = this.ctx.createGain();
      g.gain.value = send;
      out.connect(g).connect(this.reverbSend);
    }
    return out;
  }

  /** FM-style metallic voice — the core of sci-fi weapon/impact timbre */
  private fm(opts: {
    carrier: number; carrierEnd?: number; ratio: number; index: number;
    dur: number; vol: number; delay?: number; pan?: number; send?: number;
    type?: OscillatorType;
  }) {
    if (!this.ctx || !this.master || this.muted) return;
    if (!this.claim(opts.dur)) return;
    const t = this.ctx.currentTime + (opts.delay ?? 0);
    const car = this.ctx.createOscillator();
    const mod = this.ctx.createOscillator();
    const modGain = this.ctx.createGain();
    const g = this.ctx.createGain();
    car.type = opts.type ?? "sine";
    mod.type = "sine";
    car.frequency.setValueAtTime(opts.carrier, t);
    if (opts.carrierEnd !== undefined) {
      car.frequency.exponentialRampToValueAtTime(Math.max(1, opts.carrierEnd), t + opts.dur);
    }
    mod.frequency.setValueAtTime(opts.carrier * opts.ratio, t);
    modGain.gain.setValueAtTime(opts.carrier * opts.index, t);
    modGain.gain.exponentialRampToValueAtTime(1, t + opts.dur);
    mod.connect(modGain).connect(car.frequency);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(opts.vol, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + opts.dur);
    car.connect(g);
    this.bus(g, opts.pan ?? 0, opts.send ?? 0);
    car.start(t); mod.start(t);
    car.stop(t + opts.dur + 0.05); mod.stop(t + opts.dur + 0.05);
  }

  /** sub-bass body — the thump you feel rather than hear */
  private sub(f0: number, f1: number, dur: number, vol: number, delay = 0) {
    if (!this.ctx || !this.master || this.muted) return;
    if (!this.claim(dur)) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(12, f1), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    this.bus(g, 0, 0.18);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  /** shaped noise burst — the backbone of realistic impact sound */
  private noiseEx(opts: {
    dur: number; vol: number; f0: number; f1: number; delay?: number;
    type?: BiquadFilterType; q?: number; curve?: "exp" | "lin";
    pan?: number; send?: number;
  }) {
    if (!this.ctx || !this.master || !this.noiseBuf || this.muted) return;
    const { dur, vol, f0, f1 } = opts;
    if (!this.claim(dur)) return;
    const t = this.ctx.currentTime + (opts.delay ?? 0);
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const filter = this.ctx.createBiquadFilter();
    filter.type = opts.type ?? "lowpass";
    filter.Q.value = opts.q ?? 1;
    filter.frequency.setValueAtTime(f0, t);
    filter.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    if ((opts.curve ?? "exp") === "exp") {
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    } else {
      g.gain.linearRampToValueAtTime(0, t + dur);
    }
    src.connect(filter).connect(g);
    this.bus(g, opts.pan ?? 0, opts.send ?? 0);
    src.start(t, Math.random());
    src.stop(t + dur + 0.05);
  }


  /* ==================================================================
     CINEMATIC LAYER
     Trailer-style sweeteners: rising tension, impact hits, bass drops
     and long reverb tails. All procedurally synthesized.
     ================================================================== */

  /** Rising whoosh that builds anticipation before a big beat. */
  private riser(dur: number, vol: number, delay = 0, bright = 1) {
    if (!this.ctx || !this.master || this.muted) return;
    if (!this.claim(dur + delay)) return;
    const t = this.ctx.currentTime + delay;
    // noise sweeping upward through a resonant band — the classic "build"
    this.noiseEx({
      dur, vol: vol * 0.7, f0: 260, f1: 7200 * bright,
      delay, type: "bandpass", q: 1.6, curve: "lin", send: 0.55,
    });
    // detuned pitch-rising pad underneath for harmonic lift
    for (const det of [-9, 9]) {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "sawtooth";
      o.detune.value = det;
      o.frequency.setValueAtTime(110, t);
      o.frequency.exponentialRampToValueAtTime(880 * bright, t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol * 0.3, t + dur * 0.85);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g);
      this.bus(g, det / 90, 0.5);
      o.start(t);
      o.stop(t + dur + 0.05);
    }
  }

  /** Deep cinematic impact — the "boom" that lands on a cut. */
  private impact(vol = 1, delay = 0, pan = 0) {
    // transient crack
    this.noiseEx({
      dur: 0.05, vol: 0.55 * vol, f0: 9000, f1: 2200,
      delay, type: "highpass", q: 0.7, pan,
    });
    // the body: a fast downward sub sweep
    this.sub(110, 26, 0.75 * vol + 0.3, 0.95 * vol, delay);
    // metallic ring for weight
    this.fm({
      carrier: 180, carrierEnd: 42, ratio: 2.41, index: 6,
      dur: 0.6, vol: 0.34 * vol, delay, pan, send: 0.8,
    });
    // long decaying tail into the reverb
    this.noiseEx({
      dur: 1.4, vol: 0.26 * vol, f0: 340, f1: 36,
      delay: delay + 0.05, type: "lowpass", q: 0.8, send: 0.95,
    });
  }

  /** Sub-bass drop that follows an impact — felt more than heard. */
  private bassDrop(vol = 1, delay = 0) {
    this.sub(64, 18, 1.5, 0.75 * vol, delay);
    this.fm({
      carrier: 70, carrierEnd: 22, ratio: 1.01, index: 2.5,
      dur: 1.3, vol: 0.3 * vol, delay, send: 0.6, type: "sine",
    });
  }

  /** Reverse-swell: audio sucked inward, used just before a reveal. */
  private reverseSwell(dur = 0.7, vol = 0.5, delay = 0) {
    if (!this.ctx || !this.master || this.muted) return;
    if (!this.claim(dur + delay)) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    if (!this.noiseBuf) return;
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 2.2;
    // filter sweeps DOWN while gain swells UP — the inhale before the hit
    f.frequency.setValueAtTime(5200, t);
    f.frequency.exponentialRampToValueAtTime(320, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + dur * 0.92);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g);
    this.bus(g, 0, 0.7);
    src.start(t, Math.random());
    src.stop(t + dur + 0.05);
  }

  /** Distant sub-bass rumble — ambient tension under big moments. */
  private rumble(dur: number, vol: number, delay = 0) {
    this.noiseEx({
      dur, vol, f0: 150, f1: 42, delay,
      type: "lowpass", q: 1.2, curve: "lin", send: 0.9,
    });
  }

  /** shard pickup — pitch climbs with combo multiplier */
  pickup(combo: number) {
    if (!this.gate("pickup", 0.04)) return;
    const step = Math.min(combo - 1, 14);
    const base = 620 * Math.pow(2, step / 14);
    this.fm({ carrier: base, ratio: 2.76, index: 1.6, dur: 0.16, vol: 0.3, send: 0.35 });
    this.tone(base * 2, base * 2.6, 0.09, "sine", 0.14, 0.015);
  }

  shieldUp() {
    this.fm({ carrier: 220, carrierEnd: 880, ratio: 1.5, index: 2.5, dur: 0.45, vol: 0.3, send: 0.5 });
    this.tone(440, 1320, 0.4, "sine", 0.22, 0.04);
    this.noiseEx({ dur: 0.5, vol: 0.14, f0: 700, f1: 5200, type: "bandpass", q: 1.4, send: 0.6 });
  }

  shieldBreak() {
    this.noiseEx({ dur: 0.05, vol: 0.6, f0: 9000, f1: 2600, type: "highpass", q: 0.7 });
    this.fm({ carrier: 640, carrierEnd: 90, ratio: 3.7, index: 8, dur: 0.35, vol: 0.34, send: 0.6 });
    for (let i = 0; i < 5; i++) {
      this.noiseEx({
        dur: 0.05, vol: 0.13, f0: 3000 + Math.random() * 4000, f1: 900,
        delay: 0.02 + Math.random() * 0.2, type: "bandpass", q: 6,
        pan: (Math.random() - 0.5) * 1.6, send: 0.5,
      });
    }
    this.sub(140, 40, 0.3, 0.3);
  }

  /** Layered, physically-shaped explosion:
   *  1. crack   — bright transient (the shock front)
   *  2. body    — low-frequency thump you feel
   *  3. debris  — band-passed crackle of scattering fragments
   *  4. tail    — long filtered rumble decaying away  */
  explosion() {
    const pan = (Math.random() - 0.5) * 0.5;
    // 1. shock front — instantaneous bright crack
    this.noiseEx({ dur: 0.045, vol: 0.95, f0: 11000, f1: 3000, type: "highpass", q: 0.6, pan });
    // 2. sub detonation — the body you feel
    this.sub(135, 22, 0.55, 1.0);
    this.sub(70, 16, 0.85, 0.65, 0.02);
    // 3. fireball roar, sweeping down as it expands
    this.noiseEx({ dur: 0.6, vol: 0.82, f0: 3400, f1: 90, type: "lowpass", q: 1.3, pan, send: 0.5 });
    // 4. metallic hull rupture — FM clang gives it mass
    this.fm({ carrier: 320, carrierEnd: 60, ratio: 2.74, index: 7, dur: 0.5, vol: 0.4, pan, send: 0.6 });
    // 5. shrapnel — irregular band-passed debris scattering in stereo
    for (let i = 0; i < 4; i++) {
      this.noiseEx({
        dur: 0.04 + Math.random() * 0.07,
        vol: 0.14 + Math.random() * 0.13,
        f0: 1100 + Math.random() * 3200, f1: 350,
        delay: 0.04 + Math.random() * 0.34,
        type: "bandpass", q: 4,
        pan: (Math.random() - 0.5) * 1.6, send: 0.45,
      });
    }
    // 6. long rumbling tail into the reverb
    this.noiseEx({ dur: 1.1, vol: 0.3, f0: 300, f1: 38, delay: 0.06, type: "lowpass", q: 0.8, send: 0.8 });
    // 7. cinematic sub-drop so large kills land in the chest
    this.bassDrop(0.5, 0.04);
  }

  /** smaller, tighter burst for asteroids / aliens */
  explodeSmall() {
    if (!this.gate("boom", 0.05)) return;
    const pan = (Math.random() - 0.5) * 0.8;
    this.noiseEx({ dur: 0.035, vol: 0.6, f0: 8000, f1: 2400, type: "highpass", q: 0.8, pan });
    this.sub(210, 40, 0.22, 0.55);
    this.noiseEx({ dur: 0.3, vol: 0.52, f0: 2800, f1: 160, type: "lowpass", q: 1.2, pan, send: 0.4 });
    this.fm({ carrier: 520, carrierEnd: 140, ratio: 3.1, index: 5, dur: 0.22, vol: 0.22, pan, send: 0.4 });
    for (let i = 0; i < 2; i++) {
      this.noiseEx({
        dur: 0.035, vol: 0.11, f0: 1500 + Math.random() * 2200, f1: 450,
        delay: 0.03 + Math.random() * 0.13, type: "bandpass", q: 4,
        pan: (Math.random() - 0.5) * 1.4, send: 0.35,
      });
    }
  }

  launch() {
    this.riser(0.5, 0.3, 0, 0.8);
    this.sub(45, 120, 0.8, 0.7);
    this.noiseEx({ dur: 0.9, vol: 0.34, f0: 300, f1: 4200, type: "bandpass", q: 0.9, send: 0.5 });
    this.fm({ carrier: 160, carrierEnd: 680, ratio: 1.33, index: 3.5, dur: 0.7, vol: 0.26, send: 0.4, type: "sawtooth" });
  }

  ui() {
    this.tone(680, 880, 0.07, "sine", 0.22);
  }

  warn() {
    this.fm({ carrier: 210, carrierEnd: 150, ratio: 1.01, index: 2.5, dur: 0.18, vol: 0.2, send: 0.3, type: "square" });
  }

  /** slow-mo powerup — time stretching downward */
  slowmo() {
    this.fm({ carrier: 1200, carrierEnd: 140, ratio: 1.41, index: 3, dur: 0.7, vol: 0.3, send: 0.65 });
    this.noiseEx({ dur: 0.6, vol: 0.16, f0: 4200, f1: 260, type: "lowpass", q: 2, send: 0.6 });
  }

  /** 2× score powerup — bright double ping */
  doublePts() {
    this.tone(740, 1180, 0.11, "triangle", 0.4);
    this.tone(1180, 1760, 0.13, "triangle", 0.35, 0.09);
  }

  /** extra life — warm rising chime */
  life() {
    this.tone(523, 523, 0.14, "sine", 0.35);
    this.tone(659, 659, 0.14, "sine", 0.3, 0.09);
    this.tone(784, 784, 0.26, "sine", 0.35, 0.18);
  }

  /** stage clear — little fanfare arpeggio */
  stageClear() {
    // victory sting: ascending figure landing on a cinematic impact
    const n = [523, 659, 784, 1047];
    n.forEach((f, k) =>
      this.fm({
        carrier: f, ratio: 1.005, index: 1.1,
        dur: 0.34, vol: 0.26, delay: k * 0.1,
        pan: (k - 1.5) * 0.3, send: 0.6, type: "triangle",
      }),
    );
    this.impact(0.7, 0.42);
    this.rumble(1.8, 0.14, 0.45);
  }

  /** consumed a life and bounced back */
  revive() {
    this.sub(60, 180, 0.5, 0.6);
    this.fm({ carrier: 180, carrierEnd: 900, ratio: 1.5, index: 4, dur: 0.5, vol: 0.32, send: 0.5 });
    this.noiseEx({ dur: 0.5, vol: 0.26, f0: 900, f1: 5600, type: "bandpass", q: 1.2, send: 0.55 });
  }

  /** shop purchase — coin chime */
  buy() {
    this.tone(1180, 1180, 0.08, "square", 0.16);
    this.tone(1770, 1770, 0.22, "sine", 0.3, 0.06);
  }

  /** bullet fire — short pew */
  gun() {
    if (!this.gate("gun", 0.055)) return;
    const pan = (Math.random() - 0.5) * 0.35;
    this.fm({ carrier: 1750, carrierEnd: 420, ratio: 1.47, index: 4.5, dur: 0.09, vol: 0.28, pan, send: 0.18, type: "sawtooth" });
  }

  /** ultimate — big swelling tone */
  ult() {
    // charge: a rising sweep that tells you something huge is coming
    this.riser(0.68, 0.5, 0, 1.2);
    this.fm({
      carrier: 90, carrierEnd: 1400, ratio: 2.01, index: 6,
      dur: 0.7, vol: 0.34, send: 0.5, type: "sawtooth",
    });
    // release: the star goes off
    this.impact(1.3, 0.7);
    this.bassDrop(1.1, 0.74);
    this.noiseEx({
      dur: 1.5, vol: 0.5, f0: 7000, f1: 60,
      delay: 0.7, type: "lowpass", q: 1.1, send: 0.95,
    });
  }

  /** boss spawn alarm */
  boss() {
    // the inhale, then the hit — a planet arriving should feel enormous
    this.reverseSwell(0.55, 0.42);
    this.impact(1.15, 0.55);
    this.bassDrop(0.9, 0.6);
    // three descending klaxon blasts over the top
    for (let k = 0; k < 3; k++) {
      this.fm({
        carrier: 150, carrierEnd: 96, ratio: 1.01, index: 3,
        dur: 0.46, vol: 0.34, delay: 0.7 + k * 0.42, send: 0.75, type: "sawtooth",
      });
    }
    this.rumble(2.4, 0.2, 0.6);
  }

  /** hit / impact */
  hit() {
    if (!this.gate("hit", 0.045)) return;
    const pan = (Math.random() - 0.5) * 0.9;
    this.noiseEx({ dur: 0.025, vol: 0.45, f0: 7500, f1: 2200, type: "highpass", q: 0.9, pan });
    this.fm({ carrier: 760, carrierEnd: 180, ratio: 2.9, index: 6, dur: 0.12, vol: 0.26, pan, send: 0.3 });
  }

  /** squadron deploy — ascending fanfare with afterburner wash */
  squadron() {
    this.impact(0.55, 0);
    const n = [392, 523, 659, 784, 1047];
    n.forEach((f, k) => this.fm({
      carrier: f, ratio: 1.01, index: 1.2, dur: 0.26, vol: 0.22,
      delay: k * 0.062, pan: (k - 2) * 0.35, send: 0.45, type: "sawtooth",
    }));
    this.sub(80, 150, 0.7, 0.45);
    this.noiseEx({ dur: 0.85, vol: 0.3, f0: 500, f1: 6000, type: "bandpass", q: 1, delay: 0.05, send: 0.6 });
  }

  /** weapon upgrade — rising two-tone */
  upgrade() {
    this.tone(440, 660, 0.12, "triangle", 0.32);
    this.tone(660, 990, 0.18, "triangle", 0.32, 0.08);
    this.tone(990, 1480, 0.22, "sine", 0.32, 0.16);
  }
}

export const sfx = new SoundEngine();
