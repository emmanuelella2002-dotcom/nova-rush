/**
 * Nova Rush — procedural app-icon generator.
 * Renders a neon comet-orb icon at exact sizes (192, 512, maskable-512)
 * with a hand-rolled PNG encoder (no dependencies).
 * Run: node scripts/make-icons.mjs
 */
import zlib from "node:zlib";
import fs from "node:fs";
import path from "node:path";

/* ---------------- PNG encoder ---------------- */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const out = Buffer.alloc(8 + data.length + 4);
  out.writeUInt32BE(data.length, 0);
  out.write(type, 4, "ascii");
  data.copy(out, 8);
  out.writeUInt32BE(crc32(Buffer.concat([Buffer.from(type, "ascii"), data])), 8 + data.length);
  return out;
}

function encodePNG(width, height, rgba) {
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0; // filter: none
    Buffer.from(rgba.buffer, y * stride, stride).copy(raw, y * (stride + 1) + 1);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // color type RGBA
  const idat = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", idat),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

/* ---------------- tiny helpers ---------------- */

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
const mix = (a, b, t) => a + (b - a) * t;
const mix3 = (a, b, t) => [mix(a[0], b[0], t), mix(a[1], b[1], t), mix(a[2], b[2], t)];

function mulberry32(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------------- icon painter ---------------- */

// palette
const CYAN = [103, 232, 249];
const VIOLET = [168, 85, 247];
const PINK = [244, 114, 182];
const INK = [5, 6, 15];

function paintIcon(S, { maskable = false } = {}) {
  const SS = S * 2; // supersample
  const px = new Float32Array(SS * SS * 4);
  const rand = mulberry32(1337);

  const corner = maskable ? 0 : 0.225 * SS;
  const orbX = 0.5 * SS;
  const orbY = (maskable ? 0.52 : 0.555) * SS;
  const orbR = (maskable ? 0.145 : 0.175) * SS;

  // stars (drawn into bg pass via lookup list)
  const stars = [];
  const nStars = maskable ? 60 : 90;
  for (let i = 0; i < nStars; i++) {
    stars.push({
      x: rand() * SS,
      y: rand() * SS,
      r: (0.4 + rand() * 1.3) * (SS / 512),
      a: 0.25 + rand() * 0.6,
      hue: rand(),
    });
  }

  // comet bezier: top-left -> orb
  const p0 = { x: -0.1 * SS, y: 0.16 * SS };
  const p1 = { x: 0.34 * SS, y: 0.14 * SS };
  const p2 = { x: orbX, y: orbY };
  const bezier = (t) => {
    const u = 1 - t;
    return {
      x: u * u * p0.x + 2 * u * t * p1.x + t * t * p2.x,
      y: u * u * p0.y + 2 * u * t * p1.y + t * t * p2.y,
    };
  };

  for (let y = 0; y < SS; y++) {
    for (let x = 0; x < SS; x++) {
      const i = (y * SS + x) * 4;
      const fx = x / SS, fy = y / SS;

      // rounded-corner mask
      let alpha = 1;
      if (!maskable) {
        const cx = Math.max(corner - x, 0, x - (SS - corner));
        const cy = Math.max(corner - y, 0, y - (SS - corner));
        const d = Math.hypot(cx, cy);
        alpha = 1 - smooth(corner * 0.35, 0, corner - d);
        // distance outside corner circle
        const dist = Math.hypot(Math.max(x - (SS - corner), corner - x, 0), Math.max(y - (SS - corner), corner - y, 0));
        alpha = 1 - smooth(-1.5, 1.5, dist - corner);
      }
      if (alpha <= 0) continue;

      // --- background: deep space gradient + nebulas ---
      let col = mix3([4, 5, 14], [10, 12, 34], fy); // vertical ink
      // violet nebula top-left
      const dNeb1 = Math.hypot(x - 0.18 * SS, y - 0.14 * SS) / (0.75 * SS);
      const neb1 = Math.exp(-dNeb1 * dNeb1 * 2.2) * 0.5;
      col = mix3(col, [76, 29, 149], neb1);
      // cyan nebula bottom-right
      const dNeb2 = Math.hypot(x - 0.9 * SS, y - 0.95 * SS) / (0.7 * SS);
      const neb2 = Math.exp(-dNeb2 * dNeb2 * 2.4) * 0.4;
      col = mix3(col, [12, 74, 110], neb2);

      // stars
      for (const s of stars) {
        const d = Math.hypot(x - s.x, y - s.y);
        if (d < s.r * 3) {
          const tw = Math.exp(-(d * d) / (s.r * s.r)) * s.a;
          const scol = s.hue > 0.7 ? CYAN : [226, 232, 240];
          col = mix3(col, scol, clamp(tw, 0, 1) * 0.9);
        }
      }

      // --- comet trail ---
      // approximate distance to bezier by sampling
      let dTrail = 1e9, tBest = 0;
      for (let k = 0; k <= 40; k++) {
        const t = k / 40;
        const p = bezier(t);
        const d = Math.hypot(x - p.x, y - p.y);
        if (d < dTrail) { dTrail = d; tBest = t; }
      }
      const trailW = mix(0.012, 0.075, tBest * tBest) * SS * 0.6;
      const trailGlow = Math.exp(-(dTrail * dTrail) / (trailW * trailW)) * smooth(0.06, 0.55, tBest) * 0.85;
      const trailCol = mix3(VIOLET, CYAN, tBest);
      col = mix3(col, trailCol, clamp(trailGlow, 0, 1));

      // --- orbit ring ---
      const dxr = (x - orbX) / SS, dyr = (y - orbY) / SS;
      const ringAng = -0.42;
      const rx = dxr * Math.cos(ringAng) - dyr * Math.sin(ringAng);
      const ry = (dxr * Math.sin(ringAng) + dyr * Math.cos(ringAng)) * 2.6;
      const dRing = Math.abs(Math.hypot(rx, ry) - 0.30) * SS;
      const ring = Math.exp(-(dRing * dRing) / (2.2 * (SS / 512) * (SS / 512))) * 0.5;
      col = mix3(col, CYAN, clamp(ring, 0, 1));

      // --- orb glow ---
      const dOrb = Math.hypot(x - orbX, y - orbY);
      const glow = Math.exp(-(dOrb * dOrb) / (orbR * 2.6 * orbR)) * 0.55;
      col = mix3(col, VIOLET, clamp(glow, 0, 1));
      const glow2 = Math.exp(-(dOrb * dOrb) / (orbR * 1.2 * orbR)) * 0.8;
      col = mix3(col, CYAN, clamp(glow2, 0, 1));

      // --- orb core ---
      const core = smooth(orbR, orbR * 0.55, dOrb);
      if (core > 0) {
        // inner shading: bright top-left hotspot
        const hx = x - (orbX - orbR * 0.35), hy = y - (orbY - orbR * 0.4);
        const hot = Math.exp(-(hx * hx + hy * hy) / (orbR * 0.45 * orbR * 0.45));
        let coreCol = mix3([34, 211, 238], [248, 250, 252], clamp(hot, 0, 1));
        coreCol = mix3(coreCol, [255, 255, 255], clamp(Math.exp(-(hx * hx + hy * hy) / (orbR * 0.16 * orbR * 0.16)) , 0, 1) * 0.95);
        col = mix3(col, coreCol, core);
      }

      // --- vignette ---
      const dV = Math.hypot(fx - 0.5, fy - 0.5) * 1.5;
      col = mix3(col, INK, clamp(dV * dV * 0.5, 0, 0.55));

      px[i] = col[0]; px[i + 1] = col[1]; px[i + 2] = col[2];
      px[i + 3] = 255 * alpha;
    }
  }

  // downsample 2x2
  const out = new Uint8ClampedArray(S * S * 4);
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const o = (y * S + x) * 4;
      for (let c = 0; c < 4; c++) {
        const a = px[((y * 2) * SS + x * 2) * 4 + c];
        const b = px[((y * 2) * SS + x * 2 + 1) * 4 + c];
        const cI = px[((y * 2 + 1) * SS + x * 2) * 4 + c];
        const d = px[((y * 2 + 1) * SS + x * 2 + 1) * 4 + c];
        out[o + c] = (a + b + cI + d) / 4;
      }
    }
  }
  return encodePNG(S, S, out);
}

/* ---------------- run ---------------- */

const outDir = path.join("public", "icons");
fs.mkdirSync(outDir, { recursive: true });

const jobs = [
  ["icon-192.png", 192, {}],
  ["icon-512.png", 512, {}],
  ["maskable-512.png", 512, { maskable: true }],
];

for (const [name, size, opts] of jobs) {
  const t0 = Date.now();
  const png = paintIcon(size, opts);
  fs.writeFileSync(path.join(outDir, name), png);
  console.log(`✓ ${name}  ${size}x${size}  ${(png.length / 1024).toFixed(1)} KB  (${Date.now() - t0}ms)`);
}
console.log("Icons written to public/icons/");
