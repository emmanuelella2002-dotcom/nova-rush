# Nova Rush — Pocket Arcade

A one-thumb neon arcade game built as an installable PWA. Chapter One takes Nova,
a comet displaced from her own galaxy, across ten worlds of the Milky Way.

Runs entirely offline, no accounts, no ads, no network calls.

---

## Quick start

```bash
npm install
npm run dev      # local dev server
npm run build    # production build -> dist/
npm run preview  # serve the production build
```

The build inlines **everything** (JS + CSS) into a single `dist/index.html`.
Only the icons, manifest and service worker sit alongside it.

### Installing on Android (no PC required)

1. Host `dist/` anywhere over HTTPS, or open the deployed URL directly.
2. In Chrome or Samsung Internet: **⋮ → Add to Home screen → Install**.
3. For a real `.apk`: open **pwabuilder.com** on the phone, paste the URL,
   tap *Package for Android → Download*, then open the file and allow
   "install unknown apps".

---

## Project layout

```
index.html              app shell, PWA meta, font preloads
vite.config.ts          React + Tailwind v4 + single-file inlining
src/
  main.tsx              entry point, registers the service worker
  index.css             Tailwind v4 theme tokens, glow utilities, keyframes
  App.tsx               screen router + all engine↔UI wiring
  game/
    engine.ts           the game: loop, physics, bosses, aliens, rendering
    abilities.ts        per-comet weapon archetypes and on-hit effects
    cometArt.ts         procedural comet nucleus / coma / tail painter
    stages.ts           10 stage + boss definitions for Chapter One
    chapters.ts         chapter list and star-gated unlocks
    balls.ts            unlockable comet characters and shop prices
    bank.ts             persistent shards, star grades, settings
    audio.ts            synthesized SFX (FM, sub-bass, convolution reverb)
    music.ts            six procedural sci-fi scores
    story.ts            Chapter One prologue text
  ui/
    MainMenu.tsx        title screen and navigation grid
    ChapterSelect.tsx   chapter grid (1 playable, 2–9 locked)
    StageSelect.tsx     stage grid with star grades
    GameHud.tsx         in-game HUD: distance, lives, Supernova, power chips
    Hud.tsx             pause overlay
    BossIntro.tsx       boss name flash
    StageIntro.tsx      stage title card
    StageComplete.tsx   star grade and return to stage select
    GameOver.tsx        run summary and shard banking
    Settings.tsx        audio, soundtrack picker, install guide
    Story.tsx           prologue reader
    Sheet.tsx           how-to-play / APK install bottom sheets
    CometPreview.tsx    canvas comet portraits for the shop
scripts/
  make-icons.mjs        generates PWA icons (pure-JS PNG encoder, no deps)
public/
  manifest.webmanifest  PWA manifest
  sw.js                 offline service worker (bump VERSION to force update)
  icons/                generated at build time
```

Regenerate icons with `node scripts/make-icons.mjs`.

---

## How the game works

**Flow** — Main menu → Chapter select → Stage select → play. Each stage is a
light-year journey ending in a planet boss. Beating it plays a cinematic
fly-off, grades you 1–3 stars, and returns you to stage select.

**Controls** — Drag anywhere to fly; the comet leads your thumb so your finger
never covers the action. Weapons fire automatically once armed. One button:
**Supernova**.

**Weapons** — Collect a weapon orb to arm your gun for 10 seconds; orbs drop
every 20 seconds. Each comet has a distinct archetype and on-hit effect:

| Comet | Weapon | Effect |
|---|---|---|
| Pulse | Machine Gun | Pierce — punches through up to 3 targets |
| Glacier | Ice Slash | Chill — slows targets to 38% |
| Inferno | Wave Gun | Burn — damage over time |
| Nebula | Seeking Missiles | Explosive — 62px AoE detonation |
| Prism | Cosmic Flare | Ricochet + Radiant |

**Supernova** — Recharges on a 20-second timer shown as a radial gauge on the
button. Firing it resets the gauge.

**Power-ups** — shield (10s), slow-mo, ×2 score, extra life, coin magnet (18s),
AI co-pilot drone (40s, stacks to 3), and a rare squadron orb that deploys four
AI fighters for 12 seconds.

**Bosses** — Mercury through the Sun, each with its own palette, surface
features, relative size, movement signature, attack geometry and weapon type.
They are invulnerable during their arrival glide, shown by a blue shield ring.

**Survival** — An endless mode with waves escalating every 25 seconds.

---

## Persistence

All stored in `localStorage`:

| Key | Purpose |
|---|---|
| `nova-best` | best score |
| `nova-credits` | shard balance |
| `nova-balls` | owned comets |
| `nova-ball` | equipped comet |
| `nova-stars` | per-stage star grades |
| `nova-progress` | highest stage cleared |
| `nova-settings` | audio and quality preferences |
| `nova-track` | selected soundtrack |
| `nova-story-seen` | prologue shown |

Clearing site data resets all progress.

---

## Technical notes

**Rendering** — Single `<canvas>`, delta-timed, DPR-aware. Glow sprites are
pre-rendered once rather than using `shadowBlur`, which is prohibitively slow on
mobile. Boss planets and comet nuclei are painted once to offscreen canvases and
blitted. Quality scales down automatically after sustained frame drops.

**Audio** — Everything is synthesized at runtime; there are no audio assets. The
master chain is a glue compressor plus a procedurally-generated 2.2s convolution
reverb. Sounds are built from FM synthesis with deliberately inharmonic ratios
(metallic timbre), dedicated sub-bass voices, and shaped noise bursts. A 22-voice
budget and per-sound rate gates keep allocation in check.

**Music** — Six procedural scores on modal and atonal harmony (Lydian, Phrygian,
whole-tone, Locrian, octatonic, quartal), each with its own tempo, drum feel and
oscillator flavour, scheduled by a lookahead sequencer.

**Performance** — Holds ~55–60 fps on a Galaxy S10. Measurements taken in this
project's test harness ran under a headless software renderer, so real-device
figures are higher.

---

## License

Original work. All code, art and music are generated procedurally — no
third-party assets are bundled.
